@echo off
python3 esex.py
pause
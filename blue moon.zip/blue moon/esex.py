import discord
from discord.ext import commands 
from discord.ext import tasks, commands
from colorama import Fore
from psutil import users
import random
import requests
from collections import defaultdict
import os
import aiohttp
import datetime
import asyncio
import re
import time
import subprocess
import string
import sys
import json
from concurrent.futures import ThreadPoolExecutor
import traceback
from core.utils.logging import success, error, warning, inpt, info
from core.utils.init import config
# Other modules
from core.other.ccchecker import Checker
from core.other.cryptolookup import Cryptolookup
from core.other.hashcracker import hashcracker
from core.other.cvesearcher import FindCVE_NVD_NIST
from core.other.defaultrouter import router
from core.other.maclookup import maclookup
from core.other.userdb import userdb
from core.other.csvdbreader import csvdbreader
# IP modules
from core.ip.iplookup import IpLookup
from core.ip.ipfraud import IpFraud
from core.ip.isproxy import isproxy
from core.ip.portscanner import portscan
from core.ip.getserverbanner import getbanner
from core.ip.isup import isup
from core.ip.networkdeviceenum import netenum
# Minecraft modules
from core.minecraft.usernametoid import UsernameToId
from core.minecraft.capeandskin import CapeAndSkin
from core.minecraft.isblockedserver import IsBlocked
from core.minecraft.serverlookup import MCServerLookup
from core.minecraft.hypixellookup import hypixel_lookup
# Discord modules
from core.discord.idlookup import IdLookup
from core.discord.discordinvinfo import DiscordInvInfo
from core.discord.discordwebhookinfo import WebhookInfo
# Domain modules
from core.domain.subdomainenum import SubdomainEnum
from core.domain.topleveldomainenum import TopLevelDomainEnum
from core.domain.directoryenum import DirectoryEnum
# Location modules
from core.location.ziptolocation import ZIPtoLocation
from core.location.locationtozip import LocationtoZIP
from core.location.citystatetozip import CitystateToZIP
# Identity modules
from core.identity.phonenumber import Phonenumber
from core.identity.usernamelookup import UserLookup
from core.identity.email import email_lookup
from core.identity.peoplelookup import PeopleLookup
from PIL import Image, ImageDraw, ImageFont, ImageOps
from textwrap import wrap
import io

black = "\033[30m"
red = "\033[31m"
green = "\033[32m"
yellow = "\033[33m"
blue = "\033[34m"
magenta = "\033[35m"
cyan = "\033[36m"
white = "\033[37m"
reset = "\033[0m"  
pink = "\033[38;2;255;192;203m"
white = "\033[37m"
blue = "\033[34m"
black = "\033[30m"
light_green = "\033[92m" 
light_yellow = "\033[93m" 
light_magenta = "\033[95m" 
light_cyan = "\033[96m"  
light_red = "\033[91m"  
light_blue = "\033[94m"  

www = Fore.WHITE
mkk = Fore.BLUE
b = Fore.BLACK
ggg = Fore.LIGHTGREEN_EX
y = Fore.LIGHTYELLOW_EX 
pps = Fore.LIGHTMAGENTA_EX
c = Fore.LIGHTCYAN_EX
lr = Fore.LIGHTRED_EX
qqq = Fore.MAGENTA
lbb = Fore.LIGHTBLUE_EX
mll = Fore.LIGHTBLUE_EX
mjj = Fore.RED
yyy = Fore.YELLOW

prefix = ","

# Define a function to get the current prefix
def get_prefix(bot, message):
    return prefix

token = "" # ur token
TOKEN = token
intents = discord.Intents.default()
intents = discord.Intents.all()
bot = commands.Bot(command_prefix=get_prefix, self_bot=True, intents=discord.Intents.default())
bot.remove_command('help')

def get_live_build_number():
    try:
        files = extract_asset_files()
        for file in files:
            build_url = f"https://discord.com{file}"
            response = requesters.get(build_url)
            if "buildNumber" in response.text:
                build_number = response.text.split('build_number:"')[1].split('"')[0]
                return int(build_number)
        return None
    except Exception as e:
        return None


cached_xsuper = None

def getxsuper():
    global cached_xsuper
    if cached_xsuper:
        return cached_xsuper
    os = platform.system()
    browser = "Discord Client"
    osarch = platform.architecture()[0]
    if osarch == '64bit':
        osarch = 'x64'
    elif osarch == '32bit':
        osarch = 'x32'
    current_locale = locale.getdefaultlocale()[0]
    try:
        syslocale = current_locale.replace("_", "-")
    except:
        syslocale = "en-GB"
    osver = platform.version()
    cbuild = get_live_build_number()
    x = {"os":os,"client_build_number":cbuild, "os_version":osver, "system_locale":syslocale,"browser":browser}
    json_str = json.dumps(x)
    xsuper = base64.b64encode(json_str.encode()).decode()
    cached_xsuper = xsuper
    return xsuper

def MassThread(ctx, maxamount):
    while maxamount >= 0:
        r = requests.post(
            f"https://canary.discord.com/api/v9/channels/{ctx.channel.id}/threads",
            json={
                "name": f"😭RAIDED BY REIAAAAAAAAAAAAAAA",
                "type": 11,
                "auto_archive_duration": 60,
                "location": "Slash Command"
            },
            headers={"Authorization": config['token']})
        if r.status_code != int(201):
            print(f"{r.json()}")
            if r.json()['retry_after'] >= 200:
                print(f"more 200s.")
                break
        elif r.status_code == int(404):
            print(f"Channel deleted")
            break
        elif r.status_code == int(429):
            print(f"API BAN :(")
            break
        else:
            print(f"Done")
            maxamount - 1
        continue

def loading_bar():
    bar_length = 30
    for i in range(bar_length + 1):
        percent = int((i / bar_length) * 100)
        bar = f"{Fore.BLUE}[{'=' * i}{' ' * (bar_length - i)}] {percent}%"
        print(f"\r{bar}", end="")
        time.sleep(0.05)
    print(f"\n{Fore.BLUE}Loaded successfully!")

global_headers = {
    'authorization' : TOKEN,
    'authority': 'discord.com',
    'accept': '*/*',
    'accept-language': 'sv,sv-SE;q=0.9',
    'content-type': 'application/json',
    'origin': 'https://discord.com',
    'referer': 'https://discord.com/',
    'sec-ch-ua': '"Not?A_Brand";v="8", "Chromium";v="108"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9016 Chrome/108.0.5359.215 Electron/22.3.12 Safari/537.36',
    'x-debug-options': 'bugReporterEnabled',
    'x-discord-locale': 'sv-SE',
    'x-discord-timezone': 'Europe/Stockholm',
}
status_changing_task = None


def print_banner(bot):
    banner = f"""
{Fore.MAGENTA}
⠀⠀⠀⠀⢠⡶⠚⢷⣤⡀⠀⠀⠀⠀⠀⣲⡶⠛⠻⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⢠⡿⠁⠀⠀⠙⣷⣄⠀⢀⣴⡟⠁⠀⠀⢷⢹⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⣾⠃⠀⠠⠶⠚⠛⠛⠛⠛⠋⠀⠀⣀⡀⢸⠈⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢸⣏⡔⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠚⠉⠉⣿⠀⢹⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢾⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⠀⢸⡇⠀⠀⠀⠀⠀⠀⠀⠀
⠀⢠⣿⢠⣶⡆⠀⠀⠀⠀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⠀⠀⠀⠀⠀⠀⠀
⢒⡾⠁⠘⠟⠁⠀⠀⠀⠀⣿⣿⡆⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⠀⠀⠀⠀⠀⠀⠀
⠉⣧⠀⠀⠀⠀⠃⠀⠀⠀⠈⠉⠠⣍⠀⠀⠀⠀⠀⠀⣸⡇⢀⣤⠶⠛⠛⠻⢦⣄
⠀⠸⣧⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⡟⣴⠟⠁⠀⠀⠀⠀⠀⢻
⠀⠀⠀⠛⣷⡦⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣤⡴⠞⠋⢠⡟⠀⠀⠀⠀⠀⠀⢀⡾
⠀⠀⠀⢰⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠳⣤⡀⢸⠃⠀⠀⠀⠀⢠⡶⠟⠁  banner by 4zx
⠀⠀⠀⣸⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢷⣹⡄⠀⠀⠀⠀⣼⠀⠀⠀
⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢿⣇⠀⠀⠀⠀⢹⡄⠀⠀
⠀⠀⠀⢸⡀⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⡄⠀⠀⠀⠈⣧⠀⠀
⠀⠀⠀⢸⡇⠘⡇⠀⠀⠀⠀⠀⠀⠀⣀⠀⠀⠀⠀⠀⠀⢸⣿⠀⠀⠀⠀⢹⡇⠀
⠀⠀⠀⢸⡇⠀⠙⠀⠀⠀⠀⠀⢠⠞⠁⠀⠀⠀⠀⠀⠀⠀⣿⠇⠀⠀⠀⢸⡇⠀
⠀⠀⠀⢸⡇⠀⢸⡆⠀⠀⠀⠀⣟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠛⠀⠀⠀⠀⣸⠇⠀
⠀⠀⠀⢸⣿⠀⠀⡇⠀⠀⠀⠀⣿⡀⠀⠀⠀⠀⠀⠀⠀⢀⡇⠀⠀⢀⣴⡟⠁⠀
⠀⠀⠀⠘⠿⠶⢶⢧⣦⣦⡴⢾⣥⣽⣤⣤⣤⣤⣤⣤⡴⣯⡤⠴⠶⠛⠋⠀⠀⠀
{Fore.BLUE}    
====================================┳┓┓ ┳┳┏┓  ┳┳┓┏┓┏┓┳┓  ┏┓┓ ┳┏┓┳┓┏┳┓ 
====================================┣┫┃ ┃┃┣   ┃┃┃┃┃┃┃┃┃  ┃ ┃ ┃┣ ┃┃ ┃ J U S T I C E K
====================================┻┛┗┛┗┛┗┛  ┛ ┗┗┛┗┛┛┗  ┗┛┗┛┻┗┛┛┗ ┻ 

{Fore.RESET}
                              {Fore.BLUE}LOGGED AS : {Fore.GREEN}{bot.user}                                   
                              {Fore.BLUE}PREFIX : {Fore.GREEN}{prefix}
                              
                              {Fore.RED}"Don't Fuck with me.. i'm unfuckable" ~4x

"""
    print(banner)


@bot.event
async def on_ready():
    load_cogs()
    loading_bar()
    print_banner(bot)

def load_cogs() -> None:
    """Load all cogs from the cogs folder."""
    cogs_folder = 'cogs'
    for filename in os.listdir(cogs_folder):
        if filename.endswith('.py'):
            try:
                bot.load_extension(f'{cogs_folder}.{filename[:-3]}')
                print(f'Cog :{Fore.LIGHTMAGENTA_EX}{filename} loaded')
            except Exception as e:
                print(f'{Fore.RED}Failed to load {filename}: {str(e)}')

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:137.0) Gecko/20100101 Firefox/137.0',
    'Accept': '*/*',
    'Content-Type': 'application/json',
    'Authorization': TOKEN,
    'Origin': 'https://discord.com',
    'Referer': 'https://discord.com/channels/@me'
}

autofill_active = False
gc_tasks = {}
manual_message_ids = set()
kill_tasks = {}
autoreply_tasks = {}
arm_tasks = {}
outlast_tasks = {}
status_changing_task = None
bold_mode = False
cord_user = False
cord_mode = False
pl_task = None
autopress_messages = {}
autopress_status = {}
autokill_messages = {}
autokill_status = {}
death_tasks = {}
untouchable_tasks = {}
gc_name_counter = {}
current_playback = None
paused = False
ugc_task = None
unused_names = []  # Will reset from self_gcname if empty
ldr_task = None
ldr_tasks = {}  
protection_running = False
protection_messages = []
protection_groupchat = []
protection_tasks = {}
afk_checking = False
stopper = False
autopin_targets = {}  # Dict: {channel_id: user_id}
autopin_enabled = set()

@bot.command()
async def menu(ctx):
    await ctx.send(f"""```
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣶⡄
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡿⣿⡃
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⢿⣻⠇⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣿⣿⠋⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⣶⣳⡽⠇⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠏⢻⣿⡇⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡰⠃⡴⠋⠉⠁⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠞⢠⡞⠁⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡰⢃⣴⠏⠁⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠎⣠⣾⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡔⢃⣴⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡠⠊⣰⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠞⣠⡾⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠞⣡⡾⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀BLUE MOON X MIMI X SOCIAL X LAPPY X ONATOR
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠞⣡⡾⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣠⠞⣡⡾⡋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⡠⢊⣠⠞⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀             Prefix : {prefix}
⠀⠀⢀⡴⣊⡴⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀             Version : 1.0
⠠⠶⠥⠾⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
```""")
    await ctx.send(f"""```
                welcome to blue moon client! ~^_^~
[ packing ]

[1]        chat
[2]        anti gc trap
[3]        anti K
[4]        anti last
[5]        auto reaction
[6]        utility

[ fun ]
 
[7]        nsfw roleplay - this shit is broken i'll fix later 
[8]        fun
[9]        nsfw

[ nuke/raid/event reaction/troll ]
[10]       event reaction
[11]       raid/nuke
[12]       troll

[ dox/other - coming soon ]
```""")
    await ctx.send(f"""```
detonator x mimi x rei x social x lappy x j4j x 66onator x onator
```""")
@bot.command()
async def x5(ctx):
    await ctx.send(f"""```
⠀⠀⢀⣀⡀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠑⠒⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢀⡤⠄⣠⣐⣒⣒⣒⣒⣒⣒⣤⣤⣀⣀⣀⣀⣀⡀⠀⠀
⠀⠀⣠⣞⣷⠟⢻⣿⣾⣿⡿⣻⡏⠉⠋⠩⠽⠋⠉⠉⠉⠉⠁
⣐⡿⠏⠁⠀⠀⠀⠣⣷⣤⡤⠾⠃⠀⠀⠀⠀⣼⠇⠀⠀⠀⠀
⠀⠀⠰⠦⠤⠤⠤⠤⢴⣄⣤⣀⣀⣂⣡⡾⠛⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⠀⠀⠀⠀⠈⠓⠢⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
[ auto reaction ]

[1]        at <user> <emoji>
[2]        at add <user> <emoji>
[3]        at remove <user>
[4]        at set <emoji> 
[5]        at on/off
[6]        at save
[7]        alternative on <user> <emojis>
[8]        alternative off <user>
[9]        alternative set <emojis>
```""")
@bot.command()
async def x1(ctx):
    await ctx.send(f"""```
⠤⣤⣤⣤⣄⣀⣀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣠⣤⠤⠤⠴⠶⠶⠶⠶
⢠⣤⣤⡄⣤⣤⣤⠄⣀⠉⣉⣙⠒⠤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠴⠘⣉⢡⣤⡤⠐⣶⡆⢶⠀⣶⣶⡦
⣄⢻⣿⣧⠻⠇⠋⠀⠋⠀⢘⣿⢳⣦⣌⠳⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠞⣡⣴⣧⠻⣄⢸⣿⣿⡟⢁⡻⣸⣿⡿⠁
⠈⠃⠙⢿⣧⣙⠶⣿⣿⡷⢘⣡⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⣿⣷⣝⡳⠶⠶⠾⣛⣵⡿⠋⠀⠀
⠀⠀⠀⠀⠉⠻⣿⣶⠂⠘⠛⠛⠛⢛⡛⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠛⠀⠉⠒⠛⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⢸⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣾⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢻⡁⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠘⡇⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀ ⠀⠀⠀⠿
[ chat packing ]
[1]        wrath <user>
[2]        wrathoff
[3]        hush <user>
[4]        jump <user>
[5]        jumpoff
[6]        ass <user>
[7]        gcbeef <user>
[8]        gcbeefoff
[9]        press <user>
[10]       pressoff
[11]       automessage <cid> <uid> <min> <name>
[12]       automessageoff <cid> <uid>
[13]       autobeef <uid> <name> <typing_time>
[14]       autobeefoff <uid>
[15]       aggressivebeef <channel_id> <uid> <name>
[16]       aggressivebeefoff <uid>
[17]       beefcd <delay>
[18]       beef <user>
[19]       beefoff
[20]       flood <user>
[21]       floodoff
[22]       murder <user>
[23]       murderoff
[24]       ldder <user>
[25]       ldderoff
[26]       lappymode <user> <optional/on>
[27]       lappymodeoff
[28]       whore <user>
[29]       whoreoff
```""")
    await ctx.send(f"""```
[30]       faggot <user>
[31]       faggotoff
[32]       court <user>
[33]       courtoff
[34]       ar <user>
[35]       aroff
[36]       execute <user>
[37]       executeoff
[38]       autopin <user>
[39]       autopinoff
[40]       ugc <user>
[41]       ugcoff
[42]       sgc
[43]       sgcoff
[44]       lm <messages>
[45]       gcleaveall
[46]       replybeef <user>
[47]       replybeefoff
```""")
    await ctx.send(f"""```
[48]       gcname start <user>
[49]       gcname stop
[50]       gcname add <msg>
[51]       gcname remove <id>
[52]       gcname list
[53]       gcname delay <sec>
[54]       gcname counter
[55]       gcname random
[56]       gcname reset
[57]       ladder
[58]       ladder stop 
[59]       ladder add <msg 
[60]       ladder remove <msg>
[61]       ladder list
[62]       ladder delay <sec>
[63]       ladder reset
[64]       ladder clear
```""")
    await ctx.send(f"""```
[65]       afkcheck <user> <count>
[66]       duckcheck <user> <count>
[67]       vccheck <user> <count>
[68]       cord <user>
[69]       cordoff
[70]       mimic <user>
[71]       mimicoff
[72]       spam <message>
[73]       spamoff
[74]       lol <user>
[75]       lock <name>
[76]       unlock
```""")
@bot.command()
async def x2(ctx):
    await ctx.send(f"""```
⣿⣿⣿⣿⣿⣷⣿⣿⣿⡅⡹⢿⠆⠙⠋⠉⠻⠿⣿⣿⣿⣿⣿⣿⣮⠻⣦⡙⢷⡑⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣌⠡⠌⠂⣙⠻⣛⠻⠷⠐⠈⠛⢱⣮⣷⣽⣿
⣿⣿⣿⣿⡇⢿⢹⣿⣶⠐⠁⠀⣀⣠⣤⠄⠀⠀⠈⠙⠻⣿⣿⣿⣦⣵⣌⠻⣷⢝⠦⠚⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢟⣻⣿⣊⡃⠀⣙⠿⣿⣿⣿⣎⢮⡀⢮⣽⣿⣿
⢿⣿⣿⣿⣧⡸⡎⡛⡩⠖⠀⣴⣿⣿⣿⠀⠀⠀⠀⠸⠇⠀⠙⢿⣿⣿⣿⣷⣌⢷⣑⢷⣄⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣫⠶⠛⠉⠀⠁⠀⠈⠈⠀⠠⠜⠻⣿⣆⢿⣼⣿⣿⣿
⢐⣿⣿⣿⣿⣧⢧⣧⢻⣦⢀⣹⣿⣿⣿⣇⠀⠄⠀⠀⠀⡀⠀⠈⢻⣿⣿⣿⣿⣷⣝⢦⡹⠷⡙⢿⣿⣿⣿⣿⣿⣿⣿⣿⠈⠁⠀⠀⠀⠁⠀⠀⠀⠱⣶⣄⡀⠀⠈⠛⠜⣿⣿⣿⣿
⠀⠊⢫⣿⣏⣿⡌⣼⣄⢫⡌⣿⣿⣿⣿⣿⣦⡈⠲⣄⣤⣤⡡⢀⣠⣿⣿⣿⣿⣿⣿⣷⣼⣍⢬⣦⡙⣿⣿⣿⣿⣿⣯⢁⡄⠀⡀⡀⠀⠄⢈⣠⢪⠀⣿⣿⣿⣦⠀⢉⢂⠹⡿⣿⣿
⠀⠀⠄⢹⢃⢻⣟⠙⣿⣦⠱⢻⣿⣿⣿⣿⣿⣿⣷⣬⣍⣭⣥⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⡙⢿⣼⡿⣿⣿⣿⣿⣿⣷⣄⠘⣱⢦⣤⡴⡿⢈⣼⣿⣿⣿⣇⣴⣶⣮⣅⢻⣿⡏
⠀⠀⠈⠹⣇⢡⢿⡆⠻⣿⣷⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣍⡻⣿⣟⣻⣿⣿⣿⣿⣷⣦⣥⣬⣤⣴⣾⣿⣿⣿⣿⣷⣿⣿⣿⣿⣷⡜⠃
⠀⠀⠀⢀⣘⠈⢂⠃⣧⡹⣿⣷⡄⠙⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣮⣅⡙⢿⣟⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠋⡕⠂
⠀⠀⠀⠀⠀⠀⠛⢷⣜⢷⡌⠻⣿⣿⣦⣝⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⣹⣷⣦⣹⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠉⠃⠀
[ anti gc ]
[1]        antigcspam
[2]        antigcspam whitelist <user>
[3]        antigcspam unwhitelist <user>
[4]        antigcspam blacklist <user>
[5]        antigcspam unblacklist <user>
[6]        antigcspam silent
[7]        antigcspam message <message>
[8]        antigcspam autoremove
[9]        antigcspam webhook <webhook>
[10]       antigcspam autoblock
[11]       antigcspam list
[12]       autogc
[13]       autogc stop
[14]       autogc whitelist  <user>
[15]       autogc whitelistr <user>
[16]       autogc list
[17]       autogcleave
[18]       autogcleave stop
[19]       autogcleave status
```""")
@bot.command()
async def x3(ctx):
    await ctx.send(f"""```
⠀⠀⠀⠀⢀⡠⠤⠔⢲⢶⡖⠒⠤⢄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⣠⡚⠁⢀⠀⠀⢄⢻⣿⠀⠀⠀⡙⣷⢤⡀⠀⠀⠀⠀⠀⠀
⠀⡜⢱⣇⠀⣧⢣⡀⠀⡀⢻⡇⠀⡄⢰⣿⣷⡌⣢⡀⠀⠀⠀⠀
⠸⡇⡎⡿⣆⠹⣷⡹⣄⠙⣽⣿⢸⣧⣼⣿⣿⣿⣶⣼⣆⠀⠀⠀
⣷⡇⣷⡇⢹⢳⡽⣿⡽⣷⡜⣿⣾⢸⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀
⣿⡇⡿⣿⠀⠣⠹⣾⣿⣮⠿⣞⣿⢸⣿⣛⢿⣿⡟⠯⠉⠙⠛⠓
⣿⣇⣷⠙⡇⠀⠁⠀⠉⣽⣷⣾⢿⢸⣿⠀⢸⣿⢿⠀⠀⠀⠀⠀
⡟⢿⣿⣷⣾⣆⠀⠀⠘⠘⠿⠛⢸⣼⣿⢖⣼⣿⠘⡆⠀⠀⠀⠀
⠃⢸⣿⣿⡘⠋⠀⠀⠀⠀⠀⠀⣸⣿⣿⣿⣿⣿⡆⠇⠀⠀⠀⠀
⠀⢸⡿⣿⣇⠀⠈⠀⠤⠀⠀⢀⣿⣿⣿⣿⣿⣿⣧⢸⠀⠀⠀⠀
⠀⠈⡇⣿⣿⣷⣤⣀⠀⣀⠔⠋⣿⣿⣿⣿⣿⡟⣿⡞⡄⠀⠀⠀
⠀⠀⢿⢸⣿⣿⣿⣿⣿⡇⠀⢠⣿⡏⢿⣿⣿⡇⢸⣇⠇⠀⠀⠀
⠀⠀⢸⡏⣿⣿⣿⠟⠋⣀⠠⣾⣿⠡⠀⢉⢟⠷⢼⣿⣿⠀⠀⠀
⠀⠀⠈⣷⡏⡱⠁⠀⠊⠀⠀⣿⣏⣀⡠⢣⠃⠀⠀⢹⣿⡄⠀⠀
⠀⠀⠘⢼⣿⠀⢠⣤⣀⠉⣹⡿⠀⠁⠀⡸⠀⠀⠀⠈⣿⡇⠀⠀
[ anti k ]
[1]        antik toggle <on/off>
[2]        antik whitelist <id>
[3]        antik channel <id>
[4]        antik webhook <url>
[5]        antik config
```""")
@bot.command()
async def x4(ctx):
    await ctx.send(f"""```
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⡤⠤⠤⠤⣤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡤⠞⠋⠁⠀⠀⠀⠀⠀⠀⠀⠉⠛⢦⣤⠶⠦⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢀⣴⠞⢋⡽⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠃⠀⠀⠙⢶⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣰⠟⠁⠀⠘⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⡀⠀⠀⠉⠓⠦⣤⣤⣤⣤⣤⣤⣄⣀⠀⠀⠀
⠀⠀⠀⠀⣠⠞⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⣷⡄⠀⠀⢻⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣆⠀
⠀⠀⣠⠞⠁⠀⠀⣀⣠⣏⡀⠀⢠⣶⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⠿⡃⠀⠀⠄⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⡆
⢀⡞⠁⠀⣠⠶⠛⠉⠉⠉⠙⢦⡸⣿⡿⠀⠀⠀⡄⢀⣀⣀⡶⠀⠀⠀⢀⡄⣀⠀⣢⠟⢦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⠃
⡞⠀⠀⠸⠁⠀⠀⠀⠀⠀⠀⠀⢳⢀⣠⠀⠀⠀⠉⠉⠀⠀⣀⠀⠀⠀⢀⣠⡴⠞⠁⠀⠀⠈⠓⠦⣄⣀⠀⠀⠀⠀⣀⣤⠞⠁⠀
⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⠀⠁⠀⢀⣀⣀⡴⠋⢻⡉⠙⠾⡟⢿⣅⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠙⠛⠉⠉⠀⠀⠀⠀
⠘⣦⡀⠀⠀⠀⠀⠀⠀⣀⣤⠞⢉⣹⣯⣍⣿⠉⠟⠀⠀⣸⠳⣄⡀⠀⠀⠙⢧⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠈⠙⠒⠒⠒⠒⠚⠋⠁⠀⡴⠋⢀⡀⢠⡇⠀⠀⠀⠀⠃⠀⠀⠀⠀⠀⢀⡾⠋⢻⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⢸⡀⠸⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⠀⢠⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣇⠀⠀⠉⠋⠻⣄⠀⠀⠀⠀⠀⣀⣠⣴⠞⠋⠳⠶⠞⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠳⠦⢤⠤⠶⠋⠙⠳⣆⣀⣈⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
[ anti last ]
[1]        antilast toggle <on/off>
[2]        antilast whitelist <id>
[3]        antilast channel <id>
[4]        antilast webhook <url>
[5]        antilast config
```""")
@bot.command()
async def x6(ctx):
    await ctx.send(f"""```
⠀⠀⠀⠀⠀⠀⠀⠀⣠⣴⣶⡋⠉⠙⠒⢤⡀⠀⠀⠀⠀⠀⢠⠖⠉⠉⠙⠢⡄⠀
⠀⠀⠀⠀⠀⠀⢀⣼⣟⡒⠒⠀⠀⠀⠀⠀⠙⣆⠀⠀⠀⢠⠃⠀⠀⠀⠀⠀⠹⡄
⠀⠀⠀⠀⠀⠀⣼⠷⠖⠀⠀⠀⠀⠀⠀⠀⠀⠘⡆⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⢷
⠀⠀⠀⠀⠀⠀⣷⡒⠀⠀⢐⣒⣒⡒⠀⣐⣒⣒⣧⠀⢰⠀⠀⢠⢤⢠⡠⠀⢸⠀
⠀⠀⠀⠀⠀⢰⣛⣟⣂⠀⠘⠤⠬⠃⠰⠑⠥⠊⣿⠀⢸⠀⠀⠓⠃⠋⠂⠀⢸⠀
⠀⠀⠀⠀⠀⢸⣿⡿⠤⠀⢸⠁⠀⠀⢀⡆⠀⠀⣿⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⣸
⠀⠀⠀⠀⠀⠈⠿⣯⡭⠀⠸⡀⠀⢀⣀⠀⠀⠀⡟⠀⠀⢸⠀⠀⠀⠀⠀⠀⢠⠏
⠀⠀⠀⠀⠀⠀⠀⠈⢯⡥⠄⢱⠀⠀⠀⠀⠀⡼⠁⠀⠀⠀⠳⢄⣀⣀⣀⡴⠃⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢱⡦⣄⣀⣀⣀⣠⠞⠁⠀⠀⠀⠀⠀⠀⠈⠉⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢀⣤⣾⠛⠃⠀⠀⠀⢹⠳⡶⣤⡤⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣠⢴⣿⣿⣿⡟⡷⢄⣀⣀⣀⡼⠳⡹⣿⣷⠞⣳⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⢰⡯⠭⠹⡟⠿⠧⠷⣄⣀⣟⠛⣦⠔⠋⠛⠛⠋⠙⡆⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢸⣿⠭⠉⠀⢠⣤⠀⠀⠀⠘⡷⣵⢻⠀⠀⠀⠀⣼⠀⣇⠀⠀⠀⠀⠀⠀⠀
⠀⠀⡇⣿⠍⠁⠀⢸⣗⠂⠀⠀⠀⣧⣿⣼⠀⠀⠀⠀⣯⠀⢸⠀⠀⠀⠀⠀⠀⠀
[ utility ]
[1]        setpfp <imgurl>
[2]        setname <name>
[3]        setbio <bio>
[4]        setpronoun <pronoun>
[5]        setbanner <imgurl>
[6]        stealbio <user>
[7]        stealbanner <user>
[8]        stealpfp <user>
[9]        stealpronoun <user>
[10]       rtag
[11]       rtag stop
[12]       rtag status
[13]       rtag delay
[14]       dmsnipe log <url>
[15]       dmsnipe toggle <on/off 
[16]       dmsnipe edit <on/off>
[17]       dmsnipe ignore <user/id>
[18]       dmsnipe clear
[19]       ping
[20]       uptime
[21]       ab
[22]       aboff
[23]       astatus <status,status2,more>
[24]       astatusoff
[25]       aemoji <emoji,emoji2,more>
[26]       aemojioff
[27]       setprefix <prefix>
```""")
@bot.command()
async def x9(ctx):
    await ctx.send(f"""```
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣐⠒⠒⠦⢤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠑⠦⣀⠀⠀⠙⠢⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠳⣄⠀⠀⠈⢢⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⢷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢀⣠⠤⠔⠀⠀⠀⠉⠁⠀⠉⠉⠳⣄⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⣾⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⢀⡤⠖⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠒⠢⣄⠀⠈⢣⡀⠀⠀⠀⢸⠀⠀⠀⣰⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠊⠁⢀⣀⠤⠔⠒⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠱⣄⠀⣱⡄⠀⠲⢏⡀⠀⢠⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠐⠊⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡀⠈⢉⣁⣀⣀⡠⣴⣻⣦⠘⣯⣱⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣿⢻⣾⠽⠓⢯⣹⡇⠚⢻⣿⡇⢻⠹⣿⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣧⡿⣿⡟⣶⣦⣄⣽⣻⡄⠘⣿⣿⣼⣶⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠛⣇⣿⣷⡌⠳⠿⠿⠿⣇⠀⢹⣏⣿⠿⣅⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣿⠉⠉⠀⠀⠀⣸⡟⣠⢏⠝⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⠀⠀⢈⣼⣷⡟⢀⣼⡇⠀⢀⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣷⡀⠀⠀⠀⡾⡸⠡⢻⣿⠁⠀⢸⣹⣤⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣻⣦⣀⣼⡿⠃⠒⢸⡟⢀⠀⠈⡏⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡜⠋⠉⠉⡓⠀⠀⢸⠃⢸⠀⢷⣷⣿⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⣀⡾⠀⠀⠀⠀⠈⢣⠀⣼⠀⣸⠀⠸⣿⢸⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⣾⠋⠁⠀⠀⠀⠀⠀⠀⠀⢰⡇⠀⣿⢰⠀⣿⡾⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠀⠀⠀⠀⠀⠀⠀⠀⢠⡏⠀⢰⣿⢸⠀⢻⠁⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣧⡄⠀⠀⠀⠀⠀⢀⡾⢀⠀⣿⢻⢸⠀⢸⢻⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⡏⠀⠀⠀⠀⠀⠀⣼⠃⡼⢀⡏⢸⢸⡇⢸⣸⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⠁⠀⠀⣠⣿⣦⣴⡇⢀⡇⢸⣿⣸⣿⡇⣿⣿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⠃⠀⠀⢀⣿⣿⣿⣏⡄⢸⣷⣾⣿⣿⣧⢳⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⠁⠀⠀⠀⣼⣿⣿⣿⣿⣇⣿⡟⢿⣿⠸⣏⠿⠟⣻⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⠃⠀⠀⠀⢰⢯⣿⣿⣿⣿⣿⣿⣷⣿⣿⣦⢿⣄⣤⡿⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡞⠀⠀⠀⣴⣯⣼⣿⡟⢻⣟⣿⣿⣿⡿⠿⠋⠛⢯⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⠁⠀⠀⢠⣟⠉⡽⠙⢿⣥⡄⢲⣻⡟⢠⠀⠀⠀⠀⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡏⠀⠀⢠⣯⣼⣷⠃⠀⠀⠙⢷⣾⣯⣿⣌⠑⠢⠀⣠⣿⢿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⠀⠀⢠⣿⠖⠛⠁⠀⠀⠀⠀⠀⠙⣿⠿⣿⣿⣻⡿⠟⣿⠈⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡼⠉⢢⡀⣿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢿⣾⣿⡼⢁⣾⡟⠀⢸⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣰⡯⠚⠉⠢⣭⣼⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⣇⣼⡿⠀⠀⠘⡛⣷⣤⣤⣤⣤⣤⣤⣤⣤⡀⠀
⠀⠀⠀⠀⠀⠀⢀⡾⠁⣀⣀⣤⣴⣋⠀⠹⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⠟⠀⠀⢀⡞⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡆
⠀⢀⣴⣾⣿⣷⣿⣶⣿⣿⣿⣉⣿⡍⠛⠲⣝⣦⣄⡀⠀⠀⠀⠀⠀⠀⢀⠞⣽⣿⠏⠀⢀⣴⡿⠋⠑⠈⠉⠉⠉⠛⠛⠿⠿⠿⠟⠀
⣰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠉⠙⠿⢭⣗⣒⣒⣒⣚⣥⠞⠙⠼⠿⠿⠿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠙⠙⢻⠿⠿⠿⠿⠛⠋⠉⠉⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
[ nsfw 18+ ]
[1]        ecchi <user>
[2]        hentai <user>
[3]        uniform <user>
[4]        maid <user>
[5]        oppai <user>
[6]        selfies <user>
[7]        raiden <user>
[8]        marin <user>
[9]        4k
[10]       hboobs
[11]       anal
[12]       hanal
[13]       boobs
[14]       gif
[15]       thigh

```""")
@bot.command()
async def x7(ctx):
    await ctx.send(f"""```
⠀⠀⠀⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣼⣿⣿⣟⣻⣿⡏⠻⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣼⣿⣿⣿⢿⣿⣿⠗⠀⢹⣿⣿⣟⡄⠀⠀⠀⠀⠀
⠀⠀⠀⢰⣿⣿⣇⣻⡮⢟⠛⠛⠛⣻⣿⣿⣿⠘⡀⠀⠀⠀⠀
⠀⠀⠀⢸⣿⣿⡿⣷⡰⠀⠀⣀⢉⣸⣿⣿⣿⡶⠁⠀⠀⠀⠀
⠀⠀⠀⢸⣿⣿⣽⣶⣦⡀⢾⣏⠐⣿⣿⣿⠿⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠈⢟⡿⠿⠟⠿⣙⡄⠈⠓⡄⠉⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢰⠃⠀⠀⠀⠈⠉⡖⠀⡟⠢⡄⠀⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢸⠀⠀⠀⢢⠀⢀⡆⠀⡇⠀⠈⠢⡈⠠⠀⠀⠀⠀
⠀⠀⠀⠀⠘⡆⠀⠀⠈⣧⢸⠀⠀⡇⠢⡀⠀⠈⠦⡇⠀⠀⠀
⠀⠀⠀⠀⠀⠹⡆⠀⠀⢨⠃⠀⠀⣇⠀⠈⠢⠀⠀⠈⢢⠀⠀
⠀⠀⠀⠀⠀⠀⠑⡀⠀⠇⠀⠀⠀⡇⠳⡀⠀⢱⠀⠀⠀⢳⡀
⠀⠀⠀⠀⠀⠀⠀⠱⣾⠀⠀⠀⠀⡇⠀⠑⡀⡸⠄⠀⠀⣜⢘
⠀⠀⠀⠀⠀⠀⠀⠀⠙⣄⠀⠀⣰⢀⣤⡤⠼⣧⣤⣤⡾⠟⠁
⠀⠀⠀⠀⠀⠀⠀⠀⢀⣼⠑⠒⠉⠉⠁⠀⢠⠀⣽⠁⠀⠀⠀
⠀⠀⠀⠀⠀⢀⡠⠔⠉⠈⠣⠀⠀⠀⠀⠀⠀⣰⡏⠀⠀⠀⠀
⠀⠀⠀⢠⡖⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠆⠀⡇⠃⠀⠀⠀⠀
⠀⠀⣴⠛⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⡜⠀⢀⠃⠃⠀⠀⠀⠀
⠀⡼⠃⣸⡉⠢⠀⠀⢆⠀⠀⠀⠀⠀⠁⠀⠼⣦⡆⠀⠀⠀⠀
⢰⠁⠀⠏⡇⠀⠈⠐⢬⣄⠀⠀⠀⠀⠀⢀⣼⢿⠅⠀⠀⠀⠀
⢸⠀⢠⢀⠁⠀⠀⠀⠀⢇⠈⠁⢒⠖⠊⠉⠀⠘⡆⠀⠀⠀⠀
⢸⠀⡜⡘⠀⠀⠀⠀⠀⠘⣦⠔⠁⠀⠀⠀⠀⠀⠸⡄⠀⠀
[ nsfw roleplay ]
[1]        fuck <user>
[2]        cum <user>
[3]        masturbate
[4]        blowjob <user>
[5]        handjob <user>
[6]        dickride <user>
```""")
@bot.command()
async def x8(ctx):
    await ctx.send(f"""```
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠤⣄⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⡇⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢀⣤⣴⣶⣶⣶⣶⣶⣦⣤⡄⠊⠀⠀⠀⠀⠀
⠀⠦⣤⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀
⠀⠀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⠀⠀
⠀⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⠀⠀
⣠⣿⣿⣿⡿⢻⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⣿⣿⣿⡧⠀
⠉⢹⣿⣿⢓⣺⡿⠟⠛⠛⢻⣿⣼⣿⣿⣿⣿⣿⣿⣿⣇⠀
⠀⢸⣿⣿⠉⠀⠀⠀⠀⠀⠀⠀⠈⢀⣿⡿⠿⢿⣿⣿⣿⠀
⡀⠈⣿⣿⡀⠀⠀⠠⠄⠀⠀⠀⠀⢸⣿⣗⠏⢪⣿⣿⣿⡇
⠀⢀⡈⣿⣷⣤⣄⣀⠀⠀⠀⢀⣤⣿⣿⣷⣾⣿⣿⣿⣿⣧
⠀⠘⠉⢹⣿⣿⣿⣿⣿⡇⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⠀⠀⠀⣾⣿⣿⠟⡿⠟⡁⠄⠚⠉⠀⠘⢿⣿⣿⣿⣿⣿⡇
⠀⠀⠀⣿⠟⠁⠈⠉⠁⠀⠀⠀⠀⠀⠀⠀⠙⡿⠿⠏⠿⠃
⠀⠀⠀⡜⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⡄⠀⠀⠀
[ fun ]
[1]        kiss <user>
[2]        slap <user>
[3]        wave <user>
[4]        hug <user>
[5]        cuddle <user>
[6]        hurt <user>
[7]        bite <user>
[8]        poke <user>
[9]        cry
[10]       smile
[11]       sleep
[12]       smug <user>
[13]       handhold <user>
[14]       highfive <user>
[15]       dance 
[16]       blush
[17]       wink
[18]       yeet <user>
[19]       nom <user>
[20]       lick <user>
[21]       bully <user>
[22]       cat
[23]       catfact
```""")
@bot.command()
async def x10(ctx):
    await ctx.send(f"""```
⠀⠀⠀⠀⠀⠀⢀⣾⡿⣹⣿⣿⣧⣿⣿⣿⣇⢳⢹⣿⣿⣿⠉⣿⣿⣿⣷⣹⣿⣾⣼⣿⣄⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⡠⣺⣿⢋⣯⣿⡟⢹⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣿⣿⣿⢿⣿⣷⣦⡀⠀⠀⠀⠀
⠀⠀⠀⢀⣾⡾⣳⣃⣞⣿⣾⠫⣿⣿⣿⣿⣿⢾⣾⣿⣿⣿⣤⣽⣿⣿⣿⣷⢾⣿⣿⣿⢿⣿⣟⣿⣶⣄⠀⠀
⠀⠀⡰⣧⡿⣿⣏⡸⣾⣿⡏⢻⣿⢻⣿⣿⣿⣼⣽⣿⣏⣿⣗⣺⣿⣸⣿⣿⣭⢿⣿⣷⣻⡻⣿⣯⣻⣿⣦⡀
⢀⡼⣿⡿⣽⡟⢻⡿⣿⣿⠿⣾⣿⣼⣿⣿⣏⣼⣽⣸⣿⣿⡏⠙⣿⣄⣿⣿⣇⣸⣿⣽⣷⣿⡿⣿⣿⣽⣿⡿
⠈⠻⣟⢻⠟⢓⢯⢷⡟⣻⠸⠿⢅⣿⣿⣿⠉⣿⣿⢻⣿⣿⡿⠛⣿⡟⢻⣿⣿⣉⣻⣧⣿⣷⣷⢿⣿⣿⠏⠀
⠀⠀⠐⠛⠒⢼⡾⠘⠀⣿⡠⠤⠨⠭⢉⣉⠉⠉⠙⡾⣿⠟⠓⠊⢉⡙⠿⠛⠋⠉⡿⣧⠭⠛⠻⠞⠉⡆⠀⠀
⠀⠀⠀⠀⠀⠀⠈⠉⠙⠓⢇⢀⣤⣴⣶⣶⣶⣦⣤⡗⢻⣐⣲⣭⣥⣤⣄⣀⠀⢴⠉⠁⠀⠀⠀⠀⠀⠃⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⡇⢸⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣿⢿⣿⡿⣯⣿⣿⡇⢸⣿⣿⣿⣿⢿⣿⣿⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⣿⡗⡉⣿⣿⡇⢸⣿⣿⣾⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣿⣿⣿⣿⣿⣿⡇⠘⣿⣿⣿⣿⣿⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣗⣿⣿⣿⣿⣿⣷⠀⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⠀⣿⣿⣿⢿⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣷⣿⣿⣿⡿⠀⣿⣿⣷⣾⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡾⠿⣿⣿⣿⣿⣿⠇⠀⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣋⣠⣶⣻⣿⣿⣿⠏⠀⠀⢻⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⢿⣿⣿⣿⣿⣿⣿⡏⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣮⠟⢿⣿⣿⣿⣿⡟⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢰⣽⠀⠀⢨⣿⣿⣿⠃⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣶⣶⣿⣿⣿⠇⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠠⣿⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣹⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣼⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣰⣿⢿⣿⣿⣿⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢀⣿⣿⣿⣿⣽⣿⣿⣷⠀⠀⠀⠀⠀⠀⠀⢠⣿⡯⣼⣿⣿⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣤⣤⠀⠀⣠⣿⣿⣿⣾⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
[ event reaction ]
[1]        keywordr
[2]        reactkw
[3]        eonmessage
[4]        ronping
[5]        sonping
[6]        monitoruser <user>
[7]        unmonitor <user>
```""")
@bot.command()
async def x11(ctx):
    await ctx.send(f"""```
⠀⠀⠀⠀⠀⠀⠀⠀⣠⣴⣶⡋⠉⠙⠒⢤⡀⠀⠀⠀⠀⠀⢠⠖⠉⠉⠙⠢⡄⠀
⠀⠀⠀⠀⠀⠀⢀⣼⣟⡒⠒⠀⠀⠀⠀⠀⠙⣆⠀⠀⠀⢠⠃⠀⠀⠀⠀⠀⠹⡄
⠀⠀⠀⠀⠀⠀⣼⠷⠖⠀⠀⠀⠀⠀⠀⠀⠀⠘⡆⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⢷
⠀⠀⠀⠀⠀⠀⣷⡒⠀⠀⢐⣒⣒⡒⠀⣐⣒⣒⣧⠀⢰⠀⠀⢠⢤⢠⡠⠀⢸⠀
⠀⠀⠀⠀⠀⢰⣛⣟⣂⠀⠘⠤⠬⠃⠰⠑⠥⠊⣿⠀⢸⠀⠀⠓⠃⠋⠂⠀⢸⠀
⠀⠀⠀⠀⠀⢸⣿⡿⠤⠀⢸⠁⠀⠀⢀⡆⠀⠀⣿⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⣸
⠀⠀⠀⠀⠀⠈⠿⣯⡭⠀⠸⡀⠀⢀⣀⠀⠀⠀⡟⠀⠀⢸⠀⠀⠀⠀⠀⠀⢠⠏
⠀⠀⠀⠀⠀⠀⠀⠈⢯⡥⠄⢱⠀⠀⠀⠀⠀⡼⠁⠀⠀⠀⠳⢄⣀⣀⣀⡴⠃⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢱⡦⣄⣀⣀⣀⣠⠞⠁⠀⠀⠀⠀⠀⠀⠈⠉⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢀⣤⣾⠛⠃⠀⠀⠀⢹⠳⡶⣤⡤⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣠⢴⣿⣿⣿⡟⡷⢄⣀⣀⣀⡼⠳⡹⣿⣷⠞⣳⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⢰⡯⠭⠹⡟⠿⠧⠷⣄⣀⣟⠛⣦⠔⠋⠛⠛⠋⠙⡆⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢸⣿⠭⠉⠀⢠⣤⠀⠀⠀⠘⡷⣵⢻⠀⠀⠀⠀⣼⠀⣇⠀⠀⠀⠀⠀⠀⠀
⠀⠀⡇⣿⠍⠁⠀⢸⣗⠂⠀⠀⠀⣧⣿⣼⠀⠀⠀⠀⣯⠀⢸⠀⠀⠀⠀⠀⠀⠀

[ nuke/raid ]
[1]        nuke
[2]        nuke message <text>
[3]        nuke name <text>
[4]        nuke delay <seconds>
[5]        nuke speed <seconds>
[6]        nuke channels <amount>
[7]        nuke roles <amount>
[8]        nuke webhooks <amount>
[9]        nuke reset
[10]       nuke start
[11]       nuke stop
[12]       karma
[13]       ctc
[14]       cvc
[15]       seize - risky
[16]       delc
[17]       raid
```""")
@bot.command()
async def x12(ctx):
    await ctx.send(f"""```
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠤⠖⠚⢉⣩⣭⡭⠛⠓⠲⠦⣄⡀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⡴⠋⠁⠀⠀⠊⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠳⢦⡀⠀⠀⠀⠀
⠀⠀⠀⠀⢀⡴⠃⢀⡴⢳⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣆⠀⠀⠀
⠀⠀⠀⠀⡾⠁⣠⠋⠀⠈⢧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢧⠀⠀
⠀⠀⠀⣸⠁⢰⠃⠀⠀⠀⠈⢣⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣇⠀
⠀⠀⠀⡇⠀⡾⡀⠀⠀⠀⠀⣀⣹⣆⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⠀
⠀⠀⢸⠃⢀⣇⡈⠀⠀⠀⠀⠀⠀⢀⡑⢄⡀⢀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇
⠀⠀⢸⠀⢻⡟⡻⢶⡆⠀⠀⠀⠀⡼⠟⡳⢿⣦⡑⢄⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇
⠀⠀⣸⠀⢸⠃⡇⢀⠇⠀⠀⠀⠀⠀⡼⠀⠀⠈⣿⡗⠂⠀⠀⠀⠀⠀⠀⠀⢸⠁
⠀⠀⡏⠀⣼⠀⢳⠊⠀⠀⠀⠀⠀⠀⠱⣀⣀⠔⣸⠁⠀⠀⠀⠀⠀⠀⠀⢠⡟⠀
⠀⠀⡇⢀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⢸⠃⠀
⠀⢸⠃⠘⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠁⠀⠀⢀⠀⠀⠀⠀⠀⣾⠀⠀
⠀⣸⠀⠀⠹⡄⠀⠀⠈⠁⠀⠀⠀⠀⠀⠀⠀⡞⠀⠀⠀⠸⠀⠀⠀⠀⠀⡇⠀⠀
⠀⡏⠀⠀⠀⠙⣆⠀⠀⠀⠀⠀⠀⠀⢀⣠⢶⡇⠀⠀⢰⡀⠀⠀⠀⠀⠀⡇⠀⠀
⢰⠇⡄⠀⠀⠀⡿⢣⣀⣀⣀⡤⠴⡞⠉⠀⢸⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣧⠀⠀
⣸⠀⡇⠀⠀⠀⠀⠀⠀⠉⠀⠀⠀⢹⠀⠀⢸⠀⠀⢀⣿⠇⠀⠀⠀⠁⠀⢸⠀⠀
⣿⠀⡇⠀⠀⠀⠀⠀⢀⡤⠤⠶⠶⠾⠤⠄⢸⠀⡀⠸⣿⣀⠀⠀⠀⠀⠀⠈⣇⠀
⡇⠀⡇⠀⠀⡀⠀⡴⠋⠀⠀⠀⠀⠀⠀⠀⠸⡌⣵⡀⢳⡇⠀⠀⠀⠀⠀⠀⢹⡀
⡇⠀⠇⠀⠀⡇⡸⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠮⢧⣀⣻⢂⠀⠀⠀⠀⠀⠀⢧
⣇⠀⢠⠀⠀⢳⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⡎⣆⠀⠀⠀⠀⠀⠘
⢻⠀⠈⠰⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰⠘⢮⣧⡀⠀⠀⠀⠀
⠸⡆⠀⠀⠇⣾⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠆⠀⠀⠀⠀⠀⠀⠀⠙⠳⣄⡀⢢⡀
[ troll ]
[1]        swat <user>
[2]        dick <user>
[3]        gay <user>
[4]        rapemom <user>
[5]        wife
[6]        rape <user>
[7]        nigger <user>
[8]        fuck <user>
[9]        eboy <user>
[10]       egirl <user>
[11]       edater <user>
[12]       skid <user>
[13]       comboy <user>
[14]       autism <user>
[15]       spiderdick
[16]       catboy
[17]       jews
[18]       rizz <user>
[19]       bomber <user>
[20]       phc <user>
[21]       tweet
[22]       speechbubble <imgurl> <togif/on/off> = unfinished shit so it will not worl correctly
[23]       caption <imgurl> <text>
```""")


@bot.command()
async def ipc(ctx):
    # Retrieve public IP
    try:
        public_ip = requests.get("https://api.ipify.org").text
    except Exception as e:
        await ctx.send("Failed to retrieve public IP.")
        return

    # Check for tshark installation
    tshark_path = ""
    if os.path.exists("C:\\Program Files\\Wireshark\\tshark.exe"):
        tshark_path = "C:\\Program Files\\Wireshark\\tshark.exe"
    elif os.path.exists("C:\\Program Files (x86)\\Wireshark\\tshark.exe"):
        tshark_path = "C:\\Program Files (x86)\\Wireshark\\tshark.exe"

    if not tshark_path:
        await ctx.send("Wireshark not found. Please install it from https://www.wireshark.org/download.html")
        return

    await ctx.send(f"```wireshark found.. starting..```")
    
    # List interfaces
    interfaces = subprocess.check_output([tshark_path, '-D']).decode('utf-8')
    await ctx.send(f"```Available Interfaces:\n{interfaces}```")

    # Prompt for interface selection
    await ctx.send("```Select Interfaces To capture.```")
    
    def check(m):
        return m.author == ctx.author and m.channel == ctx.channel

    interface_msg = await bot.wait_for('message', check=check)
    interface = interface_msg.content.strip()
    await ctx.send(f"```Capturing on selected Interfaces. waiting for public ip STUN packet```")

    # Execute tshark command
    command = f'"{tshark_path}" -i "{interface}" -f "udp" -Y "stun.type == 0x0101 && stun.att.type == 0x0020 && stun.att.ipv4 != {public_ip}" -T fields -e stun.att.ipv4'
    output = subprocess.check_output(command, shell=True).decode('utf-8')
    
    await ctx.send(f"Capturing IP Dump:\n{output}")

@bot.command()
async def setprefix(ctx, new_prefix):
    global prefix
    if new_prefix.lower() == "none":
        prefix = ""  # Set prefix to nothing
        await ctx.send("```Prefix removed. Commands can now be used without a prefix.```")
    else:
        prefix = new_prefix
        await ctx.send(f"```Prefix changed to: {new_prefix}```")


locked_name = None

@bot.command()
async def lock(ctx, *, name: str):
    global locked_name
    locked_name = name
    await ctx.message.delete()
    await ctx.send(f"```Group chat name locked to: {locked_name}```", delete_after=3)
    await enforce_lock(ctx)

@bot.command()
async def unlock(ctx):
    global locked_name
    locked_name = None
    await ctx.send("```Group chat name unlocked```", delete_after=3)

async def enforce_lock(ctx):
    global locked_name
    while locked_name:
        try:
            # Check if the group chat name is different from the locked name
            if ctx.channel.name != locked_name:
                await ctx.channel.edit(name=locked_name)
            await asyncio.sleep(0)  # Zero delay
        except discord.Forbidden:
            await ctx.send("I do not have permission to change the group chat name.")
            break
        except discord.HTTPException as e:
            await ctx.send(f"An error occurred: {e}")
            break
        except Exception as e:
            await ctx.send(f"An unexpected error occurred: {e}")
            break


@bot.command()
async def lol(ctx, user: discord.User):
    try:
        if user:
            await ctx.message.delete()
            await lOl_user(ctx.channel, user)
        else:
            await ctx.send("User not found.")
    except Exception as e:
        await ctx.send(f"An error occurred: {e}")

async def lOl_user(channel, user):
    try:
        await channel.send(f"HOLY{user.mention}")
        await asyncio.sleep(0.615)
        await channel.send(f"# LOLOLOLOLOL{user.mention}")
        await asyncio.sleep(0.08135)
        await channel.send(f"# UR DYINGH{user.mention}")
        await asyncio.sleep(0.6156)
        await channel.send(f"# TOOOO{user.mention}")
        await asyncio.sleep(0.7156)
        await channel.send(f"# FUCKIGN {user.mention}")
        await asyncio.sleep(0.4156)
        await channel.send(f"# MANUAL{user.mention}")
        await asyncio.sleep(0.61456)
        await channel.send(f" LADDER{user.mention}")
        await asyncio.sleep(0.8)
        await channel.send(f"# DONTT {user.mention}")
        await asyncio.sleep(0.5)
        await channel.send(f" STPE{user.mention}")
        await asyncio.sleep(0.4)
        await channel.send(f"# TO{user.mention}")
        await asyncio.sleep(0.41495)
        await channel.send(f"# yur{user.mention}")
        await asyncio.sleep(0.81452)
        await channel.send(f"# GOD LOLOL{user.mention}")
        await asyncio.sleep(1.211)
        await channel.send(f"# WE CAN MANUAL FOR HOURS?{user.mention}")
        await asyncio.sleep(0.6145)
        await channel.send(f"# DAYS?{user.mention}")
        await asyncio.sleep(0.51442)
        await channel.send(f"# WEEKS?{user.mention}")
        await asyncio.sleep(0.7142)
        await channel.send(f"# MONTHS{user.mention}")
        await asyncio.sleep(1.21)
        await channel.send(f"# FUCK  RAPED UNIGGER BOY{user.mention}")
        await asyncio.sleep(0.61424)
        await channel.send(f"# HOLY {user.mention}")
        await asyncio.sleep(0.51424)
        await channel.send(f"ur{user.mention}")
        await asyncio.sleep(0.8531)
        await channel.send(f"Gettng{user.mention}")
        await asyncio.sleep(0.4021)
        await channel.send(f"out{user.mention}")
        await asyncio.sleep(0.742)
        await channel.send(f"ladderedf{user.mention}")
        await asyncio.sleep(0.5342)
        await channel.send(f"TO{user.mention}")
        await asyncio.sleep(0.521)
        await channel.send(f"fcuckk{user.mention}")
    except Exception as e:
        await channel.send(f"An error occurred: {e}")

@bot.command(name="caption")
async def caption(ctx, image_url: str, *, text: str):
    """
    Adds top caption text to an image (meme style).
    Usage: $caption <direct image URL> <text here>

    Examples:
    $caption https://i.imgur.com/abc123.jpg CORNBALL VS COUGHING BABY
    $caption https://... "PACKGOD VS DOHERTY" "very sunday"
    """
    async with ctx.typing():
        try:
            # Download image
            async with aiohttp.ClientSession() as session:
                async with session.get(image_url) as resp:
                    if resp.status != 200:
                        return await ctx.send("Couldn't download the image — check the URL?")
                    content_type = resp.headers.get('Content-Type', '')
                    if not content_type.startswith('image/'):
                        return await ctx.send("That link doesn't look like an image.")
                    img_data = await resp.read()

            # Open and prepare image
            img = Image.open(io.BytesIO(img_data)).convert("RGBA")
            
            # Resize if too big (keeps aspect, max width 1000)
            max_width = 1000
            if img.width > max_width:
                ratio = max_width / img.width
                new_size = (max_width, int(img.height * ratio))
                img = img.resize(new_size, Image.Resampling.LANCZOS)

            w, h = img.size

            # Create canvas with extra space on top for caption
            padding_top = 120          # adjust this for more/less space
            canvas = Image.new("RGBA", (w, h + padding_top), (0, 0, 0, 255))  # black background
            canvas.paste(img, (0, padding_top))

            # Draw text
            draw = ImageDraw.Draw(canvas)

            # Try to load a good impact-style font
            # Fallback: use default if you don't have impact.ttf
            try:
                font_path = "impact.ttf"  # put impact.ttf in same folder as bot script
                font_size = 80
                font = ImageFont.truetype(font_path, font_size)
            except:
                font = ImageFont.load_default()
                font_size = 50  # default font is tiny

            # Wrap text if too long
            max_chars_per_line = 30
            lines = []
            for line in wrap(text.upper(), width=max_chars_per_line):
                lines.append(line)

            # Calculate text block height
            line_height = font_size + 10
            total_text_height = len(lines) * line_height
            y_start = (padding_top - total_text_height) // 2 + 10  # center vertically in top padding

            for i, line in enumerate(lines):
                # Get text size (new way in recent Pillow)
                bbox = draw.textbbox((0, 0), line, font=font)
                text_w = bbox[2] - bbox[0]
                text_h = bbox[3] - bbox[1]

                x = (w - text_w) // 2
                y = y_start + i * line_height

                # Black outline (stroke)
                outline_range = 3
                for dx in range(-outline_range, outline_range + 1):
                    for dy in range(-outline_range, outline_range + 1):
                        if dx != 0 or dy != 0:
                            draw.text((x + dx, y + dy), line, font=font, fill="black")

                # White fill
                draw.text((x, y), line, font=font, fill="white")

            # Save to bytes
            bio = io.BytesIO()
            canvas.save(bio, format="PNG")
            bio.seek(0)

            file = discord.File(bio, filename="captioned.png")
            await ctx.send(file=file)

        except Exception as e:
            print(f"Error in caption command: {e}")
            await ctx.send("Something broke while making the caption 😭 Try a smaller image or shorter text?")

# You can adjust these or make them parameters later
BUBBLE_COLOR = (0, 0, 0)      
TAIL_SIZE = 120
BUBBLE_PADDING = 60                # how much empty space around the image

@bot.command(name="speechbubble")
async def speechbubble(ctx, image_url: str, togif: str = "off"):
    """
    Adds a speech bubble effect around an image.
    Usage: $speechbubble <direct image url> [togif/on/off]
    
    Example:
    $speechbubble https://i.imgur.com/abc123.jpg
    $speechbubble https://... on    ← outputs animated GIF
    """
    # Normalize flag
    make_gif = togif.lower() in ("on", "true", "yes", "gif")

    async with ctx.typing():
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(image_url) as resp:
                    if resp.status != 200:
                        return await ctx.send("Could not download the image (bad URL or not found).")
                    if resp.headers.get('Content-Type', '').startswith('image/') is False:
                        return await ctx.send("Link doesn't seem to point to an image.")
                    
                    img_data = await resp.read()
            
            # Open image with Pillow
            img = Image.open(io.BytesIO(img_data)).convert("RGBA")
            
            # Optional: make it a bit smaller if huge (you can remove/adjust)
            img.thumbnail((900, 900), Image.Resampling.LANCZOS)
            
            w, h = img.size
            
            # Create canvas bigger than image
            canvas_w = w + BUBBLE_PADDING * 2
            canvas_h = h + BUBBLE_PADDING * 2 + TAIL_SIZE + 30  # extra for tail
            
            canvas = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
          
            
            # Paste original image in center-top area
            paste_x = (canvas_w - w) // 2
            paste_y = BUBBLE_PADDING
            canvas.paste(img, (paste_x, paste_y), img)
            
            # Create speech bubble tail (simple triangle)
            tail = Image.new("RGBA", (TAIL_SIZE * 2, TAIL_SIZE), (0,0,0,0))
            draw = ImageDraw.Draw(tail)
            
            points = [
                (TAIL_SIZE, 0),                     # top point
                (0, TAIL_SIZE * 1.3),               # left bottom
                (TAIL_SIZE * 2, TAIL_SIZE * 1.3)    # right bottom
            ]
            draw.polygon(points, fill=BUBBLE_COLOR + (255,))
            
            # Paste tail (centered-ish under image)
            tail_x = paste_x + w // 2 - TAIL_SIZE
            tail_y = paste_y + h + 10
            canvas.paste(tail, (tail_x, tail_y), tail)
            
            # Optional rounded corners on the whole thing (looks nicer)
            canvas = ImageOps.expand(canvas, border=30, fill=BUBBLE_COLOR)
            mask = Image.new("L", canvas.size, 0)
            draw = ImageDraw.Draw(mask)
            draw.rounded_rectangle((0,0) + canvas.size, radius=60, fill=255)
            canvas.putalpha(mask)
            
            # Prepare output
            output_format = "GIF" if make_gif else "PNG"
            filename = f"speechbubble.{'gif' if make_gif else 'png'}"
            
            bio = io.BytesIO()
            canvas.save(bio, format=output_format, save_all=True if make_gif else None)
            bio.seek(0)
            
            file = discord.File(bio, filename=filename)
            await ctx.send(file=file)
            
        except Exception as e:
            print(e)  # log for you
            await ctx.send("Something went wrong while processing the image 😅 Try a different image?")

@bot.command()
async def bomber(ctx, user: discord.User):
    percentage = random.randint(1, 100)
    await ctx.send(f"{user.mention} is {percentage}% arabic. Bomber FUCK. LMFAO, keep bombing those towers for Osama bin Laden..")
@bot.command()
async def rapemom(ctx, user: discord.User):
    try:
        if user:
            await ctx.message.delete()
            await bangmom_user(ctx.channel, user)
        else:
            await ctx.send("User not found.")
    except Exception as e:
        await ctx.send(f"An error occurred: {e}")

async def bangmom_user(channel, user):
    try:
        await channel.send(f"LOL IM FUCKING {user.mention}'S MOTHER LOL HER PUSSY IS AMAZING")
        await asyncio.sleep(0.1)
        await channel.send(f"{user.mention} HER PUSSY IS SO GOOD OH MYY")
        await asyncio.sleep(0.1)
        await channel.send(f"{user.mention} **I SMACKED THE SHIT OUT OF HER ASS** 😈")
        await asyncio.sleep(0.1)
        await channel.send(f"{user.mention} **MADE HER PUSSY SLOPPY**")
        await asyncio.sleep(0.1)
        await channel.send(f"{user.mention} **GET SAD I DONT CARE BITCH*")
        await asyncio.sleep(0.1)
        await channel.send(f"{user.mention} **FUCKIN HELL SHE LASTED A LONG TIME**")
        await asyncio.sleep(0.1)
        await channel.send(f"{user.mention} **IM UR STEP-DAD NOW CALL ME DADDY FUCK**")
        await asyncio.sleep(0.1)
        await channel.send(f"{user.mention} **IM UR GOD**")
        await asyncio.sleep(0.1)
        await channel.send(f"{user.mention} **UR MY SLAVE NOW**")
        await asyncio.sleep(0.1)
        await channel.send(f"{user.mention} **SHITTY FUCK LOL**")
    except Exception as e:
        await channel.send(f"An error occurred: {e}")



@bot.command()
async def rape(ctx, user: discord.User):
    await ctx.message.delete()
    await ctx.send(f"Hey cutie kitten {user.mention}")  
    await ctx.send('my dearest kitten')
    await ctx.send('you have been running from ur daddy for too long.')
    await ctx.send('*slowly whips large meat out*')
    await ctx.send('get down on ur little knees my princess, daddy is mad.')
    await ctx.send('shhhh *puts fingers in mouth*')
    await ctx.send('*slowly pulls kittens pants down*')
    await ctx.send('are u ready for this big load my kitten?')
    await ctx.send('*puts fingers inside kittens tight little pussy')
    await ctx.send('mmm u like that right?')
    await ctx.send('moan for ur daddy')
    await ctx.send('good little princess')
    await ctx.send('*puts dick inside kittens ass*')
    await ctx.send('oops wrong hole i guess ill just keep it in there')
    await ctx.send('*keeps going while fingering kittens tight pussy*')
    await ctx.send('oh yeaa cum for your daddy')
    await ctx.send('wdym no? ARE U DISOBEYING DADDY?')
    await ctx.send('*starts pounding harder and rougher*')
    await ctx.send('yea thats what u get')
    await ctx.send('*sees blood coming out*')
    await ctx.send('good little kitten thats what u get')
    await ctx.send('*pulls out and licks the blood off the ass*')
    await ctx.send('mmmmm yea squirm for daddy')
    await ctx.send('*sticks bloody dick in kittens pussy*')
    await ctx.send('mmmmhmmm yea how does my little kitten like that')
    await ctx.send('*cum for daddy right now ugly little slut*')
    await ctx.send('did u just say no? are u disobeying me again... ykw?')
    await ctx.send('*for disobeying me fucks harder*')
    await ctx.send('beg me to stop fucking u harder')
    await ctx.send('*cums in that smooth pussy*')
@bot.command()
async def autism(ctx, user: discord.User):
    percentage = random.randint(1, 100)
    await ctx.send(f"{user.mention} has {percentage}% Autism")

@bot.command()
async def rizz(ctx, user: discord.User):
    percentage = random.randint(1, 100)
    await ctx.send(f"{user.mention} has {percentage}% rizz. dont believe this shit. if its high it's lying u got 0% rizz fuck ass nigga.")

@bot.command()
async def comboy(ctx, user: discord.User):
    percentage = random.randint(1, 100)
    await ctx.send(f"{user.mention} is {percentage}% of a Comboy u weird ass nigga kys")

@bot.command()
async def nigger(ctx, user: discord.User):
    percentage = random.randint(1000, 10000)
    await ctx.send(f"{user.mention} is {percentage}% nigger, nigga ur fucking lowtier 😭😭")
@bot.command()
async def eboy(ctx, user: discord.User):
    percentage = random.randint(1, 100)
    await ctx.send(f"{user.mention} is {percentage}% of a Eboy ur lonely nigga get a job")

@bot.command()
async def egirl(ctx, user: discord.User):
    percentage = random.randint(1, 100)
    await ctx.send(f"{user.mention} is {percentage}% of a egirl, you slut LMFAO")


@bot.command()
async def edater(ctx, user: discord.User):
    percentage = random.randint(1, 100)
    await ctx.send(f"{user.mention} is {percentage}% edater, nigga ur a e dater\n ?? get a job u lonely nigga")


@bot.command()
async def skid(ctx, user: discord.User):
    percentage = random.randint(10000, 9999999)
    await ctx.send(f"{user.mention} is {percentage}% skidder, nigga go learn how to code Hail Tool\n ur a retarded skid??")    

@bot.command()
async def spiderdick(ctx):
    await ctx.message.delete
    await ctx.send("Top 10 Most Useless Backflips")
    await ctx.send(f'https://media.discordapp.net/attachments/919335494473621564/1100693907605557309/spiderman.gif?ex=667a7a15&is=66792895&hm=c13c551563f7ba4a0876ce29ee10836ec996ba714b14c7a74d0c7c8dbcf4868d&')

@bot.command()
async def catboy(ctx):
    await ctx.send("cums on the sleeping catboy I hope he wouldn't mind...\n>////<\nthe catboy wakes up\nhe then forces his little mouseboy to bed in a pronebone position bad mousy... you spilled some on my socks...\n~`//^// ~\nthe catboy puts it in ngaaah...!! ~\n-nyaaa...~ hah~ g-good... boy...~ purr\nohh... f-fuck... ~ I... I love you...! ~\n-unyaaa...~ you... too...!! ~ the catboy paces up each thrust\n-mrrps from pleasure cu- c-cumming...~\nsqueaks from climactic pleasure uuu...~ smooch")

@bot.command()
async def jews(ctx):
    await ctx.message.delete()
    await ctx.send("YOUR ALL FUCKING JEWS. GO FUCK YOURSELF")
    await ctx.send("https://www.gtvflyers.com/wp-content/uploads/2023/08/Every-Single-Aspect-of-Disney-is-Jewish-1.jpg")

@bot.command()
async def swat(ctx, user: discord.Member = None):
    if user is None:
        user = ctx.author

    gender = ["Male", "Female", "Non-Binary", "Other"]
    age = str(random.randint(18, 50))
    height = ['5\'5\"', '5\'8\"', '6\'0\"', '6\'2\"']
    location = ["1305 Tarragon Dr Flower Mound, Texas(TX), 75028", "28261 W Thome Rd Rock Falls, Illinois(IL), 61071", "1508 2nd St NW Bowman, North Dakota(ND), 58623", "60 Gertrude Rd Dalton, Massachusetts(MA), 01226",]
    occupation = ["Software Engineer", "Artist", "Teacher", "Chef"]
    name = ['Alex Johnson', 'Jamie Lee', 'Taylor Smith', 'Jordan Brown', 'Alice Jordan', 'Kaylee Brown', 'Jesse Sowders']

    await ctx.send(f"swatting {user.mention}...\n")
    await asyncio.sleep(1)

    await ctx.send(f"```📞 *9-1-1: Hello, what is ur emergency*```")
    await asyncio.sleep(1)

    await ctx.send(f"{user.mention} my name is {random.choice(name)} i am very scared my parents were fighting and then i heard a big band like a bomb. . . .")
    await asyncio.sleep(1)
    
    await ctx.send(f"📞 okay calm down and get somewhere safe were do you live?")
    await asyncio.sleep(1)

    await ctx.send(f"i- i live at {random.choice(location)} please hurrry ")
    await asyncio.sleep(1)

    await ctx.send(f"📞 SWAT is coming shortly remain safe we will arrive soon")
    await asyncio.sleep(1)


    await ctx.send(f"🚓 SWAT: starts breaking down {user.mention} door ")
    await asyncio.sleep(1)

    await ctx.send(f"https://media.discordapp.net/attachments/1310177406732075101/1312274470504890421/b9b7b37cb0cf5e495d6512d30c56a4fb.gif?ex=674be656&is=674a94d6&hm=139874281c9b4d402eab13afd0669cd07505a18147aea95fa75277706ca32da5&=")
    await asyncio.sleep(1)
                        
    await ctx.send(f"🚓 SWAT: YOUR UNDERARRESTRED {user.mention}  ")
    await asyncio.sleep(1)

    await ctx.send(f"🚓 SWAT: targets {user.mention}")
    await asyncio.sleep(1)

    await ctx.send(f"{user.mention} I DIDN'T DO ANYTHING HELP \n")
    await asyncio.sleep(1)

    await ctx.send(f"🚓 SWAT: GET DOWN ON THE FLOOR {user.mention}")
    await asyncio.sleep(1)

    await ctx.send(f"{user.mention} I DIDNT DO ANYTHING HELP \n")
    await asyncio.sleep(1)


    await ctx.send(f"*🚓 SWAT: locks up {user.mention}*")
    await asyncio.sleep(1)

    await ctx.send(f"Successfully swatted {user.mention} \n")
    await asyncio.sleep(1)
    
    await ctx.send(f"```Details:```"
                   f"```Name: {random.choice(name)}\n"
                   f"Gender: {random.choice(gender)}\n"
                   f"Age: {age}\n"
                   f"Height: {random.choice(height)}\n"
                   f"Location: {random.choice(location)}\n"
                   f"Occupation: {random.choice(occupation)}\n```")
    


@bot.command()
async def hack(ctx, user: discord.Member=None):
    await ctx.message.delete()
    gender = ["Male", "Female", "Trans", "Other", "Retard"]
    age = str(random.randrange(10, 25))
    height = ['4\'6\"', '4\'7\"', '4\'8\"', '4\'9\"', '4\'10\"', '4\'11\"', '5\'0\"', '5\'1\"', '5\'2\"', '5\'3\"',
              '5\'4\"', '5\'5\"',
              '5\'6\"', '5\'7\"', '5\'8\"', '5\'9\"', '5\'10\"', '5\'11\"', '6\'0\"', '6\'1\"', '6\'2\"', '6\'3\"',
              '6\'4\"', '6\'5\"',
              '6\'6\"', '6\'7\"', '6\'8\"', '6\'9\"', '6\'10\"', '6\'11\"']
    weight = str(random.randrange(60, 300))
    hair_color = ["Black", "Brown", "Blonde", "White", "Gray", "Red"]
    skin_color = ["White", "Pale", "Brown", "Black", "Light-Skin"]
    religion = ["Christian", "Muslim", "Atheist", "Hindu", "Buddhist", "Jewish"]
    sexuality = ["Straight", "Gay", "Homo", "Bi", "Bi-Sexual", "Lesbian", "Pansexual"]
    education = ["High School", "College", "Middle School", "Elementary School", "Pre School",
                 "Retard never went to school LOL"]
    ethnicity = ["White", "African American", "Asian", "Latino", "Latina", "American", "Mexican", "Korean", "Chinese",
                 "Arab", "Italian", "Puerto Rican", "Non-Hispanic", "Russian", "Canadian", "European", "Indian"]
    occupation = ["Retard has no job LOL", "Certified discord retard", "Janitor", "Police Officer", "Teacher",
                  "Cashier", "Clerk", "Waiter", "Waitress", "Grocery Bagger", "Retailer", "Sales-Person", "Artist",
                  "Singer", "Rapper", "Trapper", "Discord Thug", "Gangster", "Discord Packer", "Mechanic", "Carpenter",
                  "Electrician", "Lawyer", "Doctor", "Programmer", "Software Engineer", "Scientist"]
    salary = ["Retard makes no money LOL", "$" + str(random.randrange(0, 1000)), '<$50,000', '<$75,000', "$100,000",
              "$125,000", "$150,000", "$175,000",
              "$200,000+"]
    location = ["Retard lives in his mom's basement LOL", "America", "United States", "Europe", "Poland", "Mexico",
                "Russia", "Pakistan", "India",
                "Some random third world country", "Canada", "Alabama", "Alaska", "Arizona", "Arkansas", "California",
                "Colorado", "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana",
                "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan",
                "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey",
                "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon",
                "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah",
                "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"]
    email = ["@gmail.com", "@yahoo.com", "@hotmail.com", "@outlook.com", "@protonmail.com", "@disposablemail.com",
             "@aol.com", "@edu.com", "@icloud.com", "@gmx.net", "@yandex.com"]
    dob = f'{random.randrange(1, 13)}/{random.randrange(1, 32)}/{random.randrange(1950, 2021)}'
    name = ['James Smith', "Michael Smith", "Robert Smith", "Maria Garcia", "David Smith", "Maria Rodriguez",
            "Mary Smith", "Maria Hernandez", "Maria Martinez", "James Johnson", "Catherine Smoaks", "Cindi Emerick",
            "Trudie Peasley", "Josie Dowler", "Jefferey Amon", "Kyung Kernan", "Lola Barreiro",
            "Barabara Nuss", "Lien Barmore", "Donnell Kuhlmann", "Geoffrey Torre", "Allan Craft",
            "Elvira Lucien", "Jeanelle Orem", "Shantelle Lige", "Chassidy Reinhardt", "Adam Delange",
            "Anabel Rini", "Delbert Kruse", "Celeste Baumeister", "Jon Flanary", "Danette Uhler", "Xochitl Parton",
            "Derek Hetrick", "Chasity Hedge", "Antonia Gonsoulin", "Tod Kinkead", "Chastity Lazar", "Jazmin Aumick",
            "Janet Slusser", "Junita Cagle", "Stepanie Blandford", "Lang Schaff", "Kaila Bier", "Ezra Battey",
            "Bart Maddux", "Shiloh Raulston", "Carrie Kimber", "Zack Polite", "Marni Larson", "Justa Spear"]
    phone = f'({random.randrange(0, 10)}{random.randrange(0, 10)}{random.randrange(0, 10)})-{random.randrange(0, 10)}{random.randrange(0, 10)}{random.randrange(0, 10)}-{random.randrange(0, 10)}{random.randrange(0, 10)}{random.randrange(0, 10)}{random.randrange(0, 10)}'
    if user is None:
        user = ctx.author
        password = ['password', '123', 'mypasswordispassword', user.name + "iscool123", user.name + "isdaddy",
                    "daddy" + user.name, "ilovediscord", "i<3discord", "furryporn456", "secret", "123456789", "apple49",
                    "redskins32", "princess", "dragon", "password1", "1q2w3e4r", "ilovefurries"]
        message = await ctx.send(f"`Hacking {user}...\n`")
        await asyncio.sleep(1)
        await message.edit(content=f"`Hacking {user}...\nHacking into the mainframe...\n`")
        await asyncio.sleep(1)
        await message.edit(content=f"`Hacking {user}...\nHacking into the mainframe...\nCaching data...`")
        await asyncio.sleep(1)
        await message.edit(
            content=f"`Hacking {user}...\nHacking into the mainframe...\nCaching data...\nCracking SSN information...\n`")
        await asyncio.sleep(1)
        await message.edit(
            content=f"`Hacking {user}...\nHacking into the mainframe...\nCaching data...\nCracking SSN information...\nBruteforcing love life details...`")
        await asyncio.sleep(1)
        await message.edit(
            content=f"`Hacking {user}...\nHacking into the mainframe...\nCaching data...\nCracking SSN information...\nBruteforcing love life details...\nFinalizing life-span dox details\n`")
        await asyncio.sleep(1)
        await message.edit(
            content=f"```Successfully hacked {user}\nName: {random.choice(name)}\nGender: {random.choice(gender)}\nAge: {age}\nHeight: {random.choice(height)}\nWeight: {weight}\nHair Color: {random.choice(hair_color)}\nSkin Color: {random.choice(skin_color)}\nDOB: {dob}\nLocation: {random.choice(location)}\nPhone: {phone}\nE-Mail: {user.name + random.choice(email)}\nPasswords: {random.choices(password, k=3)}\nOccupation: {random.choice(occupation)}\nAnnual Salary: {random.choice(salary)}\nEthnicity: {random.choice(ethnicity)}\nReligion: {random.choice(religion)}\nSexuality: {random.choice(sexuality)}\nEducation: {random.choice(education)}```")
    else:
        password = ['password', '123', 'mypasswordispassword', user.name + "iscool123", user.name + "isdaddy",
                    "daddy" + user.name, "ilovediscord", "i<3discord", "furryporn456", "secret", "123456789", "apple49",
                    "redskins32", "princess", "dragon", "password1", "1q2w3e4r", "ilovefurries"]
        message = await ctx.send(f"`Hacking {user}...\n`")
        await asyncio.sleep(1)
        await message.edit(content=f"`Hacking {user}...\nHacking into the mainframe...\n`")
        await asyncio.sleep(1)
        await message.edit(content=f"`Hacking {user}...\nHacking into the mainframe...\nCaching data...`")
        await asyncio.sleep(1)
        await message.edit(
            content=f"`Hacking {user}...\nHacking into the mainframe...\nCaching data...\nCracking SSN information...\n`")
        await asyncio.sleep(1)
        await message.edit(
            content=f"`Hacking {user}...\nHacking into the mainframe...\nCaching data...\nCracking SSN information...\nBruteforcing love life details...`")
        await asyncio.sleep(1)
        await message.edit(
            content=f"`Hacking {user}...\nHacking into the mainframe...\nCaching data...\nCracking SSN information...\nBruteforcing love life details...\nFinalizing life-span dox details\n`")
        await asyncio.sleep(1)
        await message.edit(
    content=f"```Successfully hacked {user}\n"
            f"Name: {random.choice(name)}\n"
            f"Gender: {random.choice(gender)}\n"
            f"Age: {age}\n"
            f"Height: {random.choice(height)}\n"
            f"Weight: {weight}\n"
            f"Hair Color: {random.choice(hair_color)}\n"
            f"Skin Color: {random.choice(skin_color)}\n"
            f"DOB: {dob}\n"
            f"Location: {random.choice(location)}\n"
            f"Phone: {phone}\n"
            f"E-Mail: {user.name + random.choice(email)}\n"
            f"Passwords: {', '.join(random.choices(password, k=3))}\n"
            f"Occupation: {random.choice(occupation)}\n"
            f"Annual Salary: {random.choice(salary)}\n"
            f"Ethnicity: {random.choice(ethnicity)}\n"
            f"Religion: {random.choice(religion)}\n"
            f"Sexuality: {random.choice(sexuality)}\n"
            f"Education: {random.choice(education)}\n"
            "```"
)

@bot.command()
async def wife(ctx):
    await ctx.send(f"https://cdn.discordapp.com/attachments/1395225282490667072/1415540751990919299/da3663c176a175053a93bee0a91553e1.gif?ex=68c3948e&is=68c2430e&hm=c3edee1686f1482c42bad7eef2324f1592d21ebd6cb39890541577c6c24863a7&")
    await ctx.send(f"```this is my wife right here fuck nigga```")
    await ctx.message.delete()
    

@bot.command()
async def dick(ctx, member: discord.Member = None):
    member = member or ctx.author

    length = random.randint(1, 20)

    pp_string = "3" + "=" * length + "D"

    await ctx.send(f"```{pp_string} {member.mention}  {length} inches```")
    await ctx.message.delete()

@bot.command() 
async def gay(ctx, member: discord.Member = None):
    if member is None:
        await ctx.send("```mention a user```")
        return

    gay_percent = random.randint(1, 100) 
    response = f"`{member.mention} is {gay_percent}% gay ur a gay nigger wtf`"
    await ctx.send(response)
    await ctx.message.delete()


@bot.command(aliases=["pornhubcomment", 'phc'])
async def phcomment(ctx, user: discord.User = None, *, args=None):
    await ctx.message.delete()
    if user is None or args is None:
        await ctx.send(f'[ERROR]: Invalid input! Command: phcomment <user> <message>')
        return

    avatar_url = user.avatar_url_as(format="png")

    endpoint = f"https://nekobot.xyz/api/imagegen?type=phcomment&text={args}&username={user.name}&image={avatar_url}"
    r = requests.get(endpoint)
    res = r.json()

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(res["message"]) as resp:
                image = await resp.read()
        with io.BytesIO(image) as file:
            await ctx.send(file=discord.File(file, f"{user.name}_pornhub_comment.png"))
    except Exception as e:
        await ctx.send(f"An error occurred: {str(e)}")

@bot.command()
async def tweet(ctx, username: str = None, *, message: str = None):
    await ctx.message.delete()
    if username is None or message is None:
        await ctx.send("missing parameters")
        return
    async with aiohttp.ClientSession() as cs:
        async with cs.get(f"https://nekobot.xyz/api/imagegen?type=tweet&username={username}&text={message}") as r:
            res = await r.json()
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(str(res['message'])) as resp:
                        image = await resp.read()
                with io.BytesIO(image) as file:
                    await ctx.send(file=discord.File(file, f"exeter_tweet.png"))
            except:
                await ctx.send(res['message'])  

status_rotation_active = False
emoji_rotation_active = False
current_status = ""
current_emoji = ""

@bot.command(name='astatus')
async def rotate_status(ctx, *, statuses: str):
    global status_rotation_active, current_status, current_emoji
    await ctx.message.delete()
    
    status_list = [s.strip() for s in statuses.split(',')]
    
    if not status_list:
        await ctx.send("```Please separate statuses by commas.```", delete_after=3)
        return
    
    current_index = 0
    status_rotation_active = True
    
    async def update_status_emoji():
        json_data = {
            'custom_status': {
                'text': current_status,
                'emoji_name': current_emoji
            }
        }

        custom_emoji_match = re.match(r'<a?:(\w+):(\d+)>', current_emoji)
        if custom_emoji_match:
            name, emoji_id = custom_emoji_match.groups()
            json_data['custom_status']['emoji_name'] = name
            json_data['custom_status']['emoji_id'] = emoji_id
        else:
            json_data['custom_status']['emoji_name'] = current_emoji

        async with aiohttp.ClientSession() as session:
            try:
                async with session.patch(
                    'https://discord.com/api/v9/users/@me/settings',
                    headers={'Authorization': bot.http.token, 'Content-Type': 'application/json'},
                    json=json_data
                ) as resp:
                    await resp.read()
            finally:
                await session.close()

    await ctx.send(f"```Status rotation started```")
    
    try:
        while status_rotation_active:
            current_status = status_list[current_index]
            await update_status_emoji()
            await asyncio.sleep(8)
            current_index = (current_index + 1) % len(status_list)
                
    finally:
        current_status = ""
        await update_status_emoji()
        status_rotation_active = False

@bot.command(name='aemoji')
async def rotate_emoji(ctx, *, emojis: str):
    global emoji_rotation_active, current_emoji, status_rotation_active
    await ctx.message.delete()
    

    emoji_list = emojis.split()
    
    if not emoji_list:
        await ctx.send("```Please provide emojis separated by spaces.```", delete_after=3)
        return
    
    current_index = 0
    emoji_rotation_active = True
    
    async def update_status_emoji():
        json_data = {
            'custom_status': {
                'text': current_status,
                'emoji_name': current_emoji
            }
        }
        
        custom_emoji_match = re.match(r'<a?:(\w+):(\d+)>', current_emoji)
        if custom_emoji_match:
            name, emoji_id = custom_emoji_match.groups()
            json_data['custom_status']['emoji_name'] = name
            json_data['custom_status']['emoji_id'] = emoji_id
        else:
            json_data['custom_status']['emoji_name'] = current_emoji

        async with aiohttp.ClientSession() as session:
            try:
                async with session.patch(
                    'https://discord.com/api/v9/users/@me/settings',
                    headers={'Authorization': bot.http.token, 'Content-Type': 'application/json'},
                    json=json_data
                ) as resp:
                    await resp.read()
            finally:
                await session.close()

    await ctx.send(f"```Emoji rotation started```")
    
    try:
        while emoji_rotation_active:
            current_emoji = emoji_list[current_index]
            await update_status_emoji()
            await asyncio.sleep(8)
            current_index = (current_index + 1) % len(emoji_list)
                
    finally:
        current_emoji = ""
        await update_status_emoji()
        emoji_rotation_active = False

@bot.command(name='astatusoff')
async def stop_rotate_status(ctx):
    global status_rotation_active
    status_rotation_active = False
    await ctx.send("```Status rotation stopped.```", delete_after=3)

@bot.command(name='aemojioff')
async def stop_rotate_emoji(ctx):
    global emoji_rotation_active
    emoji_rotation_active = False
    await ctx.send("```Emoji rotation stopped.```", delete_after=3)
# POPOUT / AUTOPASTER MUTLI TOKEN


bump_task = None
@bot.command()
async def ab(ctx):
    global bump_task
    
    if bump_task is not None:
        await ctx.send("```Auto bump is already running```")
        return
    headers = {
        "authority": "discord.com",
        "method": "PATCH",
        "scheme": "https",
        "accept": "*/*",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "en-US",
        "authorization": bot.http.token,
        "origin": "https://discord.com",
        "sec-ch-ua": '"Not/A)Brand";v="99", "Brave";v="115", "Chromium";v="115"',
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9020 Chrome/108.0.5359.215 Electron/22.3.26 Safari/537.36",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "X-Debug-Options": "bugReporterEnabled",
        "X-Discord-Locale": "en-US",
        "X-Discord-Timezone": "Asia/Calcutta",
        "X-Super-Properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxlYXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjEuMC45MDIwIiwib3NfdmVyc2lvbiI6IjEwLjAuMTkwNDUiLCJvc19hcmNoIjoieDY0IiwiYXBwX2FyY2giOiJpYTMyIiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV09XNjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIGRpc2NvcmQvMS4wLjkwMjAgQ2hyb21lLzEwOC4wLjUzNTkuMjE1IEVsZWN0cm9uLzIyLjMuMjYgU2FmYXJpLzUzNy4zNiIsImJyb3dzZXJfdmVyc2lvbiI6IjIyLjMuMjYiLCJjbGllbnRfYnVpbGRfbnVtYmVyIjoyNDAyMzcsIm5hdGl2ZV9idWlsZF9udW1iZXIiOjM4NTE3LCJjbGllbnRfZXZlbnRfc291cmNlIjpudWxsLCJkZXNpZ25faWQiOjB9"
    }

    payload = {
        "type": 2,
        "application_id": "302050872383242240", 
        "channel_id": str(ctx.channel.id),
        "guild_id": str(ctx.guild.id),
        "session_id": "".join(random.choices(string.ascii_letters + string.digits, k=32)),
        "data": {
            "version": "1051151064008769576", 
            "id": "947088344167366698",
            "name": "bump",
            "type": 1,
            "options": [],
            "application_command": {
                "id": "947088344167366698",
                "application_id": "302050872383242240", 
                "version": "1051151064008769576", 
                "name": "bump",
                "description": "Bump this server.", 
                "description_default": "Pushes your server to the top of all your server's tags and the front page",
                "dm_permission": True,
                "type": 1
            }
        }
    }

    async def bump():
        while True:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(
                        "https://discord.com/api/v9/interactions",
                        headers=headers,
                        json=payload
                    ) as resp:
                        if resp.status == 204:
                            print("Successfully bumped server")
                        else:
                            print(f"Failed to bump server: {resp.status}")
                
                await asyncio.sleep(7200) 
            except Exception as e:
                print(f"Error during bump: {e}")
                await asyncio.sleep(60)  

    await ctx.send("```Starting auto bump. run '.autobumpoff' to stop```")
    bump_task = bot.loop.create_task(bump())

@bot.command() 
async def aboff(ctx):
    global bump_task
    
    if bump_task is None:
        await ctx.send("```Auto bump is not currently running```")
        return
        
    bump_task.cancel()
    bump_task = None
    await ctx.send("```Auto bump stopped```")

spammingss = False

@bot.command()
async def spam(ctx, *, message: str):
    global spammingss
    spammingss = True 
    await ctx.send(f"```Starting spam of '{message}'. Use ,spamoff to stop.```")

    while spammingss:  
        await ctx.send(message) 
        await asyncio.sleep(0.05)


@bot.command()
async def spamoff(ctx):
    global spammingss
    spammingss = False 
    await ctx.send("```Spamming stopped.```")
editspamming = False


@bot.command()
async def cord(ctx, user: discord.User):
    global cord_mode, cord_user
    cord_mode = True
    cord_user = user
    await ctx.send(f"```cord mode enabled for {user.name}```")

@bot.command()
async def cordoff(ctx):
    global cord_mode, cord_user
    cord_mode = False
    cord_user = None
    await ctx.send("```cord mode disabled```")

mimic_user = None  

@bot.command()
async def mimic(ctx, user: discord.Member):
    global mimic_user
    mimic_user = user 
    await ctx.send(f"```Now mimicking {user.display_name}'s messages.```")


@bot.command()
async def mimicoff(ctx):
    global mimic_user
    mimic_user = None 
    await ctx.send("```Stopped mimicking messages.```")



afk_checking = False

@bot.command()
async def afkcheck(ctx, user: discord.User, count: int):
    global afk_checking
    if afk_checking:
        await ctx.send("```duck check is already running.```")
        return

    afk_checking = True
    await ctx.message.delete()

    for i in range(1, count + 1):
        if not afk_checking:
            await ctx.send("nga fuck u")
            return
        await ctx.send(f"{user.mention} | `{i}`")
        await asyncio.sleep(0)  # Adjust delay for spam speed

    afk_checking = False
    await ctx.send(f"ggs")
    await ctx.send(f"{user.mention} ur fucking loser fuck nigga kys")

duck_checking = False

@bot.command()
async def duckcheck(ctx, user: discord.User, count: int):
    global duck_checking
    if duck_checking:
        await ctx.send("```duck check is already running.```")
        return

    duck_checking = True
    await ctx.message.delete()

    for i in range(1, count + 1):
        if not duck_checking:
            await ctx.send("nga fuck u")
            return
        await ctx.send(f"yo faggot why ur ducking?????????? {user.mention} | `{i}`")
        await asyncio.sleep(0)  # Adjust delay for spam speed

    duck_checking = False
    await ctx.send(f"Ducked ez ez")
    await ctx.send(f"{user.mention} say i love raping my mom nga ur ducked scared kid LOLLOLOOLOL")

vc_checking = False

@bot.command()
async def vccheck(ctx, user: discord.User, count: int):
    global vc_checking
    if vc_checking:
        await ctx.send("```vc check is already running.```")
        return

    vc_checking = True
    await ctx.message.delete()

    for i in range(1, count + 1):
        if not vc_checking:
            await ctx.send("nga fuck u")
            return
        await ctx.send(f"{user.mention} | `{i}` ")
        await asyncio.sleep(0)  # Adjust delay for spam speed

    vc_checking = False
    await ctx.send(f"vc ducked LMFAO")
    await ctx.send(f"{user.mention} ```Folded to me nigga ur ass cant join vc```")

@bot.command()
async def pollspam(ctx, times: int = 5):
    global stopper
    stopper = False

    url = f"https://discord.com/api/v9/channels/{ctx.channel.id}/messages"
    headers = {
        "authorization": config['token'],  # Your user token (not bot)
        "x-super-properties": getxsuper(),
        "user-agent": "Mozilla/5.0",
        "content-type": "application/json"
    }

    poll_data = {
        "content": "",
        "tts": False,
        "poll": {
            "question": {"text": "$RAIDED$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"},
            "duration": 24,  # 1h
            "layout_type": 1,
            "allow_multiselect": True,
            "answers": [
                {"poll_media": {"text": "LOLOLOL"}},
                {"poll_media": {"text": "XXXXXXXXXXXXXXXXXXX"}},
                {"poll_media": {"text": "LOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOL"}}
            ]
        }
    }

    for i in range(times):
        if stopper:
            break
        requests.post(url=url, headers=headers, json=poll_data)
        await asyncio.sleep(0)


@bot.command()
async def raid(ctx):
    await ctx.message.delete()
    guild = ctx.guild

    message_templates = ["# LMAOOOOOOOOOOOO", "# @everyone RAID3D BY BLUE MOON X REI CLIENT", "```SEIZED```", "discord.gg/dvh"]

    for _ in range(5):  # Repeat 5 times
        for channel in guild.text_channels:
            try:
                await channel.send(random.choice(message_templates))
                msg = await channel.send("@everyone")

                # Optional: react if desired
                if random.randint(0, 2) == 1:
                    for emoji in ['💔', '🔪', '😭']:  # Example emojis
                        await msg.add_reaction(emoji)
            except Exception:
                continue


nukedchannels = "OWNED BY ONATOR"
nukedchannels2 = "/ONATOR #WE WAS HERE"
nukedchannels3 = "LMAOO"
nukedchannelname = "SHITTY ASS SERVER GOT S31Z3D"
nukedchannelname2 = "WE OWN THIS"
nukedchannelname3 = "LMAO"
nukedchannelname4 = "CRY FAGGOT"

@bot.command()#negro
async def seize(ctx):
    guild = ctx.guild
    await ctx.send(f"{prefix}rgld")
    await ctx.message.delete()

    for emoji in ctx.guild.emojis:
        await emoji.delete()
        print(f"{emoji.name} has been deleted in {ctx.guild.name}")
    for member in ctx.guild.members:      
        try:
            await member.edit(nick="E X E C U T E D")
        except discord.Forbidden:
            print(f"{member.name} has NOT been renamed to in {ctx.guild.name}")
        else:
            print(f"{member.name} has been renamed to in {ctx.guild.name}")
          
    print(f'{guild.name}')
    for channel in list(ctx.guild.channels):
        await channel.delete()
        await ctx.guild.create_text_channel(name=nukedchannels)
        await ctx.guild.create_text_channel(name=nukedchannels2)
        await ctx.guild.create_text_channel(name=nukedchannels)
        await ctx.guild.create_text_channel(name=nukedchannels2)
        await ctx.guild.create_text_channel(name=nukedchannels3)
        await ctx.guild.create_text_channel(name=nukedchannels3)
        await ctx.guild.create_text_channel(name="https://discord.gg/hentai")
        await ctx.guild.create_text_channel(name="L O L")
        await ctx.guild.create_role(name="NO E$CAPE")

@bot.command()
async def rgld(ctx):
            await ctx.message.delete()
            await ctx.guild.edit(name=nukedchannelname)
            await ctx.guild.edit(name=nukedchannelname2)
            await ctx.guild.edit(name=nukedchannelname3)
            await ctx.guild.edit(name=nukedchannelname4)
            while True:
                await ctx.guild.edit(name=nukedchannelname2)
                await ctx.guild.edit(name=nukedchannelname3)
                await ctx.guild.edit(name=nukedchannelname4)
                await ctx.guild.edit(name="ONATOR WAS HERE")
                await ctx.guild.edit(name="LOL")

@bot.command(aliases=["masschannels", "masschannel"])
async def ctc(ctx):
    await ctx.message.delete()
    for _i in range(50):
        try:
            await ctx.guild.create_text_channel(name="onator-was-here")
        except:
            return

@bot.command(aliases=["massvoicechannels", "massvoicechannel"])
async def cvc(ctx):
    await ctx.message.delete()
    for _i in range(50):
        try:
            await ctx.guild.create_voice_channel(name="NO-MERCY-LOL")
        except:
            return

@bot.command(aliases=["r204ekt"])
async def delc(ctx):
    await ctx.message.delete()
    for channel in list(ctx.guild.channels):
        try:
            await channel.delete()
        except:
            pass

@bot.command(aliases=["rekt"])
async def karma(ctx):
    await ctx.message.delete()
    for channel in list(ctx.guild.channels):
        try:
            await channel.delete()
        except:
            pass
    try:
        await ctx.guild.edit(
            name="KARMA No Mercy",
            description="wow so corny",
            reason="you so corny omg",
            icon="https://cdn.discordapp.com/attachments/1299281530845138976/1372910620193853561/b8bdbfda32ad7ce23315e99484b52223.png?ex=68287e27&is=68272ca7&hm=cabebba6e0fa0de060c71ffa5ee447cbb9a02c581082d71525588f785215d930&",
            banner=None
        )
    except:
        pass
    for _i in range(40):
        await ctx.guild.create_text_channel(name="niggers-blue-moon-on-top")

@bot.command()
async def ping(ctx):
    latency = bot.latency
    await ctx.send(f"""```
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣤⣴⠶⠶⠶⠶⠦⣤⣤⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣶⠾⠟⣿⣿⠾⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠙⠻⢶⣤⣠⣤⣤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡾⠟⠉⠀⠀⠸⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⢷⣀⠈⠙⠻⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡾⠋⠀⠀⠀⢀⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣧⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⠏⠀⠀⠀⠀⢠⡿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡀⠀⠀⠀⠈⠻⣦⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⡟⠁⠀⠀⠀⠀⢀⡿⠁⠀⠀⣰⣶⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣄⠀⠀⠀⠀⠀⢿⡀⠀⠀⠀⠀⠀⠙⠷⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣀⣴⠟⠋⠀⠀⠀⠀⠀⠀⣼⠇⠀⠀⠐⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⣿⣿⡇⠀⠀⠀⠀⢸⣇⠀⠀⠀⠀⠀⠀⠀⠈⠙⠳⣦⣄⡀⠀⠀⠀⠀⠀
⠀⠀⠀⣀⣴⠾⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⢿⡇⠉⠁⠉⠈⠉⠀⠀⠀⠀⠀⠀⣠⢤⣀⠀⠀⠀⠀⠀⠉⠿⠿⠁⡀⠀⠀⠀⢸⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠻⢶⣄⠀⠀⠀
⠀⣠⡾⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣷⣄⠤⠠⠐⢀⡀⠀⠀⠀⠀⠀⠋⠁⠉⠁⠀⠀⠀⠀⠀⠄⠀⠀⠀⢁⠀⠀⣼⢿⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣷⡄⠀
⢠⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡟⠻⢶⣤⣴⡾⠷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣦⣤⠀⠜⣀⣴⠟⠈⢿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣷⠀
⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡿⠁⠀⠀⣿⠃⠀⠀⢸⡟⠳⠶⠶⠶⢦⣶⣴⣶⣴⣶⣶⣿⠉⠀⠹⣷⣿⣿⣥⣄⡀⠀⢻⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇
⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⠟⠁⠀⠀⠀⢿⣆⣠⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠳⠀⢀⣿⠟⠉⠉⠉⠛⣷⡄⠙⢷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⠇
⠘⢷⣄⡀⠀⠀⠀⠀⠀⠀⢀⣠⣴⠟⠃⠀⠀⠀⠀⠀⠀⣼⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰⠶⠿⣷⡀⠀⠀⣀⠀⠈⣿⡄⠀⠙⢷⣄⡀⠀⠀⠀⠀⠀⠀⣀⣼⠏⠀
⠀⠀⠉⠛⠷⠶⠶⠶⠶⠾⠛⠋⠁⠀⠀⠀⠀⠀⠀⠀⣸⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣧⣤⣴⠏⠀⠀⣽⡇⠀⠀⠀⠈⠛⠿⠶⠶⠶⠶⠿⠋⠁⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⡇⠀⣠⣤⣄⠀⠀⠀⠀⠀⠀⠀⣀⣀⡀⠀⠀⠀⠀⠀⣼⡇⠀⠀⠀⠀⣴⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣷⡾⠋⠀⠁⠀⠀⠀⠀⠀⢀⣾⠛⠉⠙⠓⠀⠀⢀⣴⠟⠛⠿⠾⠿⠛⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣷⠀⠀⠐⢶⣶⣶⣶⣶⣾⣿⡀⠀⠀⢶⡶⠛⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣧⣀⣠⡿⠁⠀⠀⠀⠀⢹⣇⡀⣠⡾⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠁⠀⠀⠀⠀⠀⠀⠀⠙⠛⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                      [ PING ]
                      {round(latency * 1000)}ms
```""")

start_time = datetime.datetime.utcnow()


@bot.command()
async def uptime(ctx):
    now = datetime.datetime.utcnow()
    delta = now - start_time
    days, remainder = divmod(int(delta.total_seconds()), 86400)
    hours, remainder = divmod(remainder, 3600)
    minutes, seconds = divmod(remainder, 60)
    await ctx.send(f"""```ansi
⠤⣤⣤⣤⣄⣀⣀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣠⣤⠤⠤⠴⠶⠶⠶⠶
⢠⣤⣤⡄⣤⣤⣤⠄⣀⠉⣉⣙⠒⠤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠴⠘⣉⢡⣤⡤⠐⣶⡆⢶⠀⣶⣶⡦
⣄⢻⣿⣧⠻⠇⠋⠀⠋⠀⢘⣿⢳⣦⣌⠳⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠞⣡⣴⣧⠻⣄⢸⣿⣿⡟⢁⡻⣸⣿⡿⠁
⠈⠃⠙⢿⣧⣙⠶⣿⣿⡷⢘⣡⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⣿⣷⣝⡳⠶⠶⠾⣛⣵⡿⠋⠀⠀
⠀⠀⠀⠀⠉⠻⣿⣶⠂⠘⠛⠛⠛⢛⡛⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠛⠀⠉⠒⠛⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⢸⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣾⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢻⡁⠀⠀⠀⠀⠀⢸     [ uptime ]
⠀⠀⠀⠀⠀⠀⠘⡇⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀ ⠀⠀⠀⠿
{days} days 

{hours} hours 

{minutes} minutes 

{seconds} second
```""")

guild_rotation_task = None
guild_rotation_delay = 2.0  

@bot.group(invoke_without_command=True)
async def rtag(ctx, delay: float = 2.0):
    global guild_rotation_task, guild_rotation_delay
    
    if guild_rotation_task and not guild_rotation_task.cancelled():
        await ctx.send("```tag rotation is already running```")
        return
        
    if delay < 1.0:
        await ctx.send("```tag must be at least 1 second```")
        return
        
    guild_rotation_delay = delay
    
    async def rotate_guilds():
        headers = {
            "authority": "canary.discord.com",
            "accept": "*/*",
            "accept-language": "en-US,en;q=0.9",
            "authorization": bot.http.token,
            "content-type": "application/json",
            "origin": "https://canary.discord.com",
            "referer": "https://canary.discord.com/channels/@me",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "x-super-properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEyMC4wLjAuMCBTYWZhcmkvNTM3LjM2IiwiYnJvd3Nlcl92ZXJzaW9uIjoiMTIwLjAuMC4wIiwib3NfdmVyc2lvbiI6IjEwIiwicmVmZXJyZXIiOiIiLCJyZWZlcnJpbmdfZG9tYWluIjoiIiwicmVmZXJyZXJfY3VycmVudCI6IiIsInJlZmVycmluZ19kb21haW5fY3VycmVudCI6IiIsInJlbGVhc2VfY2hhbm5lbCI6InN0YWJsZSIsImNsaWVudF9idWlsZF9udW1iZXIiOjI1MDgzNiwiY2xpZW50X2V2ZW50X3NvdXJjZSI6bnVsbH0="
        }
        
        while True:
            try:
                async with aiohttp.ClientSession() as session:
                    valid_guild_ids = []
                    
                    async with session.get(
                        'https://canary.discord.com/api/v9/users/@me/guilds',
                        headers=headers
                    ) as guild_resp:
                        if guild_resp.status != 200:
                            await ctx.send("```Failed to fetch guilds```")
                            return
                        
                        guilds = await guild_resp.json()
                        
                        for guild in guilds:
                            test_payload = {
                                'identity_guild_id': guild['id'],
                                'identity_enabled': True
                            }
                            
                            async with session.put(
                                'https://canary.discord.com/api/v9/users/@me/clan',
                                headers=headers,
                                json=test_payload
                            ) as test_resp:
                                if test_resp.status == 200:
                                    valid_guild_ids.append(guild['id'])
                        
                        if not valid_guild_ids:
                            await ctx.send("```No tag found```")
                            return
                            
                        await ctx.send(f"```Found {len(valid_guild_ids)} tags```")
                        
                        while True:
                            for guild_id in valid_guild_ids:
                                payload = {
                                    'identity_guild_id': guild_id,
                                    'identity_enabled': True
                                }
                                async with session.put(
                                    'https://canary.discord.com/api/v9/users/@me/clan',
                                    headers=headers,
                                    json=payload
                                ) as put_resp:
                                    if put_resp.status == 200:
                                        await asyncio.sleep(guild_rotation_delay)
                            
            except asyncio.CancelledError:
                raise
            except Exception as e:
                print(f"Error in guild rotation: {e}")
                await asyncio.sleep(5)
    
    guild_rotation_task = asyncio.create_task(rotate_guilds())
    await ctx.send(f"```Started tag rotation (Delay: {delay}s)```")

@rtag.command(name="stop")
async def rotateguild_stop(ctx):    
    global guild_rotation_task
    
    if guild_rotation_task and not guild_rotation_task.cancelled():
        guild_rotation_task.cancel()
        guild_rotation_task = None
        await ctx.send("```Stopped clan rotation```")
    else:
        await ctx.send("```Clan rotation is not running```")

@rtag.command(name="delay")
async def rotateguild_delay(ctx, delay: float):
    global guild_rotation_delay
    
    if delay < 1.0:
        await ctx.send("```Delay must be at least 1 second```")
        return
        
    guild_rotation_delay = delay
    await ctx.send(f"```tag rotation delay set to {delay}s```")

@rtag.command(name="status")
async def rotateguild_status(ctx):
    status = "running" if (guild_rotation_task and not guild_rotation_task.cancelled()) else "stopped"
    await ctx.send(f"""```
tag Rotation Status:
• Status: {status}
• Delay: {guild_rotation_delay}s
```""")

murder_task = False
@bot.command()
async def murderoff(ctx: commands.Context):
    global murder_task

    if murder_task and not murder_task.done():
        murder_task.cancel()
        murder_task = None
        await ctx.send("```murder stopped```")
    else:
        try:
            await ctx.message.delete()
        except:
            pass
def load_murder():
    path = "thrax.txt"
    if not os.path.isfile(path):
        return ["thrax.txt not found."]
    
    with open(path, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]

@bot.command()
async def murder(ctx: commands.Context, user: discord.User = None):
    global murder_task
    target = user
    manual = load_murder()

    try:
        await ctx.message.delete()
    except discord.Forbidden:
        pass

    await ctx.send(
        f"# {target.mention} nigga want to get murdered LOLOL",
        allowed_mentions=discord.AllowedMentions(users=True)
    )

    async def send_murder():
        try:
            for line in manual:
                message = f"{target.mention} {line}"
                try:
                    await ctx.send(message, allowed_mentions=discord.AllowedMentions(users=True))
                except discord.Forbidden:
                    await ctx.author.send(message)

                await asyncio.sleep(random.uniform(0.1, 0))


            await ctx.send(f"TS NIGGA GOT MURDERED BY GOD LOL")

        except asyncio.CancelledError:
            pass
        except Exception as e:
            print(f"Error during wrath: {e}")
            pass

    murder_task = asyncio.create_task(send_murder())


court_task = None

def load_court():
    path = "court.txt"
    if not os.path.isfile(path):
        return ["court.txt not found."]
    
    with open(path, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]

@bot.command(name='court') 
async def court(ctx: commands.Context, user: discord.User = None):
    global court_task

    target = user
    manual = load_court()

    try:
        await ctx.message.delete()
    except discord.Forbidden:
        pass

    await ctx.send(
        f"# yo lets me flame ts nigga {target.mention} until i die",
        allowed_mentions=discord.AllowedMentions(users=True)
    )

    async def send_court():
        try:
            for line in manual:
                # Typing effect
                async with ctx.typing():
                    await asyncio.sleep(random.uniform(1.1, 1.5))

                message = f"{target.mention} {line}"

                try:
                    await ctx.send(message, allowed_mentions=discord.AllowedMentions(users=True))
                except discord.Forbidden:
                    await ctx.author.send(message)

                await asyncio.sleep(random.uniform(0.6, 1.5))


            await ctx.send(f"gg you folded")

        except asyncio.CancelledError:
            pass
        except Exception as e:
            print(f"Error during court: {e}")
            pass

    court_task = asyncio.create_task(send_court())

@bot.command(name='courtoff')
async def stopcourt(ctx: commands.Context):
    global court_task

    if court_task and not court_task.done():
        court_task.cancel()
        court_task = None
        await ctx.send("ggs")
    else:
        try:
            await ctx.message.delete()
        except:
            pass


@bot.command()
async def catfact(ctx):
    async with aiohttp.ClientSession() as session:
        async with session.get("https://catfact.ninja/fact") as resp:
            data = await resp.json()
            await ctx.send(data["fact"])
@bot.command()
async def cat(ctx):
    await ctx.message.delete()
    response = requests.get('https://api.thecatapi.com/v1/images/search')
    if response.status_code == 200:
        data = response.json()
        if data:
            cat_image_url = data[0]['url']
            await ctx.send(cat_image_url)
        else:
            await ctx.send('```ansi\n[30mcould not retrieve a cat image.```')
    else:
        await ctx.send('```ansi\n[30mFailed to fetch cat image.```')

@bot.command()  # thigh
async def thigh(ctx):
    await ctx.message.delete()

    request = requests.get(f'https://nekobot.xyz/api/image?type=thigh')
    data = request.json()
    link = data['message']

    await ctx.send(link)


# ────────────────────────────────────────────────
#  Waifu.im NSFW categories that usually work
# ────────────────────────────────────────────────
NSFW_CATEGORIES = [
    "ass", "blowjob", "boobs", "cum", "cunnilingus", "ero", "feet", "femdom",
    "futa", "handjob", "hentai", "loli", "milf", "oral", "pussy", "tentacle", "thigh", "yaoi", "yuri"
]

# ────────────────────────────────────────────────
#  Helper to get random NSFW image from waifu.im
# ────────────────────────────────────────────────
def get_nsfw_image(tag="hentai"):
    try:
        url = f"https://api.waifu.im/random/?many=false&gif=false&nsfw=true&tag={tag}"
        r = requests.get(url)
        if r.status_code == 200:
            data = r.json()
            return data["images"][0]["url"]
        else:
            return "https://i.waifu.im/error.png"  # fallback
    except:
        return "https://i.waifu.im/error.png"


# ────────────────────────────────────────────────
#  Generic NSFW action command template
# ────────────────────────────────────────────────
async def nsfw_action(ctx, user: discord.User, action: str, category: str):
    if user == ctx.author:
        await ctx.send(f"{ctx.author.mention} you can't {action} yourself silly nigga")
        return

    image = get_nsfw_image(category)

    msg = (
        f"{ctx.author.mention} **{action}** {user.mention} hard~\n"
        f"{user.mention} is getting **fucked** so good right now..."
    )

    await ctx.send(msg)
    await ctx.send(image)


# ────────────────────────────────────────────────
#  Commands
# ────────────────────────────────────────────────
@bot.command()
async def fuck(ctx, user: discord.User):
    await nsfw_action(ctx, user, "fucks", random.choice(["hentai", "ero", "pussy", "ass"]))

@bot.command()
async def blowjob(ctx, user: discord.User):
    await nsfw_action(ctx, user, "gives a sloppy blowjob to", "blowjob")

@bot.command()
async def handjob(ctx, user: discord.User):
    await nsfw_action(ctx, user, "jerks off", "handjob")

@bot.command()
async def cum(ctx, user: discord.User):
    await nsfw_action(ctx, user, "cums all over", "cum")

@bot.command()
async def dickride(ctx, user: discord.User):
    await nsfw_action(ctx, user, "rides the dick of", random.choice(["hentai", "ero", "pussy"]))

@bot.command()
async def masturbate(ctx, user: discord.User = None):
    if user is None:
        # solo
        image = get_nsfw_image(random.choice(["masturbation", "hentai", "ero"]))
        await ctx.send(f"{ctx.author.mention} is **touching herself** so lewdly~ 💦", file=discord.File(image))
    else:
        await nsfw_action(ctx, user, "masturbates while watching", "masturbation")

@bot.command(name="kiss")
async def kiss(ctx, user: discord.User = None):
    if not user:
        await ctx.send("```You need to mention someone to kiss!```")
        return

    gif_url = await fetch_anime_gif("kiss")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} sends an anime kiss to {user.display_name}! 💋```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime kiss GIF right now, try again later!```")
@bot.command(name="slap")
async def slap(ctx, user: discord.User = None):
    if not user:
        await ctx.send("```You need to mention someone to slap!```")
        return

    gif_url = await fetch_anime_gif("slap")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} slaps {user.display_name}! 👋```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime slap GIF right now, try again later!```")


@bot.command(name="hurt")
async def hurt(ctx, user: discord.User = None):
    if not user:
        await ctx.send("```You need to mention someone to kill!```")
        return

    gif_url = await fetch_anime_gif("kill")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} kills {user.display_name}! ☠```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime kill GIF right now, try again later!```")

@bot.command(name="pat")
async def pat(ctx, user: discord.User = None):
    if not user:
        await ctx.send("```You need to mention someone to pat!```")
        return

    gif_url = await fetch_anime_gif("pat")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} pats {user.display_name}! 🖐```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime pat GIF right now, try again later!```")

@bot.command(name="wave")
async def wave(ctx, user: discord.User = None):
    if not user:
        await ctx.send("```You need to mention someone to wave at!```")
        return

    gif_url = await fetch_anime_gif("wave")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} waves at {user.display_name}! 👋```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime wave GIF right now, try again later!```")

@bot.command(name="hug")
async def hug(ctx, user: discord.User = None):
    if not user:
        await ctx.send("```You need to mention someone to hug!```")
        return

    gif_url = await fetch_anime_gif("hug")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} hugs {user.display_name}! 🤗```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime hug GIF right now, try again later!```")

@bot.command(name="cuddle")
async def cuddle(ctx, user: discord.User = None):
    if not user:
        await ctx.send("```You need to mention someone to cuddle!```")
        return

    gif_url = await fetch_anime_gif("cuddle")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} cuddles {user.display_name}! 🤗```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime cuddle GIF right now, try again later!```")

@bot.command(name="lick")
async def lick(ctx, user: discord.User = None):
    if not user:
        await ctx.send("```You need to mention someone to lick!```")
        return

    gif_url = await fetch_anime_gif("lick")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} licks {user.display_name}! 😋```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime lick GIF right now, try again later!```")

@bot.command(name="bite")
async def bite(ctx, user: discord.User = None):
    if not user:
        await ctx.send("```You need to mention someone to bite!```")
        return

    gif_url = await fetch_anime_gif("bite")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} bites {user.display_name}! 🐍```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime bite GIF right now, try again later!```")

@bot.command(name="bully")
async def bully(ctx, user: discord.User = None):
    if not user:
        await ctx.send("```You need to mention someone to bully!```")
        return

    gif_url = await fetch_anime_gif("bully")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} bullies {user.display_name}! 😠```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime bully GIF right now, try again later!```")

@bot.command(name="poke")
async def poke(ctx, user: discord.User = None):
    if not user:
        await ctx.send("```You need to mention someone to poke!```")
        return

    gif_url = await fetch_anime_gif("poke")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} pokes {user.display_name}! 👉👈```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime poke GIF right now, try again later!```")


@bot.command(name="dance")
async def dance(ctx):
    gif_url = await fetch_anime_gif("dance")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} dances! 💃```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime dance GIF right now, try again later!```")

@bot.command(name="cry")
async def cry(ctx):
    gif_url = await fetch_anime_gif("cry")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} is crying! 😢```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime cry GIF right now, try again later!```")

@bot.command(name="sleep")
async def sleep(ctx):
    gif_url = await fetch_anime_gif("sleep")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} is sleeping! 😴```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime sleep GIF right now, try again later!```")

@bot.command(name="blush")
async def blush(ctx):
    gif_url = await fetch_anime_gif("blush")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} just blushed.! 😊```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime blush GIF right now, try again later!```")

@bot.command(name="wink")
async def wink(ctx):
    gif_url = await fetch_anime_gif("wink")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} winks! 😉```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime wink GIF right now, try again later!```")

@bot.command(name="smile")
async def smile(ctx):
    gif_url = await fetch_anime_gif("smile")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} smiles! 😊```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime smile GIF right now, try again later!```")


@bot.command(name="highfive")
async def highfive(ctx, user: discord.User = None):
    if not user:
        await ctx.send("```You need to mention someone to high-five!```")
        return

    gif_url = await fetch_anime_gif("highfive")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} high-fives {user.display_name}! 🙌```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime high-five GIF right now, try again later!```")

@bot.command(name="handhold")
async def handhold(ctx, user: discord.User = None):
    if not user:
        await ctx.send("```You need to mention someone to hold hands with!```")
        return

    gif_url = await fetch_anime_gif("handhold")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} holds hands with {user.display_name}! 🤝```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime handhold GIF right now, try again later!```")

@bot.command(name="nom")
async def nom(ctx, user: discord.User = None):
    if not user:
        await ctx.send("```You need to mention someone to nom!```")
        return

    gif_url = await fetch_anime_gif("nom")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} noms on {user.display_name}! 😋```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime nom GIF right now, try again later!```")

@bot.command(name="smug")
async def smug(ctx):
    gif_url = await fetch_anime_gif("smug")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} has a smug look! 😏```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime smug GIF right now, try again later!```")

@bot.command(name="bonk")
async def bonk(ctx, user: discord.User = None):
    if not user:
        await ctx.send("```You need to mention someone to bonk!```")
        return

    gif_url = await fetch_anime_gif("bonk")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} bonks {user.display_name}! 🤭```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime bonk GIF right now, try again later!```")

@bot.command(name="yeet")
async def yeet(ctx, user: discord.User = None):
    if not user:
        await ctx.send("```You need to mention someone to yeet!```")
        return

    gif_url = await fetch_anime_gif("yeet")

    if gif_url:
        await ctx.send(f"```{ctx.author.display_name} yeets {user.display_name}! 💨```\n[REI]({gif_url})")
    else:
        await ctx.send("```Couldn't fetch an anime yeet GIF right now, try again later!```")


async def fetch_anime_gif(action):
    async with aiohttp.ClientSession() as session:
        async with session.get(f"https://api.waifu.pics/sfw/{action}") as r:
            if r.status == 200:
                data = await r.json()
                return data['url']  
            else:
                return None


@bot.command(name="ecchi")
async def ecchi(ctx, user: discord.User = None):
    
    async with aiohttp.ClientSession() as session:
        async with session.get('https://api.waifu.im/search/?included_tags=ecchi&is_nsfw=true') as response:
            if response.status == 200:
                data = await response.json()
                image_url = data['images'][0]['url']
                await ctx.send(f"```{ctx.author.display_name} shares some ecchi```\n[REI 🌸]({image_url})")
            else:
                await ctx.send("```Failed to fetch image, try again later!```")

@bot.command(name="hentai")
async def hentai(ctx, user: discord.User = None):
    
    async with aiohttp.ClientSession() as session:
        async with session.get('https://api.waifu.im/search/?included_tags=hentai&is_nsfw=true') as response:
            if response.status == 200:
                data = await response.json()
                image_url = data['images'][0]['url']
                await ctx.send(f"```{ctx.author.display_name} shares some hentai```\n[REI 🌸sb]({image_url})")
            else:
                await ctx.send("```Failed to fetch image, try again later!```")

@bot.command(name="uniform")
async def uniform(ctx, user: discord.User = None):
    async with aiohttp.ClientSession() as session:
        async with session.get('https://api.waifu.im/search/?included_tags=uniform&is_nsfw=true') as response:
            if response.status == 200:
                data = await response.json()
                image_url = data['images'][0]['url']
                await ctx.send(f"```{ctx.author.display_name} shares some uniform content```\n[REI 🌸]({image_url})")
            else:
                await ctx.send("```Failed to fetch image, try again later!```")

@bot.command(name="maid")
async def maid(ctx, user: discord.User = None):
    async with aiohttp.ClientSession() as session:
        async with session.get('https://api.waifu.im/search/?included_tags=maid&is_nsfw=true') as response:
            if response.status == 200:
                data = await response.json()
                image_url = data['images'][0]['url']
                await ctx.send(f"```{ctx.author.display_name} shares some maid content```\n[REI 🌸]({image_url})")
            else:
                await ctx.send("```Failed to fetch image, try again later!```")

@bot.command(name="oppai")
async def oppai(ctx, user: discord.User = None):
    async with aiohttp.ClientSession() as session:
        async with session.get('https://api.waifu.im/search/?included_tags=oppai&is_nsfw=true') as response:
            if response.status == 200:
                data = await response.json()
                image_url = data['images'][0]['url']
                await ctx.send(f"```{ctx.author.display_name} shares some oppai content```\n[REI 🌸]({image_url})")
            else:
                await ctx.send("```Failed to fetch image, try again later!```")

@bot.command(name="selfies")
async def selfies(ctx, user: discord.User = None):
    async with aiohttp.ClientSession() as session:
        async with session.get('https://api.waifu.im/search/?included_tags=selfies&is_nsfw=true') as response:
            if response.status == 200:
                data = await response.json()
                image_url = data['images'][0]['url']
                await ctx.send(f"```{ctx.author.display_name} shares some selfies```\n[REI 🌸]({image_url})")
            else:
                await ctx.send("```Failed to fetch image, try again later!```")

@bot.command(name="raiden")
async def raiden(ctx, user: discord.User = None):
    async with aiohttp.ClientSession() as session:
        async with session.get('https://api.waifu.im/search/?included_tags=raiden-shogun&is_nsfw=true') as response:
            if response.status == 200:
                data = await response.json()
                image_url = data['images'][0]['url']
                await ctx.send(f"```{ctx.author.display_name} shares Raiden content```\n[REI 🌸]({image_url})")
            else:
                await ctx.send("```Failed to fetch image, try again later!```")

@bot.command(name="marin")
async def marin(ctx, user: discord.User = None):
    async with aiohttp.ClientSession() as session:
        async with session.get('https://api.waifu.im/search/?included_tags=marin-kitagawa&is_nsfw=true') as response:
            if response.status == 200:
                data = await response.json()
                image_url = data['images'][0]['url']
                await ctx.send(f"```{ctx.author.display_name} shares Marin content```\n[REI 🌸]({image_url})")
            else:
                await ctx.send("```Failed to fetch image, try again later!```")

@bot.command()
async def boobs(ctx):
    await ctx.message.delete()

    response = requests.get("https://nekobot.xyz/api/image?type=boobs")
    json_data = json.loads(response.text)
    url = json_data["message"]

    await ctx.channel.send(url)
    
    


        

@bot.command()
async def hboobs(ctx):
    await ctx.message.delete()

    
    response = requests.get("https://nekobot.xyz/api/image?type=hboobs")
    json_data = json.loads(response.text)
    url = json_data["message"]

    await ctx.channel.send(url)


@bot.command()
async def anal(ctx):
    await ctx.message.delete()

    
    response = requests.get("https://nekobot.xyz/api/image?type=anal")
    json_data = json.loads(response.text)
    url = json_data["message"]

    await ctx.channel.send(url)




@bot.command()
async def hanal(ctx):
    await ctx.message.delete()

    
    response = requests.get("https://nekobot.xyz/api/image?type=hanal")
    json_data = json.loads(response.text)
    url = json_data["message"]

    await ctx.channel.send(url)




@bot.command(name="4k")
async def caughtin4k(ctx):
    await ctx.message.delete()

    
    response = requests.get("https://nekobot.xyz/api/image?type=4k")
    json_data = json.loads(response.text)
    url = json_data["message"]

    await ctx.channel.send(url)

    


@bot.command()
async def gif(ctx):
    await ctx.message.delete()

    
    response = requests.get("https://nekobot.xyz/api/image?type=pgif")
    json_data = json.loads(response.text)
    url = json_data["message"]

    await ctx.channel.send(url)



@bot.command(description="Leaves all groups.")
async def gcleaveall(ctx):
    await ctx.message.edit(
        content=f"```Are you sure? Send y to confirm, anything else will cancel.```"
    )

    def check(m):
        return m.author == ctx.author and m.channel == ctx.channel

    try:
        msg = await bot.wait_for("message", check=check, timeout=30.0)
    except asyncio.TimeoutError:
        await ctx.message.edit(content=f"```Timed out. Please try again.```")
        return

    if msg.content.lower() == "y":
        await msg.delete()
        for dm in bot.private_channels:
            if dm.type == discord.ChannelType.group:
                try:
                    await dm.leave()
                except Exception as e:
                    print(e)
                    pass

                await asyncio.sleep(1)

        await ctx.message.edit(content=f"```Left all groups.```")
    else:
        await ctx.message.edit(content=f"```Cancelled.```")

Threads = []

@bot.command()
async def massthread(ctx, maxamount: int = 10):
    try:
        await ctx.message.delete()
    except:
        pass
    threads = []
    for i in range(maxamount):
        thread = Thread(target=MassThread, args=(
            ctx,
            maxamount,
        )).start()
        threads.append(thread)

@bot.command(help='Ladders messages')
async def lm(ctx, *, sentence: str):
    await ctx.message.delete()

    words = []
    current_word = ""
    in_quotes = False
    quote_char = ""

    for char in sentence:
        if char in ('"'):  # Detect the start or end of a quoted phrase
            if in_quotes and char == quote_char:
                in_quotes = False
                words.append(current_word.strip())
                current_word = ""
            elif not in_quotes:
                in_quotes = True
                quote_char = char
            else:
                current_word += char  # For mismatched quotes inside quotes
        elif char.isspace() and not in_quotes:  # Split on spaces outside quotes
            if current_word:
                words.append(current_word.strip())
                current_word = ""
        else:
            current_word += char

    if current_word:  # Add any remaining text as a word
        words.append(current_word.strip())

    # Send each parsed word or phrase separately
    i = 0
    while i < len(words):
        word = words[i]
        try:
            await ctx.send(word)
            await asyncio.sleep(0.000001)
            i += 1
        except discord.errors.HTTPException as e:
            print(f'Rate limit hit, retrying... Error : {e}')
            await asyncio.sleep(0)

self_gcname = [
    "your a loser",
    "yo faggot wake up",
    "yo {user} your my bitch",
    "idk you loser",
    "{user} come meet god for me",
    "ill pound your head in",
    "ill make you look unreconizable"
]

@bot.command()
async def ugc(ctx, user: discord.User):
    global ugc_task, unused_names

    if ugc_task is not None and not ugc_task.done():
        await ctx.send("```Group chat name changer is already running```")
        return

    if not isinstance(ctx.channel, discord.GroupChannel):
        await ctx.send("```This command can only be used in group chats```")
        return

    unused_names = list(self_gcname)

    async def name_changer():
        counter = 1
        while True:
            try:
                if not unused_names:
                    unused_names.extend(self_gcname)
                base_name = random.choice(unused_names)
                unused_names.remove(base_name)

                formatted = base_name.replace("{user}", user.name).replace("{UPuser}", user.name.upper())
                new_name = f"{formatted} {counter}"

                await ctx.channel._state.http.request(
                    discord.http.Route(
                        'PATCH',
                        '/channels/{channel_id}',
                        channel_id=ctx.channel.id
                    ),
                    json={'name': new_name}
                )

                counter += 1
                await asyncio.sleep(0.1)

            except discord.HTTPException as e:
                if e.code == 429:
                    retry_after = getattr(e, 'retry_after', 5)
                    await asyncio.sleep(retry_after)
                    continue
                await ctx.send(f"```HTTP Error: {e}```")
                break
            except asyncio.CancelledError:
                break
            except Exception as e:
                await ctx.send(f"```Unexpected Error: {e}```")
                break

    ugc_task = asyncio.create_task(name_changer())
    await ctx.send("```Group chat name changer started```")

@bot.command()
async def ugcoff(ctx):
    global ugc_task
    
    if ugc_task is None:
        await ctx.send("```Group chat name changer is not currently running```")
        return
        
    ugc_task.cancel()
    ugc_task = None
    await ctx.send("```Group chat name changer stopped```")



@bot.command()
async def sgc(ctx):

    await ctx.message.delete()
    await ctx.send("```Group chat name changer started```")

    global running


    running = True  # Start the renaming process

    try:
        # Get the channel from the context
        channel: discord.abc.GuildChannel = ctx.channel

        if channel is None:
            await ctx.send('Could not find the specified channel.')
            return

        # Read names from the file
        if not os.path.exists('gc.txt'):
            await ctx.send('The file gc.txt does not exist. gng create one')
            return

        with open('gc.txt', 'r') as file:
            names = [line.strip() for line in file if line.strip()]

        if not names:
            await ctx.send('No names found in gc.txt. gng.')
            return

        count = 0

        async def rename_channel():
            nonlocal count
            while running:
                new_name = f"{names[count % len(names)]} x{count}"
                try:
                    await channel.edit(name=new_name)
                except discord.Forbidden:
                    await ctx.send("I do not have permission to rename this channel.")
                    break
                except discord.HTTPException as http_error:
                    await ctx.send(f"HTTP error occurred: {http_error}")
                    break
                except Exception as e:
                    await ctx.send(f"Error renaming channel: {e}")
                    break
                count += 1

        # Use asyncio.gather to run rename_channel concurrently
        await asyncio.gather(rename_channel())

    except Exception as e:
        await ctx.send(f'An error occurred: {e}')
    finally:
        running = False  # Stop the renaming process

@bot.command()
async def sgcoff(ctx):


    await ctx.message.delete()
    global running

    running = False 
    await ctx.send("```Group chat name changer stopped```")


@bot.command()
async def autopin(ctx, user: discord.User):
    autopin_targets[ctx.channel.id] = user.id
    autopin_enabled.add(ctx.channel.id)
    await ctx.send(f"```now started auto pinning {user} message```")

@bot.command()
async def autopinoff(ctx):
    autopin_targets.pop(ctx.channel.id, None)
    autopin_enabled.discard(ctx.channel.id)
    await ctx.send("```Auto-pinning stopped```")



running2 = False
running = False
@bot.command()
async def execute(ctx, *args):

    await ctx.message.delete()
    await ctx.send("```fuck off nga``")

    global running2, outlast_active, outlast_task

    # Get the channel from the context
    channel: discord.abc.GuildChannel = ctx.channel

    if channel is None:
        await ctx.send('Could not find the specified channel.')
        return

    # Read names from the file
    if not os.path.exists('gc.txt'):
        await ctx.send('The file gc.txt does not exist. gng create one')
        return

    with open('gc.txt', 'r') as file:
        names = [line.strip() for line in file if line.strip()]

    if not names:
        await ctx.send('No names found in gc.txt. gng.')
        return

    count = 0

    async def rename_channel():
            nonlocal count
            while running2:
                new_name = f"{names[count % len(names)]} x{count}"
                try:
                    await channel.edit(name=new_name)
                except discord.Forbidden:
                    await ctx.send("I do not have permission to rename this channel.")
                    break
                except discord.HTTPException as http_error:
                    await ctx.send(f"HTTP error occurred: {http_error}")
                    break
                except Exception as e:
                    await ctx.send(f"Error renaming channel: {e}")
                    break
                count += 1

    
    if not args:
        await ctx.send("```Please mention a user or provide a valid user ID.```")
        return

    
    running2 = True  # Start the renaming process
    user_mentioned = None



    if len(args) == 1:
        arg = args[0]
        
        
        if arg.startswith("<@") and arg.endswith(">"):
            user_mentioned = arg  
        else:
          
            user_mentioned = f"<@{arg}>"

    if not user_mentioned:
        await ctx.send("```Could not resolve user mention or ID. Please try again.```")
        return

 
    if outlast_active:
        await ctx.send("```Outlast is already active```")
        return

   
    outlast_active = True

    async def outlast_messages():
        while outlast_active:
            try:
                response = random.choice(wordlist)

        
                await ctx.send(f"{response}\n{user_mentioned}")
                await ctx.pin()

                await asyncio.sleep(0.1)

            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Error: {e}")

    outlast_task = asyncio.create_task(outlast_messages())
    await asyncio.gather(rename_channel())

    running = False  # Stop the renaming process



@bot.command()
async def executeoff(ctx):


    await ctx.message.delete()
    global running2, outlast_active, outlast_task

    running2 = False 
    await ctx.send("```stopped```")

    if outlast_active:
        outlast_active = False
        if outlast_task:
            outlast_task.cancel()
            await ctx.send("```gg twin.```")

@bot.group(invoke_without_command=True)
async def autokill(ctx, user: discord.User = None):
    if ctx.invoked_subcommand is None:
        if not user:
            await ctx.send("```Please mention a user```")
            return
            
        user_id = str(ctx.author.id)
        if user_id not in autokill_messages or not autokill_messages[user_id]:
            await ctx.send("```No messages configured. Use $autokill add <message> to add messages```")
            return
            
        autokill_status[ctx.author.id] = {
            'running': True,
            'target': user
        }
        
        used_messages = set()
        messages_sent = 0
        
        print(f"\n=== Starting Autokill Command ===")
        print(f"Target User: {user.name}")
        
        async def send_message_group(channel):
            nonlocal used_messages, messages_sent
            
            available_messages = [msg for msg in autokill_messages[user_id] if msg not in used_messages]
            if not available_messages:
                used_messages.clear()
                available_messages = autokill_messages[user_id]
                print("\n=== Refreshing message list ===\n")
            
            message = random.choice(available_messages)
            used_messages.add(message)
            
            try:
                full_message = f"{user.mention} {message.replace('{username}', user.display_name)}"
                await channel.send(full_message)
                messages_sent += 1
                print(f"Message sent ({messages_sent}): {message}")
                
            except Exception as e:
                print(f"\nError sending message: {str(e)}")
        
        try:
            while (ctx.author.id in autokill_status and 
                autokill_status[ctx.author.id]['running']):
                
                available_channels = []
                
                for channel in ctx.guild.text_channels:
                    if channel.permissions_for(ctx.guild.me).send_messages:
                        available_channels.append(channel)
                
                if available_channels:
                    random.shuffle(available_channels)
                    
                    for channel in available_channels:
                        await send_message_group(channel)
                        await asyncio.sleep(random.uniform(1.5, 3.5))
                    
                    await asyncio.sleep(random.uniform(5, 10))
                
        finally:
            if ctx.author.id in autokill_status:
                autokill_status[ctx.author.id]['running'] = False
                del autokill_status[ctx.author.id]
        
        print("\n=== Autokill Stopped ===\n")

@autokill.command(name="add")
async def add_kill_message(ctx, *, message: str):
    user_id = str(ctx.author.id)
    if user_id not in autokill_messages:
        autokill_messages[user_id] = []
    
    autokill_messages[user_id].append(message)
    await ctx.send(f"```Added message: {message}```")
    save_kill_messages()

@autokill.command(name="remove")
async def remove_kill_message(ctx, index: int):
    user_id = str(ctx.author.id)
    if user_id not in autokill_messages or not autokill_messages[user_id]:
        await ctx.send("```No messages configured```")
        return
        
    if 1 <= index <= len(autokill_messages[user_id]):
        removed = autokill_messages[user_id].pop(index-1)
        await ctx.send(f"```Removed message: {removed}```")
        save_kill_messages()
    else:
        await ctx.send(f"```Invalid index. Use .autokill list to see message indices```")

@autokill.command(name="list")
async def list_kill_messages(ctx):
    user_id = str(ctx.author.id)
    if user_id not in autokill_messages or not autokill_messages[user_id]:
        await ctx.send("```No messages configured```")
        return
        
    message_list = "\n".join(f"{i+1}. {msg}" for i, msg in enumerate(autokill_messages[user_id]))
    await ctx.send(f"```Your configured messages:\n\n{message_list}```")

@autokill.command(name="clear")
async def clear_kill_messages(ctx):
    user_id = str(ctx.author.id)
    if user_id in autokill_messages:
        autokill_messages[user_id] = []
        await ctx.send("```Cleared all messages```")
        save_kill_messages()
    else:
        await ctx.send("```No messages configured```")

@autokill.command(name="stop")
async def stop_autokill(ctx):
    if ctx.author.id in autokill_status:
        autokill_status[ctx.author.id]['running'] = False
        del autokill_status[ctx.author.id]
        await ctx.send("```Stopped autokill```")
    else:
        await ctx.send("```Autokill is not running```")

def save_kill_messages():
    with open('autokill_config.json', 'w') as f:
        json.dump(autokill_messages, f)

def load_kill_messages():
    global autokill_messages
    try:
        with open('autokill_config.json', 'r') as f:
            autokill_messages = json.load(f)
    except FileNotFoundError:
        autokill_messages = {}


cord_user = False
cord_mode = False


@bot.command()
async def randomcatfact(ctx):
    async with aiohttp.ClientSession() as session:
        async with session.get("https://catfact.ninja/fact") as resp:
            data = await resp.json()
            await ctx.send(data["fact"])

anti_last_words = [
    "LAST WORD FOR",
    "LAST",
    "last word for",
    "Lasts for",
    "L A S T ",
    "L @ S T ",
    "LAASTT",
    "LASSTT",
    "LASTS",
    "LAST WORDED",
    "last word?",
    "last word",
    "any last word?"
]

antilast_enabled = False

antilast_data = {
    "whitelisted_users": set(),
    "whitelisted_channels": set(),
    "webhook_url": None
}

def save_antilast_data():
    with open('@antilast.json', 'w') as f:
        json.dump({
            "whitelisted_users": list(antilast_data["whitelisted_users"]),
            "whitelisted_channels": list(antilast_data["whitelisted_channels"]),
            "webhook_url": antilast_data["webhook_url"],
            "enabled": antilast_enabled
        }, f, indent=4)

def load_antilast_data():
    global antilast_enabled
    try:
        with open('@antilast.json', 'r') as f:
            data = json.load(f)
            antilast_data["whitelisted_users"] = set(data.get("whitelisted_users", []))
            antilast_data["whitelisted_channels"] = set(data.get("whitelisted_channels", []))
            antilast_data["webhook_url"] = data.get("webhook_url")
            antilast_enabled = data.get("enabled", False)
    except (FileNotFoundError, json.JSONDecodeError):

        antilast_data["whitelisted_users"] = set()
        antilast_data["whitelisted_channels"] = set()
        antilast_data["webhook_url"] = None
        antilast_enabled = False
        save_antilast_data()


@bot.group(invoke_without_command=True)
async def antilast(ctx):
    await ctx.send("""```
Anti Last Commands
antilast toggle <on/off>
antilast whitelist <id>
antilast channel <id>
antilast webhook <url>
antilast config
```""")

@antilast.command()
async def toggle(ctx, state: str = None):
    global antilast_enabled
    if state not in ['on', 'off']:
        await ctx.send("```Please choose 'on' or 'off'```")
        return
        
    antilast_enabled = state == 'on'
    save_antilast_data()
    await ctx.send(f"```Anti last word {state}```")

@antilast.command()
async def whitelist(ctx, user_id: str):
    antilast_data["whitelisted_users"].add(user_id)
    save_antilast_data()
    await ctx.send(f"```Added user {user_id} to whitelist```")

@antilast.command()
async def channel(ctx, channel_id: str):
    antilast_data["whitelisted_channels"].add(channel_id)
    save_antilast_data()
    await ctx.send(f"```Added channel {channel_id} to whitelist```")

@antilast.command()
async def webhook(ctx, webhook_url: str):
    antilast_data["webhook_url"] = webhook_url
    save_antilast_data()
    await ctx.send("```Updated webhook URL```")

@antilast.command()
async def config(ctx):
    config = f"""```
Antilast Configuration:
Whitelisted Users: {', '.join(antilast_data["whitelisted_users"]) or 'None'}
Whitelisted Channels: {', '.join(antilast_data["whitelisted_channels"]) or 'None'}
Webhook: {'Set' if antilast_data["webhook_url"] else 'Not Set'}```"""
    await ctx.send(config)

load_antilast_data()
anti_k_words = [
    "detoK",
    "detonatorK",
    "DETONATORK",
    "D E T O N A R O R K",
    "DETOK",
    "SOCIALK",
    "socialK",
    "S O C I A L K",
    "MIMIK",
    "mimiK",
    "M I M I K",
    "LAPPYK",
    "lappyK",
    "L A P P Y K",
    "REIK",
    "reiK",
    "R E I K",
    "66onatorK",
    "66ONATORK",
    "6 6 O N A T O R K",
    "K",
    "ONATORK",
    "onatorK",
    "O N A T O R K"
]

antik_enabled = False

antik_data = {
    "whitelisted_users": set(),
    "whitelisted_channels": set(),
    "webhook_url": None
}

def save_antik_data():
    with open('@antik.json', 'w') as f:
        json.dump({
            "whitelisted_users": list(antik_data["whitelisted_users"]),
            "whitelisted_channels": list(antik_data["whitelisted_channels"]),
            "webhook_url": antik_data["webhook_url"],
            "enabled": antik_enabled
        }, f, indent=4)

def load_antik_data():
    global antik_enabled
    try:
        with open('@antik.json', 'r') as f:
            data = json.load(f)
            antik_data["whitelisted_users"] = set(data.get("whitelisted_users", []))
            antik_data["whitelisted_channels"] = set(data.get("whitelisted_channels", []))
            antik_data["webhook_url"] = data.get("webhook_url")
            antik_enabled = data.get("enabled", False)
    except (FileNotFoundError, json.JSONDecodeError):

        antik_data["whitelisted_users"] = set()
        antik_data["whitelisted_channels"] = set()
        antik_data["webhook_url"] = None
        antik_enabled = False
        save_antik_data()


@bot.group(invoke_without_command=True)
async def antik(ctx):
    await ctx.send("""```
Antik K Commands
antik toggle <on/off>
antik whitelist <id>
antik channel <id>
antik webhook <url>
antik config
```""")

@antik.command()
async def toggle(ctx, state: str = None):
    global antilast_enabled
    if state not in ['on', 'off']:
        await ctx.send("```Please choose 'on' or 'off'```")
        return
        
    antilast_enabled = state == 'on'
    save_antilast_data()
    await ctx.send(f"```Anti last word {state}```")

@antik.command()
async def whitelist(ctx, user_id: str):
    antilast_data["whitelisted_users"].add(user_id)
    save_antilast_data()
    await ctx.send(f"```Added user {user_id} to whitelist```")

@antik.command()
async def channel(ctx, channel_id: str):
    antilast_data["whitelisted_channels"].add(channel_id)
    save_antilast_data()
    await ctx.send(f"```Added channel {channel_id} to whitelist```")

@antik.command()
async def webhook(ctx, webhook_url: str):
    antilast_data["webhook_url"] = webhook_url
    save_antilast_data()
    await ctx.send("```Updated webhook URL```")

@antik.command()
async def config(ctx):
    config = f"""```
Antik Configuration:
Whitelisted Users: {', '.join(antik_data["whitelisted_users"]) or 'None'}
Whitelisted Channels: {', '.join(antik_data["whitelisted_channels"]) or 'None'}
Webhook: {'Set' if antik_data["webhook_url"] else 'Not Set'}```"""
    await ctx.send(config)

load_antik_data()

bane = [
    "SHUT THE FUCKUP", "UR A BITCH", "LOL", "SHUT YO LAME ASS UP NIGGA",
    "DONT FOLD", "DORK ASS CUNT", "FUCK ASS BITCH",
    "SMD HEADASS NIGGA LMFAO UR WORTH NOTHING TO ME", "UR MY BITCH",
    "FUCK ASS NIGGA", "?", "UR MY SEED", "UR A HOE", "NIGGA U DIED TO ME",
    "IM FASTER THEN U SON", "UR A NERD", "🤓", "DONT STEP TO ME AGAIN",
    "NIGGA FOLDED TO ME", "PIPE THE FUCK DOWN", "I OWN U SON", "UR SLOW",
    "UR A BITCH", "LMFAO", "I DONT KNOW U", "FUCK ASS CUNT", "NIGGA TRIED STEPPING",
    "HOW DID U GET HOED LIKE THAT", "DUMB ASS BITCH", "I DONT FOLD",
    "SHUT THE FUCK UP", "TRY STEPPING AGAIN", "UR A BITCH",
    "DUMB ASS NIGGA", "DUMB ASS BITCH THOUGHT HE COULD STEP",
    "DO SUM LMFAO I RULE U", "SIGN UR LIFE AWAY TO LAP", "I DONT FOLD ILL GO FOREVER",
    "WHY RU DUCKING?", "UR NOT FAST COME AUTO AND STILL DIE", "ONE CLIENT CAN STILL CUCK U",
    "THIS POORON CANT DO SHIT", "1 2 3 4 5 6 7 8 9 10 LMFAO U FUCKING DIED", "SHOW ME UR FUNDS", "LOLLL THIS DORK  CANT DO SHIT TO ME",
    "MY EGO BIGGER THAN YO DICK NIGGA", "LMAO ARENT U A PEDO?", "SHOW ME UR HARDRIVE PEDOO", "WHY ARE YOU SO FAT LOOL",
    "KID IS GETTING RATE LIMTED", "LMFAO DONT SPEAK TO ME U EDATE SON", "LMFAO ILL TRAP U SON",
    "WHY RU FOLDING TO ME LOL", " U STAND NO CHANCE AGAINST ME CRY", "LMFAO NICE DUCK KID", 
    "CARVE MY NAME INTO UR SKIN", "LOL NICE FOLD", "BOW DOWN TO ME WHORE", "I OWN U CUCK", 
    "BOW DOWN TO ME", "STOP PACKING", "U LOVE SUCKING ON MY DICK", "UGLY FAN", "DONT STEP I OWN THIS",
    "IM UR GOD", "U USE GRABIFY TO DOX LMFAO", "CUT 4 ME SLUT", "UR SLOW", "U CANT DO NOTHING",
    "I OWN U WHORE", "HANG URSELF JEW", "I DONT FOLD UR MY HOE", "I NEVER FOLD OR DIE ILL MAKE YOU BLEED I RUN YOU",
    "NIGGAS DUCKING LMFAO", "L FUCKING PRESS ", "DORK ASS NIGGA", "WHY IS THIS NIGGA CRYING LOL",
    "U CANT HARM ME", "YOUS A BITCH LOL KILL URSELF", "STREAM UR DEATH", "ILL RAIL UR BITCH",
    "UR E GIRL DONT FW U ", "U FINGER URSELF", "KEEP TYPING SO I CAN EXILE U", 
    "WHY ARE YOU SO SLOW IM USING 1 ACC LOL", "BITCHLESS NIGGA HAD TO GET HIS E FRIENDS", "UR SAD AND WORTHLESS",
    "U AMOUNT TO NOTHING", "I RULE YOU", "I HOE U", "YOUR LIFE IS WORTHLESS UR PACKS ARE SLOW LOG OUT",
    "THIS NEVER STOPS", "gayest shit i seen all year", "THIS KID IS OWNED", "WHY CANT U FIGHT BACK",
    "LAP OWNS YOU CUCK", "FUCK ASS DORK U CANT DO SHIT", "WHO THIS BITCH THINK HE IS", "WHY ARE YOU DUCKING?",
    "COME CRY TO DADDY", "NIGGA CANT DO SHIT", "ACCEPT UR FATE", "I KILLED U", "NICE RUN", 
    "KID CANT DO SHIT HES CRYING", "I OWN ALL UR E GIRLS", "IMA BEAM U", "STOP REPPING UR SHITTY CLAN",
    "2779 WAS MORE HARMFUL THAN THIS", "WHY ARE YOU SO UNKNOWN", "COME DO SOMETHING", "OD ON PAINKILLERS",
    "WHY ARE U SO SHITTY", "UR POOR HTML CANT DO SHIT", "COME DO SOMETHING", "I RUN THIS SHIT",
    "YOU'RE A FAILURE", "STAY SILENT, I OWN YOU", "DON'T PACK ME AGAIN", 
    "I HOE YOU UR SHITTY CORD CANT OUTLAST ME I DONT DIE", "KEEP TALKING JR", "MY MOM TYPES FASTER THAN THIS WHAT THE FUCK LMFAOO", 
    "YO FATASS CANT TYPE", "UR MY HOE", "KEEP CRYING", "I'LL TAKE EVERYTHING FROM YOU",
    "YOU'RE EMBARRASSING YOURSELF", "YOUR FUCKING ASS", "BOW DOWN AND ACCEPT DEFEAT",
    "YOU'RE A NOBODY",  "SIT DOWN AND SHUT UP",
    "EVERYONE'S TIRED OF YOUR BS", "I'M YOUR GOD CUCK", "YOU ALR LOST LMFAOP",
    "NOTHING YOU DO WILL WORK", "KEEP HIDING BEHIND YOUR SCREEN", "YOUR LIFE'S A JOKE",
    "I'M UR OWNER, YOU'RE ASS", "SAY SOMETHING",
    "COME CHALLENGE ME", "YOUR WHOLE EXISTENCE IS TO SERVE ME","HOW ARE YOU USING A SKIDDED CLIENT AND STILL SLOW WTF 😂 "
    "SHUT THE FUCKUP", "UR A BITCH", "LOL", "SHUT YO LAME ASS UP NIGGA",
    "DONT FOLD", "DORK ASS CUNT", "FUCK ASS BITCH",
    "SMD HEADASS NIGGA LMFAO UR WORTH NOTHING TO ME", "UR MY BITCH",
    "FUCK ASS NIGGA", "?", "UR MY SEED", "UR A HOE", "NIGGA U DIED TO ME",
    "IM FASTER THEN U SON", "UR A NERD", "🤓", "DONT STEP TO ME AGAIN",
    "NIGGA FOLDED TO ME", "PIPE THE FUCK DOWN", "I OWN U SON", "UR SLOW",
    "UR A BITCH", "LMFAO", "I DONT KNOW U", "FUCK ASS CUNT", "NIGGA TRIED STEPPING",
    "HOW DID U GET HOED LIKE THAT", "DUMB ASS BITCH", "I DONT FOLD",
    "SHUT THE FUCK UP", "TRY STEPPING AGAIN", "UR A BITCH",
    "DUMB ASS NIGGA", "DUMB ASS BITCH THOUGHT HE COULD STEP",
    "OUT LAST ME I NEVER DIE", "COME DIE TO ME NIGGA", 
]

pl_task = None

# Task to continuously send insults
async def pl_task_function(channel, target):
    """
    Continuously send insults to the target in the given channel.
    """
    while True:
        try:
            # Prepare a batch of 10 insults
            batch = random.sample(insults, 10)

            # Format messages for the target
            messages = [
                f"# _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n  #  {insult} \n {target.mention if hasattr(target, 'mention') else target}"
                for insult in batch
            ]

            
            await asyncio.gather(*(channel.send(message) for message in messages))

           
            await asyncio.sleep(0.5)  

        except Exception as e:
            print(f"Error occurred during insult loop: {e}")
            await asyncio.sleep(0.01)  


@bot.command(name="flood")
async def pack2(ctx, user: discord.User = None):
    global pl_task
    await ctx.message.delete()

    if user is None:
        await ctx.send("```mention a user to flood```")
        return

    if pl_task and not pl_task.done():
        await ctx.send("```flood is already active```")
        return

    channel = ctx.channel  # Get the current channel

    # Start the flooding task
    pl_task = asyncio.create_task(pl_task_function(channel, user))


@bot.command(name="floodoff")
async def sa(ctx):
    global pl_task

    if pl_task and not pl_task.done():
        pl_task.cancel()
        pl_task = None
        await ctx.send("```flood has been stopped```")
    else:
        await ctx.send("```No active flood to stop.```")

# Wordlist
insults = [
    "SHUT THE FUCKUP", "UR A BITCH", "LOL", "SHUT YO LAME ASS UP NIGGA",
    "DONT FOLD", "DORK ASS CUNT", "FUCK ASS BITCH",
    "SMD HEADASS NIGGA LMFAO UR WORTH NOTHING TO ME", "UR MY BITCH",
    "FUCK ASS NIGGA", "?", "UR MY SEED", "UR A HOE", "NIGGA U DIED TO ME",
    "IM FASTER THEN U SON", "UR A NERD", "??", "DONT STEP TO ME AGAIN",
    "NIGGA FOLDED TO ME", "PIPE THE FUCK DOWN", "I OWN U SON", "UR SLOW",
    "UR A BITCH", "LMFAO", "I DONT KNOW U", "FUCK ASS CUNT", "NIGGA TRIED STEPPING",
    "HOW DID U GET HOED LIKE THAT", "DUMB ASS BITCH", "I DONT FOLD",
    "SHUT THE FUCK UP", "TRY STEPPING AGAIN", "UR A BITCH",
    "DUMB ASS NIGGA", "DUMB ASS BITCH THOUGHT HE COULD STEP",
    "DO SUM LMFAO I RULE U", "SIGN UR LIFE AWAY TO XOM", "EW WHOS THIS UGLY RANDOM ON MY REPLYS?",
    "WHY RU DUCKING?", "COME PACK ME UR SLOW", "USING 1 TOK AND STILL FUCKING THIS DORK LMFAOOOOOOOOOOOOOOOOOOOOOOOOOO",
    "THIS POORON CANT DO SHIT", "SHOW ME UR FUNDS", "LOLLL THIS DORK  CANT DO SHIT TO ME",
    "MY EGO BIGGER THAN YO DICK NIGGA", "LMAO ARENT U A PEDO?", "SHOW ME UR HARDRIVE PEDOO", "WHY ARE YOU SO SLOW LMFAOOO",
    "IM CRYING THIS KID IS GETTING RATE LIMTED", "LMFAO DONT SPEAK TO ME U EDATE SON", "LMFAO ILL TRAP U SON",
    "WHY RU FOLDING TO ME LOL", "U CANT CODE U STAND NO CHANCE AGAINST ME CRY", "LMFAO NICE DUCK KID",
    "CARVE MY NAME INTO UR SKIN CMD OWNS ME", "LOL NICE SKID", "BOW DOWN TO ME WHORE", "I OWN U CUCK",
    "BOW DOWN TO ME", "STOP PACKING", "U LOVE SUCKING ON MY DICK", "UGLY FAN", "DONT STEP I OWN THIS",
    "IM UR GOD", "U USE GRABIFY TO DOX LMFAO", "CUT 4 ME SLUT", "UR SLOW", "U CANT DO NOTHING",
    "I OWN U WHORE CMD29", "HANG URSELF JEW", "I DONT FOLD UR MY HOE", "UR PC IS SLOW",
    "NIGGAS DUCKING LMFAO", "L FUCKING PRESS CUTWHORE", "DORKS I OWN THIS CHAT", "WHY IS THIS NIGGA CRYING LOL",
    "U CANT HARM ME",  "STREAM UR DEATH", "ILL RAIL UR BITCH",
    "UR E GIRL CALLS ME DADDY LMFAO UR WORTHLESS", "OH MY GOOD LOOKING WHORE", "KEEP TYPING SO I CAN EXILE U",
    "WHY ARE YOU SO SLOW IM USING 1 ACC LOL", "BITCHLESS NIGGA HAD TO GET HIS E FRIENDS", "UR SAD AND WORTHLESS",
    "U AMOUNT TO NOTHING", "I RULE YOU", "I HOE U", "YOUR LIFE IS WORTHLESS UR PACKS ARE SLOW LOG OUT",
    "THIS NEVER STOPS", "gayest shit i seen all year", "THIS KID IS OWNED", "WHY CANT U FIGHT BACK",
    "CMD29 OWNS YOU CUCK", "FUCK ASS DORK U CANT DO SHIT", "WHO THIS BITCH THINK HE IS", "WHY ARE YOU DUCKING?",
    "COME CRY TO DADDY", "NIGGAS CANT DO SHIT", "ACCEPT UR FATE", "I KILLED U", "NICE RUN",
    "KID CANT DO SHIT HES CRYING",  "IMA BEAM U", "STOP REPPING UR SHITTY CLAN",
    "WHY ARE YOU SO UNKNOWN", "COME DO SOMETHING", "OD ON PAINKILLERS",
    "WHY ARE U SO SHITTY", "UR POOR AND CANT DO SHIT", "COME DO SOMETHING", "I RUN THIS SHIT",
    "YOU'RE A FAILURE", "STAY SILENT, I OWN YOU", "DON'T PACK ME AGAIN", 
    "YOU'RE DONE", "KEEP TALKING JR", "MY MOM TYPES FASTER THAN THIS WHAT THE FUCK LMFAOO", 
    "YO FATASS CANT TYPE", "UR MY HOE", 
    "YOU'RE THE SLUT OF THIS SERVER", "YOU'RE PATHETIC", 
    "YOU'LL NEVER BE GOOD ENOUGH", "KEEP CRYING", "I'LL TAKE EVERYTHING FROM YOU",
    "YOU'RE EMBARRASSING YOURSELF", "YOUR BEST IS STILL TRASH", "BOW DOWN AND ACCEPT DEFEAT",
    "YOU'RE A NOBODY",  "SIT DOWN AND SHUT UP",
    "EVERYONE'S TIRED OF YOUR BS", "I'M YOUR GOD CUCK", "YOU ALR LOST LMFAOP",
    "NOTHING YOU DO WILL WORK", "KEEP HIDING BEHIND YOUR SCREEN", "YOUR LIFE'S A JOKE",
    "I'M UR OWNER, YOU'RE ASS", "SAY SOMETHING",
    "COME CHALLENGE ME", "YOUR WHOLE EXISTENCE IS TO SERVE ME","HOW ARE YOU USING A SKIDDED CLIENT AND STILL SLOW WTF ?? "
]

wordlist = [
"hey\nweak\ndork\nboy\nwya\ni\ncant\nhear\nyou\nspeak\na\nbit\nfaster\nson",
"YO\nQUEER\nARE\nYOU\nSTEPPING\nTO\nDIE\nTO\nME?\nMOVE\nFUCKBOY",
"ILL\nBLOW\nUR\nGIRLS\nSPINE\nOUT\nFAT\nCUCK",
"LLMFAO\nISNT\nUR\nMOTHER\nA\nSTRIPPER?\nLOLLLLLLLLLLL",
"KID\nDONT\nFOLD\nGET\nUP\nAND\nCOME\nKILL\nME\nUR\nFUCKING\nDYING\nRIGHT\nNOW\nDORK",
"I\nSAID\nSTEP\nTHE\nFUCK\nUP\nUR\nBORING\nME\nU\nWEAK\nMUTT",
"POORON\nU\nDIED\nTO\nA\nCLIENT\nAND\nWILL\nDIE\nIN\nMANAUL\nIF\nYOU\nNEED\nSOME\nHELP\nDM\SOCIAL\nLMFAO\nHE\nMIGHT\nHELP\nUR\nWEAK\nASS",
"YO\nFEMBOY\nSHUT\nTHE\nFUCK\nUP",
"MORON\nUR\nMY\nFUCKING\nJR\nU\nWILL\nNEVER\nBE\nFASTER\nTHAN\nME\nLOL",
"TALK\nUR\nSHIT\nU\nWEAK\nASS\nRANDOM\nILL\nFUCKING\nKILL\nYOU",
"I\nCAN\nTURN\nUR\nWHOLE\nFAMILY\nINTO\nMY\nSLAVES",
"THIS\nPOOR\nKID\nLIVES\nIN\nA\n5FT\nHOUSE\nLMFAOOOOOOOOOO",
"STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n STFU U DIED TO ME GET FLOODED DORK BOY\n ",
"NICE\nRUN\nJRR",
"YOU\nDIED\nLAST\nWORD.",
  "YOU\nDORK\nASS\nRUNT\nDONT\nSTEP\nTO\nYOUR\nFOUNDER\n",
  "SOCIAL\nMURDERD\nYOU\nLMFAO\nYOUR\nSO\nWEAK\n",
  "RETARDED\nMORON\nHAIL\nSOCIAL\nLOL\nUR\nFUCKING\nWORTHLESS\n",
  "YO\nCUCK\nDONT\nSTEP\nTO\nUR\nFATHER\nAGAIN\nILL\nHUMBLE\nYOU\nRETARD\n",
  "ILL\nSTEP\nON\nUR\nBITCH\nLMFAO\nCOME\nKILL\nME\nGET\nPAY\nBACK\nYOU\nWEAK\nFUCK\n",
  "COME\nHERE\nILL\nCHOKE\nYOU\n",
  "GET\nDROWNED\nBY\nUR\nGOD\n",
  "GET\nTHE\nFUCK\nDOWN",
  "ILL\nFUCKING\nMURDER\nYOU\nWEAK\nSKID",
  "SHOW\nYOUR\nFUNDS\nWEAK\nPOORON",
  "SHUT\nTHE\nFUCK\nUP\nRANDOM\nFEMBOY",
  "I\nTURN\nUR\nBITCH\nINTO\nMY\nSLUT",
  "YOUR\nMOM\nCUTS\nFOR\nME",
  "ILL\nNEVER\nFOLD\nOR\nDIE\nHAIL\nSOCIAL",
  "DID\nU\nDIE\nSO\nQUICK",
  "PATHETIC\nSLOW\nBOY",
  "UR\nCLIENT\nIS\nSHIT",
  "YOUR\nFUCKING\nSTRUGGLING\nTO\nLIVE",
  "BREATHE\nMY\nWEAKEST\nCHILD",
  "ILL\nRIP\nYOUR\nINTESTINES\nOUT\nAND\nFEED\nIT\nTO\nMY\nDOG",
  "YOUR\nA\nWEAK\nSKID\nASS\nNIGGA\nLOL\nUR\nFUCKING\nRETARDED\nYOU\nBUY\nSCRIPTS\nAND\nSTILL\nDIE\nYOU\nMORON",
  "YOUR\nA\nPUSSY\nASS\nKID\nWHY\nDID\nU\nSTEP\nAND\nGOT\nPUT\nTHE\nFUCK\nDOWN",
  "STEP\nTHE\nFUCK\nDOWN\nBEFORE\nA\nREAL\nSTEPPER\nMURDERS\nYOU\nUR\nMY\nLAB\nDOG\nBARK\nFOR\nUR\nGOD\nYOU\nFEMBOY\nYOU\nHAVE\nA\nCUCK\nKINK",
  "YOUR\nEGO\nDIED\nAFTER\nI\nKILLED\nUR\nSHIT\nTOKENS\nYOUR\nADDICTED\nTO\nDYING\nBY\nSOCIAL\nYOU\nFUCKUP\nDORK",
  "DO\nYOU\nWANT\nMY\nWORD\nLIST\n?\nLOL\nU\nMIGHT\nNEED\nIT\nU\nUSE\nCHAT\nGPT\nTO\nGIVE\nU\nWORDS",
  "SHUT\nUP\nBROKE\nASS\nKID",
  "I\nFEEL\nBAD\nBUT\nI\nHAVE\nTO\nSHOW\nYOU\nWHO\nUR\nGOD\nIS",
  "LETS\nGO\nTO\nWAR\nWATCH\nU\nDIE\nWEAK\nFUCK",
  "YOU\nWILL\nNEVER\nGET\nA\nBITCH\nAND\nIF\nU\nDO\nU\nWILL\nMAKE\nHER\nPUSSY\nDRY",
  "STFU\nYOU\n1WPM\nWARRIOR\nUR\nSAD\nAS\nSHIT",
  "ILL\nNEVER\nDIE\nKEEP\nGOING\nTILL\nYOUR\nBONES\nDECAY\nMY\nCLIENTS\nCAN\nOUTLAST\nYOUR\nWORTHLESS\nLIFE",
  "SHUT\nUP\nYOU\nLOW\nTIER\nRETARD",
  "you\ndied\nto\na\ngod\nlol\nits\nokay\njrs\nlike\nyou\nalways\nfail\nme", 
  "YOU\nDISAPOINTED\nME\nI\nWANTED\nTO\nGO\nLONGER",
  "SAY\nIT\nWITH\nYOUR\nCHEST\nYOU\nCANT\nHANDLE\nTHE\nGREATEST",
]

BIRTHDAY_FILE = "birthdays.json"
lappymsg = [f"WHOIS THIS UNKNOWN SLUT LMFAO","CMON DO SUM LOL","IM WAITING TO KILL U LOL","UR DEAD","GET FLOODED BOY","UR WORTHLESS NIGGA UR SLOW WTF","WHERE ARE YOU AT???","???????????","YOU CANT PACK ME","CMON START THAT AUTO BEEFER BY LARP FAGGOT","UR FUCKING USELESS CANT DO HARM","LOOLOLOL","WHERE ARE YOU AT PEDO","STOP HIDING BEHING UR SCREEN LOL I SEE U","YOU FOLDED TO ME","CMON DO SUM","SHITTY PEON","TS NIGGA WAS MADE IN CH1NA BTW","SATAN WANT TO TAKE YOU FOR BEING GOOD BOY/GIRL LOL","COME HERE AND FIGHT ME UR MCDONALD MADE FAGGOT","U AINT TUFF","OLOL BE GOOD BOY/GIRL LOL","UR RETARDED LOL THIS FUCK BOY/GIRL NIGGER LOL","903 OWNS TS CHAT NIGA LOL U AINT DOING ANY DAMAGE","GET ON AND BEEF IF U ARE TUFF","LMFAOOOOOOOOOOOOOOOOOO YO B1TCH UR DEAD","REAL BAD YOU USED CHATGPT FOR ROAST SHIT","DONT BEEF W ME FAGGOT","STOP ATTACKING INNOCENT SOULS RETARD","KILL YOURSELF","UR A PEON MADE SLUT","WHORE ASS PEON","HAPPY D3ADDAY FAGGOT","DEAR GOD PLS STRIKE TS NGA DOWN TS NGA IS SO FUNNY IM DYINGH 😭🙏","nigga kys 🙏😭😭","ur adorable lil fuck holy shit 😭😭💔","STOP YAPPING AND BEND OVER 😭","ts pussy looks tasty nga holy 💔","ur daddy is here son ur aint tuff LOLOLOL","OHHHHHHHH UR SO SCARY 🥀","nigga 😭🙏","PUSSY I WILL FUCK U LOLLOOL","U NOT TUFF BRO LOLOOLLO","UR UNFUNNY NIGA KILL YOURSELF","GARBAGE THAT CREATED W LOVE LOLOOL","I GO FOREVER NIGGA","YOU FUCKEDUP SLUT\n903 OWN TS NGA","UR MY FAN","UR FUCKING GARBAGE JUST KILL YOURSELF","CODE HERE SLUT UR SUCK C0CK LOLOLOL","I'LL MASS RAPE YOU","WE OWNS THIS CHAT NOW","U ARE DEAD 2 LAPPY X 903","GARBAGE MADE","YOU ARE ASS","UR PARENT USED TO BEAT YO UP LMFAO DONT GET SMART SLAVE","OFC TS NGA IS LOSER","OLLOLOO NIGGA FOLDING 2 ME LOL"]
lappymsg2 = [
  "you\nare\ngarbage\nass\nfaggot\ni\nowns\nyou\nLMFAOO",
  "SHUT\nTHE\nFUCK\nUP\nAND\nDIE\nTO\nLAPPY\nU\nSHITTY\nFAGGOT\nUR\nFUCKING\nWORTHLESS\nSHIT",
  "POP\nTF\nOUT\nUR\nDEAD\nTO\nME\nGET TF UP\nUR\nA\nLOSER\nWTF\nLOL\nGET\nUP\nAND\nFIGHT\nME",
  "I\nOWN\nTHIS\nSHITTY\nSLAVE\nLOLLO\nYES\nITS\nTRUE\nLOL\nUR\nDEAD\nTO\nME",
  "YOU\nARE\nFOLDED\nTO\nME\nYOU\nARE\nFOLDED\nTO\nME\nYOU\nARE\nFOLDED\nTO\nME\nYOU\nARE\nFOLDED\nTO\nME\nYOU\nARE\nFOLDED\nTO\nME\nYOU\nARE\nFOLDED\nTO\nME\nYOU\nARE\nFOLDED\nTO\nME",
  "LLOL\nWHOS\nTS\nSHITTY\nBEEFER\nLOL\nTRY\nOUT\nLAST\nME\nLOLOOLL\nUR\nDEAD\nI'LL\nEXECUTE\nYOU",
  "GAY\nFAGGOT\nARE\nU\nPEDO?\nTALK\nBOY\nUR DEAD\nLOL\nGET\nUP\nAND\nDO SHIT\nHARMLESS\nSLUTTY\nFAGGOT",
  "YOU\nCANT\nOUTLAST\nME\nRETARD\nIM\nUR\nGOD\nLOL\nGET\nON\nAND\nSTOP\nHIDING\nBEHIND\nUR\nSCREEN",
  "YOU\nARE\nWORTHLESS\nFAGGOT\nKEEP\nTRYING\nLOOLOLLMAO\nGET\nOUTLASTED\nBY\nLAPPY\nLOL",
  "UR\nAINT\nA\nGOD\nWHY\nYOU\nCANT\nHARM\nME\nLMFAO\nDO\nSUM\nFAGGOT\nIM\nGOING\nTO\nRAPE\nYOU\nLOLOL",
  "WHERE\nARE\nYOU\nAT\nLOL\nLETS\nME\nFIND\nU\nLMAO\nUR\nDEAD",
  "YOUR\nGENERATION\nIS\nD O O M E D\nYES\nITS\nTRUE\nLOL\nUR\nDEAD\nTO\nME",
    "LOLOL\nLOOK\nAT\nTHIS\nFAGGOT\nLMFAO\nFAGGOT\nWAS\nMOANING\n24FUCKING7\nLOL\nSTOP\nAURA\nFARMING\nU\nAINT\nTUFF\nBOY",
  "G A R B A G E\nA S S\nYOU\nCANNOT\nDO\nSHIT\nUR\nFUCKING\nUSELESS\nGARBAGE\nASS\nLOL"
]

outlast_active = False
outlast_task = None
pl_task4 = None
group_name_changer_task = None
lappygcnames = ["YOU FUCKING ASS NIGGA KYS LOLL","903 RUNS TS SHIT OLLOL","UR A GARBAGE","ASS","TS NGA GETTING RAPED","LOLO UR A NOBODY","GET OFF MY DICK NGA","YES IM AGGRESSIVE AND????","WTF U GOING TO DO NGA","UR DORK MUSLIM ASS RETARDED PEON NGA KYS","OH PLEASE KILL YOURSELF UR A USELESS","NGA PLEASE SUCK UR COCK IF U CAN LOL I DARE U","UR NEVER STAND A CHANCE AGAINST ME","UR A SATANIST NGA UR A RETARD LOL","TRY BEEF W ME I DARE U","FAGGOT ASS","I'LL HOE U","KEEP HIDING BEHING UR SCREEN NGA","UR NOT HIM LIL NGA YOU ARE DORK","UR A RETARD NGA 903 OWNS YOU AS SLAVE","UR FIRED FROM UR JOB NGA","LOLOLOL","TRASH ASS","UR NOT HIM LIL NGA LMAFOA","UR DORK ASS","GARBAGE SLOW PEON","WHERE RU AT PEDO LOL"]

async def pl_task_function4(channel, target):
    while True:
        try:
            batch = random.sample(lappymsg, 10)
            messages = [
                f"# _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n # _ _ \n  #  {insult} \n {target.mention if hasattr(target, 'mention') else target}"
                for insult in batch
            ]
            await asyncio.gather(*(channel.send(message) for message in messages))
            await asyncio.sleep(0.5)
        except Exception as e:
            print(f"Error occurred during insult loop: {e}")
            await asyncio.sleep(0.01)

async def group_name_changer(channel):
    count = 0
    while outlast_active:
        try:
            new_name = f"{lappygcnames[count % len(lappygcnames)]} x{count}"
            await channel.edit(name=new_name)
            count += 1
        except Exception as e:
            print(f"Error changing group name: {e}")
            await asyncio.sleep(0.01)

@bot.command(help="Super aggressive auto beefer + gc name changer [lappy mode] ")
async def lappymode(ctx, *args):
    global outlast_active, outlast_task, pl_task4, group_name_changer_task

    await ctx.message.delete()

    if not args:
        await ctx.send("```Please mention a user or provide a valid user ID.```")
        return

    user_mentioned = None
    arg = args[0]

    if arg.startswith("<@") and arg.endswith(">"):
        user_mentioned = arg  
    else:
        user_mentioned = f"<@{arg}>"

    if not user_mentioned:
        await ctx.send("```Could not resolve user mention or ID. Please try again.```")
        return

    if outlast_active:
        await ctx.send("```Outlast is already active```")
        return

    outlast_active = True

    async def outlast_messages():
        while outlast_active:
            try:
                response = random.choice(lappymsg2)
                await ctx.send(f"> {response}\n{user_mentioned}")
                await asyncio.sleep(0.1)
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Error: {e}")

    outlast_task = asyncio.create_task(outlast_messages())
    pl_task4 = asyncio.create_task(pl_task_function4(ctx.channel, user_mentioned))

    if len(args) > 1 and args[1].lower() == "on":
        group_name_changer_task = asyncio.create_task(group_name_changer(ctx.channel))

@bot.command()
async def lappymodeoff(ctx):
    global outlast_active, outlast_task, pl_task4, group_name_changer_task

    if pl_task4 and not pl_task4.done():
        pl_task4.cancel()
        pl_task4 = None

    if group_name_changer_task and not group_name_changer_task.done():
        group_name_changer_task.cancel()
        group_name_changer_task = None

    if outlast_active:
        outlast_active = False
        if outlast_task:
            outlast_task.cancel()
        await ctx.send("```lappy mode disabled```")
    else:
        await ctx.send("```No active mode to stop.```")


outlast_active = False
outlast_task = None

# Example insult list (replace with your own)
insults2 = [
    "FAGGOT GET UP LOLOL I OWNS THIS SHIT LOLOL",
    "UR WEAK AS FUCK WTF LMAO",
    "SHOW\nYOUR\nFUNDS\nWEAK\nFAGGOT",
    "GET\nTF\nUP\nAND\nFIGHT\nME\nLOLOOLL",
    "UR\nMY\nSLUT\nLLOLOLO\nNIGGA\nWHERE\nARE\nYOU\nLOLOLOLL",
    "Y O U R  G E N E R A T I O N  I S  D O O M E D\nLOOLOL",
    "NIGGA\nWHY\nYOU\nHIDING\nBEHIND\nUR\nSCREEN?LOOL\nCMON\nDO SUM",
    "?\nWHERE RU AT\nI\nWILL\nKILL\nYOU\nLMFAOOOOOOOO",
    "GET\nON\nFAGGOT\nIM\nWAITING\nLOLLOLOLLOOLLO",
    "UR SLOW SHIT LOLOLOLOLOL\nGET TF UP\nTYPE\nFASTER",
    "TRY CHALLENGE UR GOD LOLOL UR FAILURE AND HOPELESS LIL NGA L M A O  UGLY JR",
    "EVEN\nGOD\nAINT\nTAKING\nTS NIGGA LOOL FUCKING PATHETIC",
    "TRY CHALLENGE ME BOY\nUSE UR SKIDDED\nAUTOBEEFER\nAND\nHARM\nME\nLLOLOL",
    "I WILL KILL YOU\nLMFAOOOOOOOOOO\nGET ON\nWHORE ASS\nI GO FOREVER\nPUSSY\nSLOW\nDORK",
    "UR\nMY\nSLUT\nAND\nU\nALREADY\nPREGNANT\nLMFAOOOOOOOO\nHOLY",
    "N O  E S C A P E  F A G G O T  I M  U R  G O D\nY O U  A R E  D O O M E D",
    "??????????????????????????????????\nGET TF ON\nUR\nHIDING\nFROM\nME\nWANNABE JUSTICE KID LOLOLLOOL",
    "UR A JEW FAGGOT GROSS DORK\nDO SUM\nLOLOLOL\nUR SLOW"
    
]

async def pl_task_function2(channel, target):
    """
    Continuously send playful insults to the target in the given channel.
    """
    while True:
        try:
            # Pick up to 10 random insults
            batch = random.sample(insults2, min(10, len(insults2)))

            # Format messages with target mention
            messages = [
                f"""```
⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠄⢤⣠⢷⣝⢦⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⠒⣲⣦⣺⣳⣤⡿⠛⠃⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⠉⠢⣣⣁⠀⣀⠙⢧⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⡎⠑⢤⡼⡩⡪⠷⠀⠀⡇⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢿⣶⡞⢯⣠⡻⠼⡇⠀⠀⠀⡇⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⡷⢌⠻⣶⡟⡄⠈⠁⠀⠀⠐⢣⡀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⡴⣷⣿⡗⠀⣡⠊⠻⠋⠒⢄⠀⠀⢀⠔⠙⢦⡀⠀
⠀⠀⠀⠀⠀⠀⡠⠊⠁⢺⣿⢇⠜⠁⠀⠀⠀⠀⣠⠗⠊⠀⠀⣠⡺⠆⠀
⠀⠀⠀⠀⣠⣾⡗⠀⠀⢸⡿⠋⠀⠀⠀⠀⠀⠀⠻⣆⠛⣠⣞⢕⢽⣆⠀
⠀⠀⠀⣴⣿⣿⡇⠀⢀⠞⠁⠀⠀⠀⠀⠀⠀⠀⢐⡯⡪⡫⡢⣑⣕⢕⠀
⠀⠀⣼⣿⣿⣿⠇⡰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢮⡺⣾⣮⡪⡳⠀
⢀⣼⣿⣿⣿⠿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠺⣷⣝⢮⠀
⠾⠿⠟⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠪⣻⡇
DON'T RUN
DON'T RUN
DON'T RUN
DON'T RUN
DON'T RUN
DON'T RUN
DON'T RUN
DON'T RUN
DON'T RUN
DON'T RUN
DON'T RUN
DON'T RUN
```
https://media.discordapp.net/attachments/1153645269745926174/1194096579011956767/ezgif-1-c9599ca267.gif?ex=674bc199&is=674a7019&hm=9a1af4657b58be730316c368c9c2a206f8695f3d05a0c0e892a96399dccf42b4&=&width=292&height=198
 
{insults2}

{target.mention if hasattr(target, 'mention') else str(target)}
                """ for insults2 in batch
            ]

            # Send messages concurrently but handle rate limits
            for msg in messages:
                await channel.send(msg)
                await asyncio.sleep(0.1)  # delay between messages to avoid spam

        except Exception as e:
            print(f"\033[1;31m[Error]\033[0m {e}")
            await asyncio.sleep(1.0)  # small cooldown on error

pl_task2 = None

whore_wordlist = ["HOW\nDID\nYOU\nGET\nHOED\nLIKE\nTHAT\nLOLL\nYOUR\nA\nBITCH", "SIGN\nYOUR\nLIFE\nAWAY\nTO\nME\nLOSER\nASS\nPEDO\nLOLL","SHUT\nYOUR\nPUSSY\nASS\nMOUTH\nBITCH", "NIGGA\nGETS\nBULLIED\nON\nDAILY\nBASIS", "TRASH\nNIGGA\nOUTLAST\nME\nRETARD", "MORONIC\nASS\nLITTLE\nFAGGOT\nGET\nBACK\nUP", "WEAL\nASS\nCHAT\nSLAVE\nGET\nDOWN\nFUCK\nBOY", "NEVER\nCOMPETE\nWITH\nA\nGOD", "UR\nMY\nFUCKING\nSON\nPEASENT", "FOCUS\nUP\nRETARDED\nFUCKBOY\nLOLLOL", "NIGGA\nYOU\nCANT\nSTEP\nSHITTY\nLOSER", "SHUT\nTHE\nFUCK\nUP\nBITCHMADE\nLOSER", "LOL\nYOUR\nA\nSHITTY\nCOM\nREJECT\nLOSER", "YOUR\nDYING\nTO\nME\nLMFAOO", "STOP\nSTEPPING\nU\nSLOW\nBRAINED\nMORON", 
"EGOUL\nMEU\nE MAI\nMARE\nDECÂT\nPUIUL TĂU\nNEGRU", "NU POȚI\nPROGRAMA\nNU\nAI\nNICIO\nȘANSĂ\nÎMPOTRIVA\nMIEI\nPLÂNGE", "MY\nMOM\nTYPES\nFASTER\nTHAN\nTHIS\nWHAT\nTHE\nFUCK\nLMFAOO", "RETARDED\nMORON\nLOL\nUR\nFUCKING\nWORTHLESS", "ILL\nNEVER\nFOLD\nOR\nDIE", "GET\nDROWNED\nBY\nUR\nGOD", "STEP\nTHE\nFUCK\nDOWN\nBEFORE\nA\nREAL\nSTEPPER\nMURDERS\nYOU\nUR\nMY\nLAB\nDOG\nBARK\nFOR\nUR\nGOD\nYOU\nFEMBOY\nYOU\nHAVE\nA\nCUCK\nKINK", "YOUR\nMY\nSEEDLING\nI\nGREW\nYOU\nLIKE\nA\nPLANT\nWEAK\nFUCK\nBOY", "WHO\nIS\nTHIS\nWEAK\nLOWTIER\nCLOWN", "ILL\nTEAR\nYOUR\nGUTS\nOUT\nWEAK\nUGLY\nSLOW\nDORK\nLOLLL", "I\nBROKE\nTHIS\nNIGGAS\nNECK\nLOL\nWEAKLING", 
"SHUT\nTHE\nFUCK\nUP\nYOU\nCANT\nBEEF\nRETARD", "STREAM\nYOUR\nDEATH\nPETTIE\nFAGGOT", "YOUR\nDYING\nTO\nME\nFRAIL\nSLUT","UP\nME\nA\nPENNY\nPOOR\nPISS\nFUCK", "I\nSTABBED\nTHIS\nNIGGA\nIN\nHIS\nCHEST", "WEAK\nDYSLEXIC\nFUCK\nUR\nHORRID", "WE\nCAN\nGO\nFOREVER\nILL\nMURDER\nYOUR\nBLOODLINE\nDYKE", "NOBODY\nCAN\nSAVE\nYOU\nTRANNY\nDYKE", "YOUR\nA\nPUSSY\nASS\nKID\nWHY\nDID\nU\nSTEP\nAND\nGOT\nPUT\nTHE\nFUCK\nDOWN", "LOL\nYOUR\nJUS\nASS\nAINT\nYOU?😂", "SHUT\nTHE\nFUCK\nUP\nWEAK\nFUCKBOY", "BOW\nDOWN\nTO\nME\nSHITTY\nSLUT", "PEON\nASS\nNIGGA\nASKED\nA\nHOMELESS\nGUY\nFOR\nA\nDOLLAR", "WHO\nGAVE\nTHIS\nNIGGA\nTHE\nMIC\nLMFAOO", 
"DIRTY\nASS\nHOBO\nLIVES\nIN\nA\nCARDBOARD\nBOX", "WHO\nTHE\nFUCK\nASKED\nBITCHMADE\nLOSER", "UGLY\nASS\nBLACK\nTHUG", "nigga\nbuilt\nlike\na\nsumo\nwreslting\nairplane", "nigga\nyo\ngranny\nlevetaties\nwhen\nshe\nclicks\nher\nankles", "frog\nwith\nvampire\nteeth\nthat\nruns\naway\nfrom\nhumans", " you\nlook\nlike\nan\niguana\nwith\na\nrocket\nboot\non", "YOU\nSHOT\nA\nHOMELESS\nMAN\nFOR\nSELLING\nCANDY", "that\nnigga\nwhitebeard\nthrew\na\npocket\nknife\nat\nyo\ntooth", "YOU\nDORK\nASS\nRUNT\nDONT\nSTEP\nTO\nYOUR\nFOUNDER", "COME\nHERE\nILL\nCHOKE\nYOU\nDIRTY\nHINDU\nIDIAN", "ILL\nFUCKING\nMURDER\nYOU\nWEAK\nSKID", 
"ILL\nRIP\nYOUR\nINTESTINES\nOUT\nAND\nFEED\nIT\nTO\nMY\nDOG", "SAY\nIT\nWITH\nYOUR\nCHEST\nYOU\nCANT\nHANDLE\nTHE\nGREATEST", "ILL\nMAKE\nYOUR\nLIFE\nFLASH\nDUMB\nCUCK", "NIGGA\nGETS\nBEAT\nBY\nHIS\nDAD\nLOL", "YOU\nFLEX\nWEAKNESS\nAND\nCALL\nIT\nPERSONALITY\nDUMBASS\nNIGGA", "WE\nCOULD\nPUT\nU\nON\nA\nSHIRT\nRETARDED\nFUCKING\nPEDOPHILE", "WEIRD\nASS\nNIGGA\nTALKING\nTO\nME\nLIKE\nWE\nCOOL", "I\nWALK\nIN\nYOU\nVANISH\nTHATS\nREAL\nINFLUENCE", "UR\nA\nDIRTY,\nASS\nNIGGA\nAND\nNOBODY\nCARE", "UR\nMY\nFUCKING\nSON\nNIGGA\nDIED\nAND\nBLEW\nHIS\nFUCKING\nBRAINS\nOUT", "LETS\nALL\nPRAY\nFOR\nTHIS\nNIGGA\nLOOOL", "HOW\nARE\nYOU\nSO\nASS\nNIGGA\nLMAO", 
"get\nthe\nfuck\ndown\ni\nown\nyou", "TU\nMAMÁ\nES\nMI\nPUTA", "I'll\nrip\nur\nankles\noff\nweak\nbitch", "you\nlook\nlike\na\ndinosaur\nwith\nno\nteeth", "im\ngonna\ntake\nyour\nsoul\nnow", "your\nfucking\nslow\nand\nyour\na\nindian\nloser", "you\nso\nfucking\ntrash\nbitch\nboy", "you\nugly\nas\nfuck boy\nniggas\nwill\nput\nands\non\nyou", "ur\nso\nfucking\ndogshit\nweak\ncuck\nnow\nshut\nthe\nfuck\nup\nlike\nmy\ndog", "you\nsaw\nme\nand\nyo\nbody\nshook\npussy", "yo\nindian\nshut\nthe\nfuck\nup", "Nigga\nyou\nwas\nplaying\nagario\nand\ngot\ndouble\nsplitted\nby\na\nnigga\nnamed\nTimmyTwoThumbs\nboy\nyou\nugly\nass\nretarted\nfuck", 
"Nigga\nyou\ngot\nbanned\nfrom\nthe\nLGBTQ\nhideout\nbecause\nyou\nsaid\nsaid\nthe\ncolors\nof\nthe\nrainbow\nwere\nugly\nnigga\nyou\nstupid\nas\nfuck\nboy", "ill\nchuck\nyou\nin\na\nriver\nbitch", "even\ncancer\npatients\nhas\nmore\nlife\nthan\nyou", "this\nis\nbad\nyour\nslow\nand\ni\nown\nyou", "weird\nass\nliving\nspecial\ncreature", "ill\nput\nyou\nin\na\nchokehold\nand\nbody\nslam\nyou\nLOL", "ill\nrip\nyour\nscalp\noff\nyour\nskull", "niggas\nwill\nend\nyou\nfaggot\nthot", "slobby\ndepressed\nfuck\nshut\nthe\nfuck\nup", "shut\nthe\nfuck\nup\nyou\nadmitted\nto\nbeing\nmy\ngood\nlittle\nwhore\ndogshit\nfaggot", "nigga\nis\nsprinting\naway\nfrom\nme",
"ill\nbeat\nthe\nfuck\noutta\nyou", "im\nfaster\nden\nyou\nslow\nlittle\nbitch", "ay\nbitch\nshut\nthe\nfuck\nup\nugly\npussy", "ugly\nass\npedophile\ni\ndont\nfuck\nwith\nyou\nfaggot", "your\nlife\nis\non\n50/50cringe\nbitch", "ill\nhumiliate\nyou\nbitch\nyou\ngot\nhoed\nby\neveryone\ngarbage\nbitch", "ill\nput\na\nrifle\nin\nyour\nmouth\nbitch\nmade\nloser\nLOLL", "you\ngot\nelectrocut\nby\nmy\neel\nloser\ndork", "im\ndissing\nyou\nnow\nwhat\nweak\nass\ndying\nslut", "your\nso\nfucking\nweird\nugly\npedo\nstop\nfucking\nlooking", "ill\nthrow\nyou\nin\na\ndumpster\nslave\ndont\nfucking\ndie\nscumbag", "your\nmy\nloser\nlittle\nbitch\nyour\nass\nas\nfuck\nwhore",
"pedo\nfuck\nstay\naway\nfrom\nminors\nfucking\ntrash\nbitch", "ay\nfuck\nup\ndogshit\nqueer\ndo\ni\nneeda\nsmack\nthe\nfuck\noutta\nyou", "your\nmother\nisnt\nvisiting\nyour\nfuneral\nlonely\nfuck\nill\ntake\nyour\nsoul\nout\nusing\nmy\nbarehands", "bitchass\nnigga\nill bash ur head in pussy\nyour\nmy\nbitch\nweak\nfuck", "niggas\nwill\nshoot\nyour\nface\noff\nshut\nthe\nfuck\nup\nfat\nbitch", "stop\nbeing\nmy\nbitch\nfaggot\nyour\nass\nson\nand\nyour\naccuracy\nis\nshit" "watch\nthat\nfuckin\nmouth\nfaggot\nbitch\nyour\na\nnerdy\nshithead\nyour\nclit\nstinks\nim\nhere\nto\nkill\nyou", "cow\ndick\neating\nass\nnigga", "skanky\nlittle\nfaggot\nyour\nugly\nas\nfuck\nLOL", 
"yo\ngreasy\nfaggot\nfuck\nup\nill\nbeat\nthe\nfuck\noutta\nyou", "bitch\nill\nbreak\nyo\nnose\nsit\nthe\nfuck\ndown\nfaggot", "ugly\nfaggot\ndont\nrun\nwhy\nare\nyou\nnot\ndoing\ndamage", "Nigga\nyour\nhead\nlooks\nlike\na\ndorito\nmy\nnigga\nyou\ngot\nthat\nshit\nfrom\nphineas\nand\nferb\ntell\nme\nwhy\ni\nsaw\nyou\nbeating\nyour\ndick\nto\ndora\nthe\nexplora", "I'LL\nLEAVE\nTHIS\nIMPAIRED\nREJECTS\nBODY\nIN\nA\nDITCH", "NIGGA\nDIED\nBY\nFIRING\nSQUAD", "stop\ncrying\nget\nback\nup", "skanky\nlittle\nfaggot\nyour\nugly\nas\nfuck\nLOL", "ill\nmake\nyou\nend\nyour\nlife\nfrail\nass\nbitch", "Cállate\nla\nboca\nsucio\ncriatura\nespecial\nnegro\nEntraste\na\nmi\npaís\nen\nun\ncontenedor",
"988\nheres\nthe\nsuicide\nhotline\nfrustrated\npedo", "this\nis\nbad\ni\nfucking\nkilled\nyou" "BITCH\nWHY\nAM\nI\nOVER\nYOU\nSTOP\nFUCKING\nDYING\nPIGFUCKER\nYOU\nCANT\nCOMPETE\nWITH\nYOUR\nGOD\nBITCH\nWHY\nAM\nI\nOVER\nSTOP\nFUCKING\nDYING\nPIGFUCKER\nYOU\nCANT\nCOMPETE\nWITH\nYOUR\nGOD\nBITCH\nWHY\nAM\nI\nOVER\nYOU\nSTOP\nFUCKING\nDYING\nPIGFUCKER\nYOU\nCANT\nCOMPETE\nWITH\nYOUR\nGOD\nBITCH\nWHY\nAM\nI\nOVER\nYOU\nSTOP\nFUCKING\nDYING\nPIGFUCKER\nYOU\nCANT\nCOMPETE\nWITH\nYOUR\nGOD\nBITCH\nWHY\nAM\nI\nOVER\nYOU\nSTOP\nFUCKING\nDYING\nPIGFUCKER\nLOLLOLOOL", "nigga\ni\ncaught\nu\nslapboxing\na\nnigga\nname\ndonitello\nfor\n20\nvbucks\nlike\nshit\nnigga\nyou\nwas\na\nknown\nschool\nthreat\nbecause\nyou\nbrought\na\nbaguette\nto\nschool\nfor\nbring\nyour\npet\nday\nsmelly\nnigga",
"nigga\nthats\nwhy\nyo\nnipples\nare\nbuilt\nlike\nfour\nleaf\nclovers\nthats\nwhy\byo\nmom\nuse\nto\nuppercut\nyou\nin\nfatboy”, “you\nsmoke\nvapes\nout\nyour\nasshole\nweirdo”, “SORRY\nASS\nNIGGA\nUR\nNOT\nSAFE\nFROM\nME\nWEAK\nVIRGIN\nASS\nNIGGA\nUR\nMISERABLE\nAS\nSHIT\nFUCKING\nFAGGOT\nASS\nPEDO\nLOLOL”, “NIGGA\nHOE\nASS\nNIGGA\nDIRTY\nASS\nNIGGA\nSHUT\nUP\nNIGGA\nYOU\nWASTED\nEIGHT\nYEARS\nOF\nYOUR\nLIFE\nIN\nA\nJUNGLE\nTRYNA\nFIND\nA\nLEGENDARY\nPOKEMON\nMY\nNIGGA\nCAUSE\nYOU\nDIRTY\nAS\nFUCK\nMY\nNIGGA\nYOU\nFEEL\nBURPS\nFORM\nIN\nYO\nTHROAT\nAND\nPISS\nYO\nPANTS\nMY\nNIGGA\nYO\nMOTHER\nIS\nA\nCRACK\nADICT\nLOLOO"

]

@bot.command(help="whore beef")
async def whore(ctx, *args):
    global outlast_active, outlast_task

    
    if not args:
        await ctx.send("```mention a user```")
        return

    
    user_mentioned = None

    if len(args) == 1:
        arg = args[0]
        
        
        if arg.startswith("<@") and arg.endswith(">"):
            user_mentioned = arg  
        else:
          
            user_mentioned = f"<@{arg}>"
    await ctx.message.delete()
    if not user_mentioned:
        await ctx.send("```user not mentioned```")
        return

 
    if outlast_active:
        await ctx.send("```whore already enabled```")
        return

    outlast_active = True

    async def outlast_messages():
        while outlast_active:
            try:
                response = random.choice(whore_wordlist)

        
                await ctx.send(f"{response}\n{user_mentioned}")

                await asyncio.sleep(0.1)

            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Error: {e}")

    
    outlast_task = asyncio.create_task(outlast_messages())

@bot.command()
async def whoreoff(ctx):
    global outlast_active, outlast_task

    if outlast_active:
        outlast_active = False
        if outlast_task:
            outlast_task.cancel()
            await ctx.send("```whore disabled```")
            await ctx.message.delete()

faggot_wordlist = ["wsp faggot nigga","ur a faggot wtf","ur a faggot ass nigga go kill yourself","faggot cant do shi","ts faggot is a pedo nigga wtf","ur fucking losertard","kill urself pls","faggot cant do shii olololo","ur aa faggotard nigga go kill yourself","i aint stopping lil nigga","ur ass faggot go cry in sex corner nga","ur fucking faggot u fucktard","faggot go watch https://www.pornhub.com faggot retard ","kill yourself nigga ur a faggot","faggotard nigga ur a fucking loser","faggot trying to outlast my ass lmfao fucking losertard","ur weak fucktard","go fuck ur non existing gf aka ur pillow faggot nga","faggot made slut nigga","kill yourself","ur a retarded faggot ass nigga folding to fucking auto beefer","kill yourself u faggot","go fuck yourself u nasty faggot"]

@bot.command(help="faggot beef")
async def faggot(ctx, *args):
    global outlast_active, outlast_task

    
    if not args:
        await ctx.send("```mention a user```")
        return

    
    user_mentioned = None

    if len(args) == 1:
        arg = args[0]
        
        
        if arg.startswith("<@") and arg.endswith(">"):
            user_mentioned = arg  
        else:
          
            user_mentioned = f"<@{arg}>"
    await ctx.message.delete()
    if not user_mentioned:
        await ctx.send("```user not mentioned```")
        return

 
    if outlast_active:
        await ctx.send("```faggot already enabled```")
        return

    outlast_active = True

    async def outlast_messages():
        while outlast_active:
            try:
                response = random.choice(faggot_wordlist)

        
                await ctx.send(f"> # {response}\n{user_mentioned}")

                await asyncio.sleep(0.0001)

            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Error: {e}")

    
    outlast_task = asyncio.create_task(outlast_messages())

@bot.command()
async def faggotoff(ctx):
    global outlast_active, outlast_task

    if outlast_active:
        outlast_active = False
        if outlast_task:
            outlast_task.cancel()
            await ctx.send("```faggot disabled```")
            await ctx.message.delete()



@bot.command(name="beef", help="Auto beefer 2")
async def pack1(ctx, user: discord.User = None):
    global pl_task2
    await ctx.message.delete()

    if user is None:
        await ctx.send("```mention a user to beef```")
        return

    if pl_task2 and not pl_task2.done():
        await ctx.send("```beef is already active```")
        return

    channel = ctx.channel  # Get the current channel

    # Start the flooding task
    pl_task2 = asyncio.create_task(pl_task_function2(channel, user))


@bot.command(name="beefoff", help="stop beef")
async def sa2(ctx):
    global pl_task2

    if pl_task2 and not pl_task2.done():
        pl_task2.cancel()
        pl_task2 = None
        await ctx.send("```beef has been stopped```")
    else:
        await ctx.send("```No active beef to stop.```")

@bot.command()
async def automessageoff(ctx, channel_id: int, user_id: int):
    
    task_key = (channel_id, user_id)
    if task_key in tasks_dict:
        tasks_dict[task_key].cancel()
        del tasks_dict[task_key]
        await ctx.send(f"```Stopped sending messages to <@{user_id}> in <#{channel_id}>.```")
    else:
        await ctx.send("```No active task found for the specified channel and user.```")
MESSAGES = [
    "yo {name} shut the fuck up",
    "fuck up {name}",
    "hey {name} shut the fuck up speaking",
    "nigga named {name} fuck up talking lol",
    "yo bitch {name} didn't I say shut up",
    "I am getting tired of you talking {name} so shut the fuck up",
    "shut up {name}",
    "{name} bitch shut that shit up",
    "{name} can you shut the fuck up",
    "nigga {name} shut the fuck up right now",
    "{name} shut your lips bitch",
    "{name} cry and shut the fuck up",
]

# Dictionary to store active tasks
tasks_dict = {}


@bot.command()
async def automessage(ctx, channel_id: int, user_id: int, minutes: int, *, name: str):
    
    if (channel_id, user_id) in tasks_dict:
        await ctx.send("A task is already running for this channel and user.")
        return

    async def task():
        """Task to send periodic messages."""
        channel = bot.get_channel(channel_id)
        if channel is None:
            await ctx.send(f"Channel with ID {channel_id} not found.")
            return
        
        counter = 0
        while True:
            message_content = random.choice(MESSAGES).format(name=name)
            if counter % 2 == 0:
                message = f"{message_content} <@{user_id}>"
            else:
                message = message_content
            
            await channel.send(message)
            counter += 1
            await asyncio.sleep(minutes * 60)

    # Start the task
    task_instance = bot.loop.create_task(task())
    tasks_dict[(channel_id, user_id)] = task_instance
    await ctx.send(f"```Started sending messages to <@{user_id}> in <#{channel_id}> every {minutes} minutes.```")






autobeef_targets = {}  # Tracks active auto-beef targets
message_timestamps = {}  # Tracks the last few message times for spam detection
autobeefer_messages = [
    "ur shit as fuck pedophile {name}",
    "She is only 5 get that dick outta her nipples u pedo named {name}",
    "Yo fuck ass nigga named {name}, ur fuckin ass and u should hang urself with a dildo",
    "Stop tryna hit me u fuckin diddy {name}",
    "Fuck ass boy stop drinking horse semen",
    "nigga ur fuckin ass u shemale pedophile {name}",
    "{name} how about u kys now fucking twink",
    "Nigga ur fuckin ass {name}",
    "YO SHUT THE FUCK UP {name} LOL.",
    "thats why ur dad left u fuckin loser named {name}",
    "yo slut stop cutting ur self u fuckin retard",
    "bitch ass boy named {name} u killed ur self",
    "and this bitch ass nigga killed himself",
    "yo\nbitch\nshut\nthe\nfuck\nup\npedo\nass{name}",
    "stop sucking my dick u peon",
    "ur fuckin ass lol kys now pedo",
    "ur shit as fuck pedophile {name}",
    "She is only 5 get that dick outta her nipples u pedo named {name}",
    "Yo fuck ass nigga named {name}, ur fuckin ass and u should hang urself with a dildo",
    "Stop tryna hit me u fuckin diddy {name}",
    "Fuck ass boy stop drinking horse semen",
    "nigga ur fuckin ass u shemale pedophile {name}",
    "{name} how about u kys now fucking twink",
    "Nigga ur fuckin ass {name}",
    "YO SHUT THE FUCK UP {name} LOL.",
    "thats why ur dad left u fuckin loser named {name}",
    "yo slut stop cutting ur self u fuckin retard",
    "bitch ass boy named {name} u killed ur self",
    "and this bitch ass nigga killed himself",
    "yo\nbitch\nshut\nthe\nfuck\nup\npedo\nass{name}",
    "ur shit as fuck pedophile {name}",
  "She is only 5 get that dick outta her nipples u pedo named {name}!",
  "Yo fuck ass nigga named {name}, ur fuckin ass and u should hang urself with a dildo",
  "Stop tryna hit me u fuckin diddy {name}",
  "Fuck ass boy stop drinking horse semen",
  "nigga ur fuckin ass u shemale pedophile {name}",
  "{name} how about u kys now fucking twink",
  "Nigga ur fuckin ass {name}",
  "YO SHUT THE FUCK UP {name} LOL.",
 "thats why ur dad left u fuckin loser named {name}",
 "yo slut stop cutting ur self u fuckin retard {name} ",
"bitch ass boy named {name} u killed ur self {name} ",
"and this bitch ass nigga killed himself {name} ",
"yo\nbitch\nshut\nthe\nfuck\nup\npedo\nass{name}" "cringe pedophile {name} ","ugly faggot ass pedo","drop dead maggot","niggas spit on u everywhere u go","do u still cut yourself","isnt this the dork i made eat his on feces on cam LOL","ill cave yo teeth in","dork","soft ass queer","slit your throat pedophile","weak test tube baby","they watching me rip yo teeth out with pliers","sloppy mouth faggot","im ur diety","die faggot","ur weak bitch","ill rip your tongue out","ill erdacite whats left of your species","saggy breast loser","ill send u to god faggot","I WILL FUCKING MURDER YOU WITH MY BARE HANDS JEW","rape victim","insecure cunt","deformed man boobs LOL","pathetic leech make a name for yourself","I WILL STOMP YOUR HEAD IN FRAIL FAGGOT","YO BITCH I SAID SHUT THE FUCK UP WEAK TESTICA EATING FAGGOT ILL FUCKING END YOUR BLOODLINE","freak","ew your a pedo","cringe","yo remember when u used to eat your own feces on camera","u have no friends","illnfuckingnpunchnyournfacenoff","i invoke fear into your heart","saggy breast pedo","obese loser on discord with manboobs","dork with orge ears""dirty ass rodent molester" "u cant beef me","weakling","YO\nBITCH\nSHUT\nTHE\nFUCK\nUP\nWEAK\nASS\nPEDOPHILE\nCRINGE\nCHILDTOUCHER","ill crush every bone in your body slut","frail bitch","ill lynch u nigger","trash\nass\npedophile\nlame\ndork","YO BITCH SPEAK BACK IAN TELL U TO STOP","retard","dweeb","sloppy mouth faggot","your a nobody faggot","weak shitter","nigga cant up funds LOLOLOL lame pooron","ill break your teeth n make u cough blood up for weeks","ill snap your neck faggot","cuck","shit face","kys faggot""nb cares faggot", "YOU SUCK",
"dirty ass rodent molester {name} ",
"weak prostitute {name} ",
"stfu dork ass nigga {name} ",
"garbage ass slut {name} ",
"ur weak",
"why am i so above u rn",
"soft ass nigga",
"frail slut",
"ur slow as fuck",
"you cant beat me",
"shut the fuck up LOL",
"you suck faggot ass nigga be quiet",
"YOU SUCK\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nwtf\nyoure\nslow\nas\nfuck\nlmao\nSHUT\nTHE\nFUCK\nUP\nLMFAOO\nyou suck faggot ass nigga",
"YOU SUCK\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nwtf\nyoure\nslow\nas\nfuck\nlmao\nSHUT\nTHE\nFUCK\nUP\nLMFAOO\nyou suck weak ass nigga",
"YOU SUCK\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nwtf\nyoure\nslow\nas\nfuck\nlmao\nSHUT\nTHE\nFUCK\nUP\nLMFAOO\nyou suck soft ass nigga",
"YOU SUCK\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nwtf\nyoure\nslow\nas\nfuck\nlmao\nSHUT\nTHE\nFUCK\nUP\nLMFAOO\nyou suck hoe ass nigga", "y ur ass so weak nigga", "yo stfu nb fw u", "com reject", "yo retard stfu", "pedo", "frail fuck",
"weakling", "# stop bothering minors", "# Don't Fold", "cuck", "faggot", "hop off the alt loser" "ðŸ¤¡","sup feces sniffer how u been", "hey i heard u like kids", "femboy", 
"sup retard", "ur actually ass wdf", "heard u eat ur boogers", "zoophile", "doesn't ur mom abuse u", "autistic fuck", "stop fantasizing about ur mom weirdo", "hey slut shut the fuck up","you're hideous bitch shut up and clean my dogs feces","hey slut come lick my armpits","prostitute stfu slut","bitch shut up","you are ass nigga you wanna be me so bad","why do your armpits smell like that","stop eating horse semen you faggot","stop sending me your butthole in DMs gay boy","why are you drinking tap water out of that goats anus","say something back bitch","you have a green shit ring around your bootyhole","i heard you use snake skin dildos","ill cum in your mouth booty shake ass nigga","type in chat stop fingering your booty hole","i heard you worship cat feces","worthless ass slave","get your head out of that toilet you slut","is it true you eat your dads belly button lint? pedo","fuck up baby fucker","dont you jerk off to elephant penis","hey i heard you eat your own hemorroids","shes only 5 get your dick off of her nipples pedo","you drink porta potty water","hey bitch\nstfu\nyou dogshit ass nigga\nill rip your face apart\nugly ass fucking pedo\nwhy does your dick smell like that\ngay ass faggot loser\nfucking freak\nshut up","i\nwill\nrip\nyour\nhead\noff\nof\nyour\nshoulders\npussy\nass\nslime ball","nigga\nshut\nup\npedophile","stfu you dogshit ass nigga you suck\nyour belly button smells like frog anus you dirty ass nigga\nill rape your whole family with a strap on\npathetic ass fucking toad","YOU\nARE\nWEAK\nAS\nFUCK\nPUSSY\nILL\nRIP\nYOUR\nVEINS\nOUT\nOF\nYOUR\nARMS\nFAGGOT\nASS\nPUSSY\nNIGGA\nYOU\nFRAIL\nASS\nLITTLE\nFEMBOY","tranny anus licking buffalo","your elbows stink","frog","ugly ass ostrich","pencil necked racoon","why do your elbows smell like squid testicals","you have micro penis","you have aids","semen sucking blood worm","greasy elbow geek","why do your testicals smell like dead   buffalo appendages","cockroach","Mosquito","bald penguin","cow fucker","cross eyed billy goat","eggplant","sweat gobbler","cuck","penis warlord","slave","my nipples are more worthy than you","hairless dog","alligator","shave your nipples","termite","bald eagle","hippo","cross eyed chicken","spinosaurus rex","deformed cactus","prostitute","come clean my suit","rusty nail","stop eating water balloons","dumb blow dart","shit ball","slime ball","golf ball nose","take that stick of dynamite out of your nose","go clean my coffee mug","hey slave my pitbull just took a shit, go clean his asshole","walking windshield wiper","hornet","homeless pincone","hey hand sanitizer come lick the dirt off my hands","ice cream scooper","aborted fetus","dead child","stop watching child porn and fight back","homeless rodant","hammerhead shark","hey sledgehammer nose","your breath stinks","you cross eyed street lamp","hey pizza face","shave your mullet","shrink ray penis","hey shoe box come hold my balenciagas","rusty cork screw","pig penis","hey cow sniffer","walking whoopee cushion","stop chewing on your shoe laces","pet bullet ant","hey mop come clean my floor","*rapes your ass* now what nigga","hey tissue box i just nutted on your girlfriend come clean it up","watermelon seed","hey tree stump","hey get that fly swatter out of your penis hole","melted crayon","hey piss elbows","piss ball","hey q tip come clean my ears","why is that saxaphone in your anus","stink beetle","bed bug","cross eyed bottle of mustard","hey ash tray","hey stop licking that stop sign","why is that spatula in your anus","hey melted chocolate bar","dumb coconut"
     
]

@bot.command()
async def autobeef(ctx, user_id: int, name: str, typing_time: float = 2.0):

    if user_id in autobeef_targets:
        await ctx.send(f"User with ID {user_id} is already being auto-beefed!")
        return

    message_timestamps[user_id] = []  # Initialize message timestamps for spam detection

    shuffled_messages = autobeefer_messages.copy()
    random.shuffle(shuffled_messages)

    async def send_autobeef(message):
        """
        Send up to 5 random auto-beef messages, avoiding repeats.
        """
        nonlocal shuffled_messages
        try:
            for _ in range(5):
                if not shuffled_messages:
                    shuffled_messages = autobeefer_messages.copy()
                    random.shuffle(shuffled_messages)

                random_message = shuffled_messages.pop(0).replace("{name}", name)
                if random.random() < 0.5:
                    random_message += f" <@{user_id}>"  # Mention the user using their ID
                
                # Show typing indicator in the same channel as the message
                async with message.channel.typing():
                    await asyncio.sleep(typing_time)
                await message.channel.send(random_message)
                await asyncio.sleep(random.uniform(0.1, 0))  # Delay between messages
        except Exception as e:
            print(f"Error in send_autobeef: {e}")

    async def beef_loop():
        """
        Main loop for monitoring user messages and sending auto-beef replies.
        """
        def check(m):
            return m.author.id == user_id

        while user_id in autobeef_targets:
            try:
                message = await bot.wait_for('message', check=check)

                now = time.time()
                message_timestamps[user_id].append(now)
                message_timestamps[user_id] = [t for t in message_timestamps[user_id] if now - t <= 5]
                
                if len(message_timestamps[user_id]) > 5:
                    print(f"Skipping auto-beef for user with ID {user_id} due to spam.")
                    await asyncio.sleep(1)
                    continue

                await send_autobeef(message)
            except Exception as e:
                print(f"Error in autobeef loop: {e}")
                await asyncio.sleep(1)

    autobeef_targets[user_id] = bot.loop.create_task(beef_loop())
    await ctx.send(f"Started auto-beefing user with ID {user_id} with messages mentioning '{name}'.")

@bot.command()
async def autobeefoff(ctx, user_id: int):

    if user_id in autobeef_targets:
        autobeef_targets[user_id].cancel()
        del autobeef_targets[user_id]
        message_timestamps.pop(user_id, None)  # Clean up timestamps
        await ctx.send(f"Stopped auto-beefing user with ID {user_id}.")
    else:
        await ctx.send(f"No active auto-beefing task for user with ID {user_id}.")

aggressive_autobeefer_tasks = {}  # Tracks active aggressive autobeefer tasks
aggressive_autobeefer_delays = {}  # Tracks delays for each user/channel combination


aggressive_autobeefer_messages = [
    "ur shit as fuck pedophile {name}",
    "She is only 5 get that dick outta her nipples u pedo named {name}",
    "Yo fuck ass nigga named {name}, ur fuckin ass and u should hang urself with a dildo",
    "Stop tryna hit me u fuckin diddy {name}",
    "Fuck ass boy stop drinking horse semen",
    "nigga ur fuckin ass u shemale pedophile {name}",
    "{name} how about u kys now fucking twink",
    "Nigga ur fuckin ass {name}",
    "YO SHUT THE FUCK UP {name} LOL.",
    "thats why ur dad left u fuckin loser named {name}",
    "yo slut stop cutting ur self u fuckin retard",
    "bitch ass boy named {name} u killed ur self",
    "and this bitch ass nigga killed himself",
    "yo\nbitch\nshut\nthe\nfuck\nup\npedo\nass{name}",
    "ur shit as fuck pedophile {name}",
  "She is only 5 get that dick outta her nipples u pedo named {name}!",
  "Yo fuck ass nigga named {name}, ur fuckin ass and u should hang urself with a dildo",
  "Stop tryna hit me u fuckin diddy {name}",
  "Fuck ass boy stop drinking horse semen",
  "nigga ur fuckin ass u shemale pedophile {name}",
  "{name} how about u kys now fucking twink",
  "Nigga ur fuckin ass {name}",
  "YO SHUT THE FUCK UP {name} LOL.",
 "thats why ur dad left u fuckin loser named {name}",
 "yo slut stop cutting ur self u fuckin retard {name} ",
"bitch ass boy named {name} u killed ur self {name} ",
"and this bitch ass nigga killed himself {name} ",
"yo\nbitch\nshut\nthe\nfuck\nup\npedo\nass{name}" "cringe pedophile {name} ","ugly faggot ass pedo","drop dead maggot","niggas spit on u everywhere u go","do u still cut yourself","isnt this the dork i made eat his on feces on cam LOL","ill cave yo teeth in","dork","soft ass queer","slit your throat pedophile","weak test tube baby","they watching me rip yo teeth out with pliers","sloppy mouth faggot","im ur diety","die faggot","ur weak bitch","ill rip your tongue out","ill erdacite whats left of your species","saggy breast loser","ill send u to god faggot","I WILL FUCKING MURDER YOU WITH MY BARE HANDS JEW","rape victim","insecure cunt","deformed man boobs LOL","pathetic leech make a name for yourself","I WILL STOMP YOUR HEAD IN FRAIL FAGGOT","YO BITCH I SAID SHUT THE FUCK UP WEAK TESTICA EATING FAGGOT ILL FUCKING END YOUR BLOODLINE","freak","ew your a pedo","cringe","yo remember when u used to eat your own feces on camera","u have no friends","illnfuckingnpunchnyournfacenoff","i invoke fear into your heart","saggy breast pedo","obese loser on discord with manboobs","dork with orge ears""dirty ass rodent molester" "u cant beef me","weakling","YO\nBITCH\nSHUT\nTHE\nFUCK\nUP\nWEAK\nASS\nPEDOPHILE\nCRINGE\nCHILDTOUCHER","ill crush every bone in your body slut","frail bitch","ill lynch u nigger","trash\nass\npedophile\nlame\ndork","YO BITCH SPEAK BACK IAN TELL U TO STOP","retard","dweeb","sloppy mouth faggot","your a nobody faggot","weak shitter","nigga cant up funds LOLOLOL lame pooron","ill break your teeth n make u cough blood up for weeks","ill snap your neck faggot","cuck","shit face","kys faggot""nb cares faggot", "YOU SUCK",
"dirty ass rodent molester {name} ",
"weak prostitute {name} ",
"stfu dork ass nigga {name} ",
"garbage ass slut {name} ",
"ur weak",
"why am i so above u rn",
"soft ass nigga",
"frail slut",
"ur slow as fuck",
"you cant beat me",
"shut the fuck up LOL",
"you suck faggot ass nigga be quiet",
"YOU SUCK\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nwtf\nyoure\nslow\nas\nfuck\nlmao\nSHUT\nTHE\nFUCK\nUP\nLMFAOO\nyou suck faggot ass nigga",
"YOU SUCK\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nwtf\nyoure\nslow\nas\nfuck\nlmao\nSHUT\nTHE\nFUCK\nUP\nLMFAOO\nyou suck weak ass nigga",
"YOU SUCK\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nwtf\nyoure\nslow\nas\nfuck\nlmao\nSHUT\nTHE\nFUCK\nUP\nLMFAOO\nyou suck soft ass nigga",
"YOU SUCK\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nwtf\nyoure\nslow\nas\nfuck\nlmao\nSHUT\nTHE\nFUCK\nUP\nLMFAOO\nyou suck hoe ass nigga", "y ur ass so weak nigga", "yo stfu nb fw u", "com reject", "yo retard stfu", "pedo", "frail fuck",
"weakling", "# stop bothering minors", "# Don't Fold", "cuck", "faggot", "hop off the alt loser" "ðŸ¤¡","sup feces sniffer how u been", "hey i heard u like kids", "femboy", 
"sup retard", "ur actually ass wdf", "heard u eat ur boogers", "zoophile", "doesn't ur mom abuse u", "autistic fuck", "stop fantasizing about ur mom weirdo", "hey slut shut the fuck up","you're hideous bitch shut up and clean my dogs feces","hey slut come lick my armpits","prostitute stfu slut","bitch shut up","you are ass nigga you wanna be me so bad","why do your armpits smell like that","stop eating horse semen you faggot","stop sending me your butthole in DMs gay boy","why are you drinking tap water out of that goats anus","say something back bitch","you have a green shit ring around your bootyhole","i heard you use snake skin dildos","ill cum in your mouth booty shake ass nigga","type in chat stop fingering your booty hole","i heard you worship cat feces","worthless ass slave","get your head out of that toilet you slut","is it true you eat your dads belly button lint? pedo","fuck up baby fucker","dont you jerk off to elephant penis","hey i heard you eat your own hemorroids","shes only 5 get your dick off of her nipples pedo","you drink porta potty water","hey bitch\nstfu\nyou dogshit ass nigga\nill rip your face apart\nugly ass fucking pedo\nwhy does your dick smell like that\ngay ass faggot loser\nfucking freak\nshut up","i\nwill\nrip\nyour\nhead\noff\nof\nyour\nshoulders\npussy\nass\nslime ball","nigga\nshut\nup\npedophile","stfu you dogshit ass nigga you suck\nyour belly button smells like frog anus you dirty ass nigga\nill rape your whole family with a strap on\npathetic ass fucking toad","YOU\nARE\nWEAK\nAS\nFUCK\nPUSSY\nILL\nRIP\nYOUR\nVEINS\nOUT\nOF\nYOUR\nARMS\nFAGGOT\nASS\nPUSSY\nNIGGA\nYOU\nFRAIL\nASS\nLITTLE\nFEMBOY","tranny anus licking buffalo","your elbows stink","frog","ugly ass ostrich","pencil necked racoon","why do your elbows smell like squid testicals","you have micro penis","you have aids","semen sucking blood worm","greasy elbow geek","why do your testicals smell like dead   buffalo appendages","cockroach","Mosquito","bald penguin","cow fucker","cross eyed billy goat","eggplant","sweat gobbler","cuck","penis warlord","slave","my nipples are more worthy than you","hairless dog","alligator","shave your nipples","termite","bald eagle","hippo","cross eyed chicken","spinosaurus rex","deformed cactus","prostitute","come clean my suit","rusty nail","stop eating water balloons","dumb blow dart","shit ball","slime ball","golf ball nose","take that stick of dynamite out of your nose","go clean my coffee mug","hey slave my pitbull just took a shit, go clean his asshole","walking windshield wiper","hornet","homeless pincone","hey hand sanitizer come lick the dirt off my hands","ice cream scooper","aborted fetus","dead child","stop watching child porn and fight back","homeless rodant","hammerhead shark","hey sledgehammer nose","your breath stinks","you cross eyed street lamp","hey pizza face","shave your mullet","shrink ray penis","hey shoe box come hold my balenciagas","rusty cork screw","pig penis","hey cow sniffer","walking whoopee cushion","stop chewing on your shoe laces","pet bullet ant","hey mop come clean my floor","*rapes your ass* now what nigga","hey tissue box i just nutted on your girlfriend come clean it up","watermelon seed","hey tree stump","hey get that fly swatter out of your penis hole","melted crayon","hey piss elbows","piss ball","hey q tip come clean my ears","why is that saxaphone in your anus","stink beetle","bed bug","cross eyed bottle of mustard","hey ash tray","hey stop licking that stop sign","why is that spatula in your anus","hey melted chocolate bar","dumb coconut"
     
]







@bot.command()
async def aggressivebeef(ctx, channel_id: int, user: discord.User, name: str):

    if user.id in aggressive_autobeefer_tasks:
        await ctx.send(f"Aggressive auto-beefing is already active for {user.name}!")
        return

    try:
        channel = bot.get_channel(channel_id)
        if not channel:
            await ctx.send(f"Channel with ID {channel_id} not found!")
            return

        # Default delay if not set
        delay = aggressive_autobeefer_delays.get(user.id, 1.0)

        async def send_beef_messages():
            while user.id in aggressive_autobeefer_tasks:
                # Randomly select a message
                message = random.choice(aggressive_autobeefer_messages).replace("{name}", name)

                # Occasionally ping the user
                if random.random() < 0.5:  # 50% chance
                    message += f" {user.mention}"

                try:
                    await channel.send(message)
                except discord.HTTPException as e:
                    print(f"Error sending message: {e}")
                    await asyncio.sleep(1)  # If there's an error, pause briefly before retrying
                await asyncio.sleep(delay)  # Customizable delay between messages

        # Start the aggressive auto-beefing task
        task = bot.loop.create_task(send_beef_messages())
        aggressive_autobeefer_tasks[user.id] = task
        await ctx.send(f"Aggressive auto-beefing for {user.name} started in <#{channel_id}> with a delay of {delay:.1f}s.")
    except Exception as e:
        print(f"Error starting aggressive auto-beefing: {e}")
        await ctx.send("An error occurred while starting aggressive auto-beefing.")


@bot.command()
async def aggressivebeefoff(ctx, user: discord.User):

    if user.id in aggressive_autobeefer_tasks:
        aggressive_autobeefer_tasks[user.id].cancel()
        del aggressive_autobeefer_tasks[user.id]
        await ctx.send(f"Aggressive auto-beefing for {user.name} has been stopped.")
    else:
        await ctx.send(f"No active aggressive auto-beefing found for {user.name}.")


@bot.command()
async def beefcd(ctx, user: discord.User, delay: float):

    if delay < 0.5:
        await ctx.send("Delay must be at least 0.5 seconds to avoid rate-limiting.")
        return

    aggressive_autobeefer_delays[user.id] = delay
    await ctx.send(f"Custom delay for {user.name} set to {delay:.1f} seconds.")
    

press = ["ILL\nKILL\nU\nSKID\n","who\nru?\nlol\nnn\nstepping\nto\nhis\nfounder","yo\nrandom\nmake\nme\na\nfansign\nfemboy\nLOL","i\ndont\nclaim\nu\nno\ntier\nrando","show\nme\n500k\nto\nbeef\nw\nme\nbtw\nur\npoor\nLOL"]

press_active = False
press_task = None
@bot.command()
async def press(ctx, *args):
    global press_active, press_task

    if not args:
        await ctx.send("```usage: <@user>```")
        await ctx.message.delete()
        return

    user_mentioned = None

    if len(args) == 1:
        arg = args[0]

        if arg.startswith("<@") and arg.endswith(">"):
            user_mentioned = arg  
        else:
            user_mentioned = f"<@{arg}>"

    if not user_mentioned:
        await ctx.send("```Could not resolve user mention or ID. Please try again.```")
        return

    if press_active:
        await ctx.send("```Press command is already active```")
        return

    press_active = True

    async def press_messages():
        while press_active:
            try:
                response = random.choice(press)

                await ctx.send(f"{response}\n{user_mentioned}")

                
                await asyncio.sleep(random.choice([1.0, 0.1, 0.2, 0.9, 0.4]))

            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Error: {e}")

    press_task = asyncio.create_task(press_messages())

@bot.command()
async def pressoff(ctx):
    global press_active, press_task

    if press_active:
        press_active = False
        if press_task:
            press_task.cancel()
            await ctx.send("```Press command has been stopped.```")

    
    await ctx.message.delete()
    await ctx.send(message)

gcpack_names = ["faggatron getting stepped on like a dork", 
          "2wpm warrior died to a god lol", 
          "you a lil bitch i run u", 
          "you a random to me faggot",
          "stop dick sucking u sad asl",
          "moron speak up u low as shit LOL",
          "i cant hear u son speak up to dada",
          "you a peon id never relate to you",
          "you piss poor tryna step on discord com",
          "you a random newgen bandwagon",
          "change ur ways ur a loser",
          "keep that ego up u still getting bitched",
          "go fix urself ur breaking",
          "ur a cuck why are you speaking",
          "lmao go log ur worthless",
          "nigga ur clueless",
          "keep being a bitch stop playin stupid",
          "learn to not me worthless ur sad asf",
          "dont fold on me jr",
          "ugly hippo steppin",
          "corny emo bastard",
          "u wish u were me LOL",
          "KKK NIGGA",
          "UR A PUSSY LOLL",]  # Your custom names
gcpack_task = None  # Stores the background task

@bot.command(name="gcbeef")
async def gcpack(ctx):
    global gcpack_task

    if gcpack_task:
        await ctx.send("```Already running!```", delete_after=2)
        return

    if not isinstance(ctx.channel, discord.GroupChannel):
        await ctx.send("```Group chats only!```", delete_after=2)
        return

    async def rename_loop():
        while True:
            try:
                # Iterate through gcpack_names NOT gcpack
                for name in gcpack_names:  # Fixed this line
                    await ctx.channel.edit(name=name)
                    await asyncio.sleep(0.5)
            except Exception as e:
                print(f"Error: {e}")
                await asyncio.sleep(5)

    gcpack_task = bot.loop.create_task(rename_loop())

@bot.command(name="gcbeefoff")
async def gcoff(ctx):
    global gcpack_task
    if gcpack_task:
        gcpack_task.cancel()
        gcpack_task = None
    await ctx.send("```gc beef disabled.```", delete_after=2)

ladder_task = None

def load_manual():
    path = "manual.txt"
    if not os.path.isfile(path):
        return ["manual.txt not found."]
    
    with open(path, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]

@bot.command(name='wrath') 
async def wrath(ctx: commands.Context, user: discord.User = None):
    global ladder_task

    target = user or ctx.author
    manual = load_manual()

    try:
        await ctx.message.delete()
    except discord.Forbidden:
        pass

    await ctx.send(
        f"# {target.mention} on foenem you a bitch FIGHT BACK NIGGA",
        allowed_mentions=discord.AllowedMentions(users=True)
    )

    async def send_wrath():
        try:
            for line in manual:
                # Typing effect
                async with ctx.typing():
                    await asyncio.sleep(random.uniform(1.0, 1.5))

                message = f"# {target.mention} {line}"

                try:
                    await ctx.send(message, allowed_mentions=discord.AllowedMentions(users=True))
                except discord.Forbidden:
                    await ctx.author.send(message)

                await asyncio.sleep(random.uniform(0.5, 1.0))


            await ctx.send(f"now look at urself {target.mention} you proud? ur a pathetic child slit ur throat")
            await ctx.send("https://media.discordapp.net/attachments/1179197163662758031/1202416855789342750/hajlhitla.gif")
            await ctx.send("HUSHHH MODEEEEEEEEEEEEEEEEEEE")
            await ctx.send(f"BOIIIII GET FLAMED ON DISCORD.COM {target.mention}")
            await ctx.send("PACKGOD WE MADE HIM CRY AHAHAHHAHAHA")
            await ctx.send("YOU DID THE HARLEM SHAKE ON YO MOMMA WITH CHICKEN BONES")
            await ctx.send("YO DADDY BEAT U WITH A KITCHEN SPOON AND U MOANED")


        except asyncio.CancelledError:
            pass
        except Exception as e:
            print(f"Error during wrath: {e}")
            pass

    ladder_task = asyncio.create_task(send_wrath())

@bot.command(name='wrathoff')
async def stopwrath(ctx: commands.Context):
    global ladder_task

    if ladder_task and not ladder_task.done():
        ladder_task.cancel()
        ladder_task = None
        await ctx.send("prophet god")
    else:
        try:
            await ctx.message.delete()
        except:
            pass

@bot.command()
async def aura (ctx):
    try:
        # Customizable variables
        gif_urls = [
            "https://i.gifer.com/C3ag.gif",
            "https://i.pinimg.com/originals/2b/47/dd/2b47dda4a47e399de34e6a004189f6c0.gif",
            "https://gifdb.com/images/high/steins-gate-kuisu-dark-aura-41ah71hd8bektlzx.gif",
            "https://www.icegif.com/wp-content/uploads/2022/01/icegif-543.gif",
            "https://pa1.narvii.com/6596/370088affed3c21ba80fade625527b8efd7328bd_hq.gif",
            "https://th.bing.com/th/id/R.05a25409f94ad16a3ea4e3d04c294163?rik=maf%2fhhbpG%2fXwpA&riu=http%3a%2f%2f2.bp.blogspot.com%2f-87TzpMAdbGg%2fVgRDSJqK8KI%2fAAAAAAAAD4U%2fUET1ZkkZqQ4%2fs1600%2f7.gif&ehk=tQncS0d3fl1OHHDEqHMhdLLJoehvzyj99S2Zdle0bvk%3d&risl=&pid=ImgRaw&r=0",
        ]
        
        greetings = [
            "# random dont speak of my name for i have returned",
            "# Come glaze me, son. My aura is insane",
            "# Shut the fuck up, peasant.",
            "# hush up the king is back",
            "# come glaze ur father peon",
            "***i- is it really him?*** THE KING IS HERE NIGGA",
            "# come scratch my balls lil girl",
        ]
        
        # Random selections
        random_gif = random.choice(gif_urls)
        random_greeting = random.choice(greetings)
        
        # Send as plain message with GIF
        await ctx.send(f"{random_greeting}")
        await ctx.send(f"{random_gif}")
    except Exception as e:
        await ctx.send(f"Error: {e if str(e) else 'Failed to send aura.'}")
        await ctx.message.delete()

@bot.command()
async def ass(ctx, user: discord.User):
    try:
        # Customizable variables
        gif_urls = [
            "https://th.bing.com/th/id/R.8f5d55972f42311be2fa042c4b584404?rik=cOmG8vOyMa2kNQ&pid=ImgRaw&r=0",
            "https://media.giphy.com/media/3oEjHWZnBkaEYTbl4s/giphy.gif",
            "https://image.myanimelist.net/ui/r3qBomK5dyfD2Qn9ImIhL38EZedyk4q61Dcp7av0EOkDtmoZG_HogXYi-p2_JiunhiOM1AU6iGT3GLHG0fTewJGJ30OYf7vv4-EEN-crsuw",
            "https://th.bing.com/th/id/OIP.XBHR10gZEbVJnq-SR-KBEQHaEL?rs=1&pid=ImgDetMain",
            "https://media.tenor.com/GBEZR0e1B9MAAAAC/raven-frosting.gif",
        ]
        
        greetings = [
            "# whos gonna take this dick ",
            "# your tight little hole feels so good",
            "# im boutta cummm",
            "# yo bend that back bitch",
            "# im boutta fuck the shit outta u",
            "# yo take this dick ugly bitch",
            "# only thing good abt u is that tight lil hole",
        ]
        
        # Random selections
        random_gif = random.choice(gif_urls)
        random_greeting = random.choice(greetings)
        
        # Send as plain message with GIF
        await ctx.send(f"{random_greeting} {user.mention}")
        await ctx.send(f"{random_gif}")
    except Exception as e:
        await ctx.send(f"Error: {e if str(e) else 'Failed to send aura.'}")
        await ctx.message.delete()

protection_messages = [
    "# obese faggot obsessed with a god named @prophet ",
    "i dont know u ur poor lmao lmk when u can move more than 3 usd LOL",
    "# i would make u my bitch but your fucking fat i would never let you be known as my bitch thats to much of a reward for you",
    " i claim you as my dog btw nn random",
    "# i dont know you LOL queer wants to be known",
    " DO\nYOU\nWANT\nMY\nWORD\nLIST\n?\nLOL\nU\nMIGHT\nNEED\nIT\nU\nUSE\nCHAT\nGPT\nTO\nGIVE\nU\nWORDS",
    "# YOUR\nA\nWEAK\nSKID\nASS\nNIGGA\nLOL\nUR\nFUCKING\nRETARDED\nYOU\nBUY\nSCRIPTS\nAND\nSTILL\nDIE\nYOU\nMORON",
    " CHATGPT\nHELP\nME\n@prophet \nIS\nHOEING\nME\nchatgpt: no one can kill him hes a god LOL",
    "# 3\nNECKED\nASS\nDORK\nLOOK\nAT\nUR\nFAT\nASS\nARCHED\nLOOKING\nAT\nUR\nPC\nLOL",
    " RUN\nMY\nBLAZE\nPUSSY",
    "# LMK\nWHEN\nU\nCAN\nDOUBLE\nMY\nNETWORTH\nPOOR\nJEW",
    "! ï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·º",
    "# YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n YO FEMBOY STEP DOWN U DIED TO A GOD LOL\n ",
    " yo fetus step up LOL",
    "# shut the fuck up son i fried ur router and raped ur bitch LOLLLL",
    " ill swat you and watch you cry for me like a little dog",
    "# OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n OUTLASTED BY @prophet  #NEVERDIED #POORON\n ",
    " ggs skid u died",
    "# NIGGA ILL WHIP U LMAO UR A LITTLE DOG TO ME COME BE A LITTLE SUBMISSIVE FAG",
    "go make me a fansign LMAO",
    "# LMAO CUT URSELF RANDOM",
    "https://media.discordapp.net/attachments/1363343599625965599/1371957070722498691/attachment-2-1.gif?ex=68250617&is=6823b497&hm=d6bc5a0e8a8a48667ad13544cc2df7801a2343c3abbf93888c545a0b5e47145f&=",
    "# noname thinks hes someone LOLLL"
]

channel_name_list = [
    "! skidmade faggot died to a god LOL", 
    "! shut the fuck up jew",
    "! ï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·ºï·º",
    "! SLIT UR WRIST @prophet  RUNS UR SOUL",
    "! QUEER GOT STEPPED ON BY @prophet ",
    "! YOU CANT EGO A GOD LAME ASS NIGGA",
    "! YOUR AN UGLYASS FREAK NIGGA ",
    "! YO PEON NEVER STEP AGAIN U LAME ASL LMAOOOO",
    "! YOU CANT HOE ME FAGGOT I NEVER FOLD",
    "! YOU BOUT LAME AS FUCK UR A CUCK TOO",
    "! POSTED YO MOM SUCKING MY DICK ON IG LOL",
    "! NIGGA ILL MAKE YOU CUT URSELF AND ILL SWAT UR FATHER",
    "! YOU GET NO BITCHES NIGGA UR HARMLESS TOO LOL",
    "! LETS GO CONTENT4CONTENT HARMLESS MORON",
    "! I STEPPED ON U LIL NIGGA AND BROKE YO JAW",
    "! UR SHITTY $5 SCRIPT CANT HOE ME LOL",
    "! COME BLAZE ME NIGGA UR LOW AS FUCK",
    "! SUCKING YO MOM TITTIES WHILE MY BOT HOES U",
    "! CHATGPT MADE FAGGOT",
] 


class SharedCounter:
    def __init__(self):
        self.value = 1
        self.lock = asyncio.Lock()

    async def increment(self):
        async with self.lock:
            current = self.value
            self.value += 1
            return current

shared_counter = SharedCounter()


protection_running = False
protection_tasks = {}


delays = [0.1,2.4, 2.4, 2.1, 2.3, 2.1, 1.3, 1.3, 1.2, 1.0, 0.5]
@bot.command()
async def jump(ctx, user: discord.User):
    global protection_running
    protection_running = True
    channel_id = ctx.channel.id

    async def send_message():
        last_send_time = 0

        while protection_running:
            try:
                current_time = time.time()
                time_since_last = current_time - last_send_time
                
                delay = random.choice(delays)  
                if time_since_last < delay:
                    await asyncio.sleep(delay - time_since_last)
                
                message = random.choice(protection_messages)
                count = await shared_counter.increment()

                # Send the message to the current channel
                await ctx.send(f"{message}\n```piss poor retarded peon``````@prophet #2026``````yes i run u``````yeo pedo you folded``````count: {count}```\n{user.mention}")
                last_send_time = time.time()

                await asyncio.sleep(random.choice(delays))  # Randomly choose delay for next message

            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"{e}")
                await asyncio.sleep(1)

    async def change_name():
        last_change_time = 0  

        name_change_count = 0
        message_count = 0

        while protection_running:
            try:
                current_time = time.time()
                time_since_last = current_time - last_change_time
                
                delay = random.choice(delays)  # Randomly choose a delay from the list
                if time_since_last < delay:
                    await asyncio.sleep(delay - time_since_last)

                # Change the channel name 5 times
                if name_change_count < 5:
                    new_channel_name = random.choice(channel_name_list)
                    await ctx.channel.edit(name=new_channel_name)
                    print(f"")
                    name_change_count += 1
                    await asyncio.sleep(random.choice(delays))  # Randomly choose delay for next name change

                # After changing name 5 times, send 3 messages
                if name_change_count == 5 and message_count < 3:
                    message = random.choice(protection_messages)
                    count = await shared_counter.increment()
                    await ctx.send(f"{message}\n```piss poor retarded peon``````@prophet #2026``````yes i run u``````yeo pedo you folded``````count: {count}```\n{user.mention}")
                    message_count += 1


                if message_count == 3:
                    name_change_count = 0
                    message_count = 0

            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"{e}")
                await asyncio.sleep(1)


    message_task = asyncio.create_task(send_message())
    name_change_task = asyncio.create_task(change_name())

    protection_tasks[channel_id] = [message_task, name_change_task]

    await ctx.send("```jump mode enabled```")

@bot.command()
async def jumpoff(ctx):
    global protection_running, protection_tasks

    if not protection_running:
        await ctx.send("```jump mode is not active.```")
        return

    protection_running = False


    for task in protection_tasks.get(ctx.channel.id, []):
        task.cancel()

    protection_tasks[ctx.channel.id] = []

    await ctx.send("```jump mode ended```")
autokill_targets = {}  # user_id : ar.txt lines


def load_ar_lines():
    try:
        with open("ar.txt", "r", encoding="utf-8") as f:
            return [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        return ["you're getting packed twin"]


@bot.command()
async def ar(ctx, user: discord.User):
    await ctx.message.delete()
    autokill_targets[user.id] = load_ar_lines()
    print(f"🔪 Autokilling {user} — Auto replying from ar.txt")


@bot.command()
async def aroff(ctx, user: discord.User = None):
    await ctx.message.delete()
    if user:
        if user.id in autokill_targets:
            del autokill_targets[user.id]
            print(f"❌ Stopped autokilling {user}")
    else:
        autokill_targets.clear()
        print("🧹 Cleared all autokill targets")
ladder_mode = False
# LADDER MODE ON
@bot.command()
async def lddr(ctx):
    global ladder_mode
    await ctx.message.delete()
    ladder_mode = True
    print("🔩 Ladder Mode Enabled Twin — Everything you type will be laddered.")


# LADDER MODE OFF
@bot.command()
async def lddrend(ctx):
    global ladder_mode
    await ctx.message.delete()
    ladder_mode = False
    print("🛑 Ladder Mode Disabled Twin — You back to normal.")


# LADDER PACK WITH THRAX.TXT
@bot.command()
async def lddrpack2(ctx, user: discord.User):
    await ctx.message.delete()
    try:
        with open("thrax.txt", "r", encoding="utf-8") as f:
            lines = [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        print("thrax.txt not found nigga.")
        return

    for line in lines:
        ladder_msg = "\n".join(line.split())
        try:
            await ctx.send(f"{user.mention}\n{ladder_msg}")
            await asyncio.sleep(0.3)
        except Exception as e:
            print(f"[ladderpack error] {e}")



mock_targets = []  # the user id(s) getting mocked.


def mock_text(text):
    result = ""
    upper = True
    for char in text:
        if char.isalpha():
            if upper:
                result += char.upper()
            else:
                result += char.lower()
            upper = not upper
        else:
            result += char
    return result




@bot.command()
async def mock(ctx, user: discord.User):
    await ctx.message.delete()
    if user.id in mock_targets:
        print(f"Already mocking {user}")
    else:
        mock_targets.append(user.id)
        print(f"🤡 Now mocking {user}")


@bot.command()
async def mockoff(ctx, user: discord.User = None):
    await ctx.message.delete()
    if user:
        if user.id in mock_targets:
            mock_targets.remove(user.id)
            print(f"Stopped mocking {user}")
        else:
            print(" Not mocking that user :3.")
    else:
        mock_targets.clear()
        print("🧹 Cleared all mock targets.")



target_user = None
hush_active = False  

@bot.command()
async def hush(ctx, user: discord.User):
    global target_user, hush_active
    if hush_active:
        await ctx.message.delete()
        return
    
    target_user = user
    hush_active = True
    
    await ctx.send(f"```Hush mode active```")
    
    delete_future_messages.start(ctx)

@tasks.loop(seconds=0.0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001)  
async def delete_future_messages(ctx):
    global target_user
    if target_user:
        async for message in ctx.channel.history(limit=1):
            if message.author == target_user:
                try:
                    await message.delete()
                    print(f"Deleted future message from {target_user}: {message.content}")
                except discord.Forbidden:
                    print(f"Failed to delete future message from {target_user}")

@bot.command()
async def hushoff(ctx):
    await ctx.message.delete()
    global hush_active
    if not hush_active:
        await ctx.send("")
        return
    
    hush_active = False
    delete_future_messages.stop()  
    await ctx.send("```Hush mode stopped``` ")


# ---------------- DATA ---------------- #
auto_react_targets = {}  # {user_id: emoji}
alt_react_targets = {}   # {user_id: [emoji_list, current_index]}
auto_react_enabled = True

# ---------------- SAVE / LOAD ---------------- #
def save_reacts():
    data = {
        "auto": auto_react_targets,
        "alt": {str(k): v for k, v in alt_react_targets.items()},
        "enabled": auto_react_enabled
    }
    with open("reacts.json", "w") as f:
        json.dump(data, f, indent=4)
    print(f"{Fore.MAGENTA}[Save]{Fore.WHITE} React settings saved to reacts.json")

def load_reacts():
    global auto_react_targets, alt_react_targets, auto_react_enabled
    try:
        with open("reacts.json", "r") as f:
            data = json.load(f)
            auto_react_targets = {int(k): v for k, v in data.get("auto", {}).items()}
            alt_react_targets = {int(k): v for k, v in data.get("alt", {}).items()}
            auto_react_enabled = data.get("enabled", True)
        print(f"{Fore.MAGENTA}[Load]{Fore.WHITE} React settings loaded from reacts.json")
    except FileNotFoundError:
        print(f"{Fore.MAGENTA}[Load]{Fore.WHITE} reacts.json not found, starting fresh.")

load_reacts()

# ---------------- COMMAND GROUP ---------------- #
@bot.group(invoke_without_command=True)
async def at(ctx, user: discord.User = None, emoji: str = None):
    """
    React command group.
    Extra feature: $react <user> <emoji> shorthand.
    """
    if user and emoji:
        auto_react_targets[user.id] = emoji
        await ctx.send(f"```Added {user.display_name} with emoji {emoji} for auto-react.```")
        print(f"\033[35m[Auto-React]\033[37m Added user: {user.display_name} with emoji: {emoji}")
    else:
        await ctx.send("")

# --- Add user ---
@at.command()
async def add(ctx, user: discord.User, emoji: str = "👍"):
    auto_react_targets[user.id] = emoji
    await ctx.send(f"Added {user.display_name} with emoji {emoji} for auto-react.")
    print(f"\033[35m[Auto-React]\033[37m Added user: {user.display_name} with emoji: {emoji}")

# --- Remove user ---
@at.command()
async def remove(ctx, user: discord.User):
    if user.id in auto_react_targets:
        del auto_react_targets[user.id]
        await ctx.send(f"```Removed {user.display_name} from auto-react.```")
        print(f"\033[35m[Auto-React]\033[37m Removed user: {user.display_name}")
    else:
        await ctx.send(f"{user.display_name} is not in auto-react list.")

# --- Set emoji for all auto-react users ---
@at.command()
async def set(ctx, emoji: str):
    for user_id in auto_react_targets:
        auto_react_targets[user_id] = emoji
    await ctx.send(f"```Set emoji for all auto-react users to {emoji}.```")
    print(f"\033[35m[Auto-React]\033[37m Set emoji for all users: {emoji}")

# --- Enable/Disable ---
@at.command()
async def on(ctx):
    global auto_react_enabled
    auto_react_enabled = True
    await ctx.send("```Auto-react is enabled```")
    print(f"\033[35m[Auto-React]\033[37m Auto-react enabled")

@at.command()
async def off(ctx):
    global auto_react_enabled
    auto_react_enabled = False
    await ctx.send("````Auto-react is disabled.```")
    print(f"\033[35m[Auto-React]\033[37m Auto-react disabled")

# --- Save ---
@at.command()
async def save(ctx):
    save_reacts()
    await ctx.send("Auto-react settings saved!")

# ---------------- ALTERNATIVE REACT GROUP ---------------- #
@at.group()
async def alternative(ctx):
    if ctx.invoked_subcommand is None:
        await ctx.send("```alternative on/off/set.```")

# --- Alternative on ---
@alternative.command(name="on")
async def alt_on(ctx, user: discord.User, *emojis):
    if not emojis:
        await ctx.send("You must provide at least one emoji.")
        return
    alt_react_targets[user.id] = [list(emojis), 0]
    await ctx.send(f"```Alternative react ON for {user.display_name} with emojis {emojis}.```")
    print(f"\033[35m[Alt-React]\033[37m Enabled for {user.display_name} with emojis: {emojis}")

# --- Alternative off ---
@alternative.command(name="off")
async def alt_off(ctx, user: discord.User):
    if user.id in alt_react_targets:
        del alt_react_targets[user.id]
        await ctx.send(f"```Alternative react OFF for {user.display_name}.```")
        print(f"\033[35m[Alt-React]\033[37m Disabled for {user.display_name}")
    else:
        await ctx.send(f"```{user.display_name} does not have alternative react enabled.```")

# --- Alternative set ---
@alternative.command(name="set")
async def alt_set(ctx, *emojis):
    if not emojis:
        await ctx.send("Provide at least one emoji to set.")
        return
    for user_id in alt_react_targets:
        alt_react_targets[user_id][0] = list(emojis)
        alt_react_targets[user_id][1] = 0
    await ctx.send(f"```Set alternative emojis for all users to {emojis}.```")
    print(f"ansi\n033[35m[Alt-React]\033[37m Set emojis for all alternative users: {emojis}")


@bot.event
async def on_message(message):
    global ladder_mode, caps_mode, bold_mode
    if message.author.id in auto_react_targets:
        try:
            emoji = auto_react_targets[message.author.id]
            await message.add_reaction(emoji)
        except Exception as e:
            print(f"{Fore.RED}[ERROR] Failed to auto-react: {str(e)}")
    
    if message.author.id in alt_react_targets:
        try:
            emoji_list, current_index = alt_react_targets[message.author.id]
            await message.add_reaction(emoji_list[current_index])
            
            next_index = (current_index + 1) % len(emoji_list)
            alt_react_targets[message.author.id][1] = next_index
        except Exception as e:
            print(f"{Fore.RED}[ERROR] Failed to alt-react: {str(e)}")
    if (
        message.channel.id in autopin_enabled
        and message.author.id == autopin_targets.get(message.channel.id)
        and message.channel.type in [discord.ChannelType.group, discord.ChannelType.private, discord.ChannelType.text]
    ):
        try:
            await message.pin()
        except discord.HTTPException as e:
            print(f"[!] Failed to pin message: {e}")

    # AutoKill Logic
    if message.author.id in autokill_targets:
        line = random.choice(autokill_targets[message.author.id])
        try:
            await message.reply(f"{message.author.mention} {line}")
        except Exception as e:
            print(f"[autokill error] {e}")

    # Ladder Mode
    if ladder_mode and message.author.id == bot.user.id:
        if message.content.startswith("$"):
            return
        if "\n" in message.content:
            return
        ladder_msg = "\n".join(message.content.split())
        try:
            await message.delete()
            await message.channel.send(ladder_msg)
        except Exception as e:
            print(f"[ladder error] {e}")
        return

    # Mock Mode
    if message.author.id in mock_targets:
        mocked = mock_text(message.content)
        try:
            await message.channel.send(mocked)
        except Exception as e:
            print(f"[mockmode error] {e}")
    if message.author.id == bot.user.id and not message.content.startswith('.'):
        try:
            content = message.content
            should_edit = False

            if cord_mode and cord_user:
                content = f"{content} {cord_user.mention}"
                should_edit = True

            if should_edit:
                await message.edit(content=content)

        except Exception as e:
            print(f"Failed to edit message: {e}")

    if mimic_user is not None and mimic_user.id == message.author.id:
        content_to_send = message.content
        forbidden_pattern = r'\b(0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen)\b'
        if content_to_send.strip() and not re.search(forbidden_pattern, content_to_send, re.IGNORECASE):
            try:
                await message.channel.send((chr(173) + content_to_send))
                print(f"Mimicked message: {content_to_send}")
            except discord.Forbidden:
                print("Insufficient permissions to send messages in this channel.")
            except Exception as e:
                print(f"Error sending message: {e}")

    if not antilast_enabled:
        return

    if message.guild is not None:
        return

    if message.author == bot.user:
        return

    if (str(message.author.id) in antilast_data["whitelisted_users"] or 
        str(message.channel.id) in antilast_data["whitelisted_channels"]):
        return
    
    if isinstance(message.channel, discord.DMChannel):
        if any(word.lower() in message.content.lower() for word in anti_last_words):
            try:
                await message.channel.send("LMFAOO LAST WORD FOR SOCIAL")
                
                headers = {
                    "Authorization": bot.http.token,
                    "Content-Type": "application/json"
                }
                async with aiohttp.ClientSession() as session:
                    await session.put(
                        f"https://discord.com/api/v9/users/@me/relationships/{message.author.id}",
                        headers=headers,
                        json={"type": 2}
                    )
                
                    if antilast_data["webhook_url"]:
                        webhook = discord.Webhook.from_url(antilast_data["webhook_url"], adapter=discord.AsyncWebhookAdapter(session))
                        embed = discord.Embed(
                            title="This loser tried to last word you LMFAO",
                            description=f"fucking loser nice try",
                            color=discord.Color.red()
                        )
                        embed.add_field(name="User", value=f"{message.author} ({message.author.id})")
                        embed.add_field(name="Content", value=message.content)
                        await webhook.send(embed=embed)
            except Exception as e:
                print(f"Error in antilast DM handling: {str(e)}")

    elif isinstance(message.channel, discord.GroupChannel):
        if any(word.lower() in message.content.lower() for word in anti_last_words):
            try:
                await message.channel.send("LMFAOO LAST FOR SOCIAL")
                await message.channel.leave()
                
                if antilast_data["webhook_url"]:
                    async with aiohttp.ClientSession() as session:
                        webhook = discord.Webhook.from_url(antilast_data["webhook_url"], adapter=discord.AsyncWebhookAdapter(session))
                        embed = discord.Embed(
                            title="Anti Last Word Triggered",
                            description=f"User tried to last word in group chat",
                            color=discord.Color.red()
                        )
                        embed.add_field(name="User", value=f"{message.author} ({message.author.id})")
                        embed.add_field(name="Group", value=f"{message.channel}")
                        embed.add_field(name="Content", value=message.content)
                        await webhook.send(embed=embed)
            except Exception as e:
                print(f"Error in antilast GC handling: {str(e)}")

    if not antik_enabled:
        return

    if message.guild is not None:
        return

    if message.author == bot.user:
        return

    if (str(message.author.id) in antik_data["whitelisted_users"] or 
        str(message.channel.id) in antik_data["whitelisted_channels"]):
        return
    
    if isinstance(message.channel, discord.DMChannel):
        if any(word.lower() in message.content.lower() for word in anti_k_words):
            try:
                await message.channel.send("LMFOOOOO TS NIGGA TRIED TO K WORD ME")
                
                headers = {
                    "Authorization": bot.http.token,
                    "Content-Type": "application/json"
                }
                async with aiohttp.ClientSession() as session:
                    await session.put(
                        f"https://discord.com/api/v9/users/@me/relationships/{message.author.id}",
                        headers=headers,
                        json={"type": 2}
                    )
                
                    if antik_data["webhook_url"]:
                        webhook = discord.Webhook.from_url(antik_data["webhook_url"], adapter=discord.AsyncWebhookAdapter(session))
                        embed = discord.Embed(
                            title="This loser tried to k word you LMFAO",
                            description=f"fucking loser nice try",
                            color=discord.Color.red()
                        )
                        embed.add_field(name="User", value=f"{message.author} ({message.author.id})")
                        embed.add_field(name="Content", value=message.content)
                        await webhook.send(embed=embed)
            except Exception as e:
                print(f"Error in antiK DM handling: {str(e)}")

    elif isinstance(message.channel, discord.GroupChannel):
        if any(word.lower() in message.content.lower() for word in anti_k_words):
            try:
                await message.channel.send("LMFAOO K FOR THE GOD LOL")
                await message.channel.leave()
                
                if antik_data["webhook_url"]:
                    async with aiohttp.ClientSession() as session:
                        webhook = discord.Webhook.from_url(antik_data["webhook_url"], adapter=discord.AsyncWebhookAdapter(session))
                        embed = discord.Embed(
                            title="Anti K Word Triggered",
                            description=f"User tried to k word in group chat",
                            color=discord.Color.red()
                        )
                        embed.add_field(name="User", value=f"{message.author} ({message.author.id})")
                        embed.add_field(name="Group", value=f"{message.channel}")
                        embed.add_field(name="Content", value=message.content)
                        await webhook.send(embed=embed)
            except Exception as e:
                print(f"Error in antiK GC handling: {str(e)}")
    
    await bot.process_commands(message)

bot.run(token, bot=False) 
